"""Run a reproducible open-source pronunciation-scoring smoke benchmark.

The input sample is from SpeechOcean762. Its reference sentence is
"WE CALL IT BEAR" and its human sentence-level accuracy label is 8/10.
This script does not treat the result as a recruitment decision: it is only
a feasibility check for the MIT-licensed pronounce-assess phoneme model.
"""

import json
import sys
import time

import librosa
import numpy as np

from pronounce_assess import PronounceAssessModel


def main(audio_path: str, reference: str) -> int:
    started = time.perf_counter()
    audio, rate = librosa.load(audio_path, sr=16000, mono=True)
    loaded_at = time.perf_counter()

    assessor = PronounceAssessModel(sentence=reference, device="cpu")
    model_ready_at = time.perf_counter()
    events = list(assessor.stream_decode([np.asarray(audio, dtype=np.float32)], sample_rate=16000))
    ended = time.perf_counter()

    phones = [event for event in events if event.label != "prosody"]
    prosody = next((event for event in events if event.label == "prosody"), None)
    assessed = [event for event in phones if event.gop is not None]
    score = round(100 * sum(event.gop for event in assessed) / len(assessed), 1) if assessed else None
    errors = [
        {"phoneme": event.phoneme, "heard": event.decoded, "type": event.label,
         "score": round(float(event.gop), 3) if event.gop is not None else None}
        for event in phones if event.label in {"mispronounced", "omitted"}
    ]
    result = {
        "reference": reference,
        "audio_seconds": round(len(audio) / rate, 2),
        "pronunciation_score_0_100": score,
        "phonemes_assessed": len(assessed),
        "phoneme_errors": errors,
        "prosody": {
            "monotony_score": getattr(prosody, "monotony_score", None),
            "rhythm_score": getattr(prosody, "rhythm_score", None),
            "boundary_score": getattr(prosody, "boundary_score", None),
            "speaking_rate": getattr(prosody, "speaking_rate", None),
        },
        "timing_seconds": {
            "audio_load": round(loaded_at - started, 2),
            "model_load": round(model_ready_at - loaded_at, 2),
            "inference": round(ended - model_ready_at, 2),
        },
        "limitations": [
            "This package is a prototype and has no published independent benchmark.",
            "The output must not be used as an automatic recruitment rejection.",
            "This CPU test is not evidence that the model fits a Render Free instance.",
        ],
    }
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: benchmark_pronunciation.py AUDIO.wav 'REFERENCE SENTENCE'")
    raise SystemExit(main(sys.argv[1], sys.argv[2]))
