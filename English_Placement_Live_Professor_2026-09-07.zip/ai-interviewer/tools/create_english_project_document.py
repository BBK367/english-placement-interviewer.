from copy import deepcopy
from pathlib import Path
from docx import Document

SOURCE = Path(r"C:\Users\Le loup\Documents\CODEX 2\Livrables\Presentation_simple_projet_AI_English_Placement.docx")
OUTPUT = Path(r"C:\Users\Le loup\Documents\CODEX 2\Livrables\AI_English_Placement_Interviewer_Project_Overview.docx")

T = {
"PROJET DE STAGE":"INTERNSHIP PROJECT",
"AI English Placement\nInterviewer":"AI English Placement\nInterviewer",
"Une plateforme web d’entretien adaptatif pour estimer simplement le niveau d’anglais d’un candidat":"An adaptive web interview platform designed to provide a simple estimate of a candidate's English level",
"Document de présentation simple destiné au tuteur de stage\nVersion du 6 août 2026":"Simple project overview prepared for the internship supervisor\nVersion dated 6 August 2026",
"1. Le projet en une phrase":"1. The project in one sentence",
"Le projet simule un entretien d’anglais en ligne : le candidat répond à six questions, l’intelligence artificielle analyse ses réponses et produit une estimation structurée de son niveau.":"The project simulates an online English interview: the candidate answers six questions, the artificial intelligence analyses the answers and produces a structured estimate of the candidate's level.",
"2. Le besoin auquel il répond":"2. The need addressed by the project",
"Évaluer rapidement l’anglais d’un candidat demande normalement du temps et une personne capable de mener l’entretien. Cette application propose une première évaluation homogène et disponible à distance.":"Quickly assessing a candidate's English normally requires time and a qualified interviewer. This application provides a consistent first assessment that can be completed remotely.",
"Faire passer un premier entretien d’anglais depuis un navigateur web.":"Conduct an initial English interview from a web browser.",
"Adapter les questions selon les réponses et le niveau observé.":"Adapt the questions according to the answers and the level observed.",
"Fournir des résultats détaillés, faciles à relire par un recruteur ou un formateur.":"Provide detailed results that a recruiter or trainer can review easily.",
"Signaler clairement les limites de l’évaluation pour éviter une décision injuste.":"Clearly state the limitations of the assessment to help prevent unfair decisions.",
"3. Le parcours du candidat":"3. Candidate journey",
"Le candidat ouvre le site et découvre le fonctionnement de l’entretien.":"The candidate opens the website and reads how the interview works.",
"Il renseigne son nom, son adresse e-mail et, si besoin, une référence candidat.":"The candidate enters a name, email address and, where applicable, a candidate reference.",
"Il accepte l’évaluation et autorise l’accès au microphone.":"The candidate agrees to the assessment and authorises microphone access.",
"La première question est affichée et peut aussi être lue à voix haute.":"The first question is displayed and can also be read aloud.",
"Le candidat répond oralement ; le navigateur transforme sa voix en texte. Il peut également écrire ou corriger la transcription.":"The candidate answers verbally and the browser converts the speech into text. The candidate can also type or correct the transcript.",
"Après chaque réponse, Claude l’évalue et choisit la question suivante. Après six réponses, un rapport final est affiché.":"After each answer, Claude evaluates it and selects the next question. A final report is displayed after six answers.",
"4. Comment les différentes parties travaillent ensemble":"4. How the different parts work together",
"5. Comment fonctionne l’intelligence artificielle":"5. How the artificial intelligence works",
"Claude ne reçoit pas une liste complète de réponses préparées à l’avance. À chaque tour, le backend lui transmet la question, la réponse du candidat, l’historique utile et le niveau actuellement estimé.":"Claude does not use a complete list of pre-written replies. At each turn, the backend sends the question, the candidate's answer, the relevant conversation history and the current estimated level.",
"Claude analyse la réponse selon des règles précises définies dans le projet.":"Claude analyses the answer using precise rules defined by the project.",
"Il renvoie une évaluation dans un format technique imposé et validé par le serveur.":"It returns an assessment in a required technical format that is validated by the server.",
"Il choisit ensuite une question adaptée au niveau et à l’étape de l’entretien.":"It then selects a question suited to the level and the current interview stage.",
"Le serveur refuse une réponse de l’IA si elle ne respecte pas le format attendu.":"The server rejects an AI response if it does not follow the expected format.",
"6. Ce qui est évalué":"6. What is assessed",
"7. Le résultat final":"7. Final result",
"Après les six questions, l’application calcule une moyenne pour chaque critère et affiche :":"After the six questions, the application calculates an average for each criterion and displays:",
"un niveau CECR estimé, de A1 à C2 ;":"an estimated CEFR level from A1 to C2;",
"un résumé général et un niveau de confiance ;":"an overall summary and a confidence level;",
"les points forts du candidat ;":"the candidate's strengths;",
"les points à améliorer ;":"areas for improvement;",
"les limites à garder en tête avant toute décision.":"limitations to consider before making any decision.",
"8. Limites importantes de la version actuelle":"8. Important limitations of the current version",
"La transcription automatique peut contenir des erreurs liées au navigateur, au micro ou à l’accent.":"Automatic transcription may contain errors caused by the browser, microphone or accent.",
"Six questions donnent une estimation utile, mais limitée.":"Six questions provide a useful but limited estimate.",
"Les sessions sont conservées temporairement en mémoire et disparaissent si le serveur redémarre.":"Sessions are stored temporarily in memory and disappear if the server restarts.",
"Un résultat peu fiable ne doit jamais être présenté comme un refus définitif.":"A low-confidence result must never be presented as a definitive rejection.",
"9. Sécurité et protection des informations":"9. Security and data protection",
"Les clés AWS sont enregistrées uniquement dans les variables secrètes de Render.":"AWS keys are stored only in Render's secret environment variables.",
"Elles ne sont ni placées dans le code GitHub ni envoyées au navigateur.":"They are neither stored in the GitHub source code nor sent to the browser.",
"Le candidat doit donner son accord avant l’utilisation du microphone et de l’évaluation.":"The candidate must provide consent before the microphone and assessment are used.",
"Le serveur vérifie le format des données produites par Claude avant de les utiliser.":"The server validates the format of the data produced by Claude before using it.",
"Le projet ne doit pas analyser les émotions, la personnalité ou le comportement du candidat à partir de son visage.":"The project must not infer a candidate's emotions, personality or behaviour from facial images.",
"10. Technologies utilisées":"10. Technologies used",
"11. État actuel du projet":"11. Current project status",
"Le frontend et le backend sont réunis dans une application web accessible sur Internet.":"The frontend and backend are combined in a web application accessible through the Internet.",
"La connexion à AWS Bedrock fonctionne sur Render.":"The AWS Bedrock connection is working on Render.",
"Un test réel a confirmé que Claude évalue une réponse et génère la question suivante.":"A live test confirmed that Claude evaluates an answer and generates the next question.",
"Le déploiement est relié au dépôt GitHub : après publication d’un changement sur la branche principale, Render peut mettre le site à jour automatiquement.":"Deployment is linked to the GitHub repository: after a change is published to the main branch, Render can update the website automatically.",
"Adresse de démonstration : https://english-placement-interviewer.onrender.com/":"Demonstration website: https://english-placement-interviewer.onrender.com/",
"12. Prochaines évolutions possibles":"12. Possible next developments",
"Ajouter une webcam locale pour rendre l’entretien plus réaliste, sans analyser le visage ni enregistrer la vidéo par défaut.":"Add a local webcam preview to make the interview more realistic, without analysing the face or recording video by default.",
"Enregistrer les candidats, les sessions et les rapports dans une vraie base de données.":"Store candidates, sessions and reports in a persistent database.",
"Analyser réellement l’audio pour pouvoir évaluer la prononciation.":"Perform real acoustic analysis of the audio before assessing pronunciation.",
"Créer un espace recruteur pour consulter et comparer les rapports avec les précautions nécessaires.":"Create a recruiter area for reviewing and comparing reports with appropriate safeguards.",
"Ajouter davantage de tests, de suivi des erreurs et de mesures de coût des appels à l’IA.":"Add more tests, error monitoring and AI usage cost tracking.",
"Conclusion":"Conclusion",
"Cette première version démontre qu’un entretien d’anglais peut être organisé automatiquement, tout en gardant une structure contrôlée et des limites explicites. L’objectif n’est pas de remplacer le jugement humain, mais de fournir un premier indicateur cohérent, rapide et traçable pour préparer la suite du processus.":"This first version demonstrates that an English interview can be organised automatically while retaining a controlled structure and explicit limitations. Its purpose is not to replace human judgement, but to provide a consistent, quick and traceable initial indicator for the next stage of the process.",
"FORMAT":"FORMAT", "6 questions":"6 questions", "RÉSULTAT":"RESULT", "Niveau CECR estimé":"Estimated CEFR level", "IA":"AI", "Claude via AWS Bedrock":"Claude through AWS Bedrock",
"À retenir : il s’agit d’un outil de pré-évaluation pour orienter un recrutement ou une formation. Le résultat n’est pas une certification officielle d’anglais.":"Key point: this is a pre-assessment tool intended to support recruitment or training decisions. The result is not an official English-language certification.",
"Partie":"Component", "Rôle":"Role", "Exemple concret":"Practical example",
"Frontend":"Frontend", "Interface visible dans le navigateur":"Interface displayed in the browser", "Formulaire, microphone, questions, progression et résultat":"Form, microphone, questions, progress and result",
"Backend":"Backend", "Serveur qui organise l’entretien":"Server that manages the interview", "Crée la session, conserve l’historique et contrôle les réponses":"Creates the session, retains the history and controls the responses",
"AWS Bedrock":"AWS Bedrock", "Passerelle sécurisée vers le modèle d’IA":"Secure gateway to the AI model", "Envoie la consigne et la transcription à Claude":"Sends the instructions and transcript to Claude",
"Claude":"Claude", "Analyse linguistique et adaptation":"Language analysis and adaptation", "Note la réponse et génère la prochaine question":"Scores the answer and generates the next question",
"Render":"Render", "Hébergement sur Internet":"Internet hosting", "Rend le frontend et le backend accessibles avec une URL publique":"Makes the frontend and backend available through a public URL",
"Pourquoi une API ? L’API est le lien sécurisé entre le serveur du projet et Claude. Le navigateur du candidat ne reçoit jamais les identifiants AWS, le modèle utilisé ni les instructions internes.":"Why is an API required? The API is the secure link between the project server and Claude. The candidate's browser never receives AWS credentials, the model identifier or the internal instructions.",
"Critère":"Criterion", "Question simple posée par l’évaluation":"Simple question used by the assessment",
"Compréhension":"Comprehension", "La réponse correspond-elle à la question ?":"Does the answer address the question?",
"Fluidité":"Fluency", "La réponse est-elle suffisamment développée et naturelle dans la transcription ?":"Is the transcript sufficiently developed and natural?",
"Grammaire":"Grammar", "Les structures de phrases sont-elles correctes et variées ?":"Are the sentence structures correct and varied?",
"Vocabulaire":"Vocabulary", "Les mots sont-ils adaptés et suffisamment précis ?":"Are the words appropriate and sufficiently precise?",
"Cohérence":"Coherence", "Les idées sont-elles organisées et faciles à suivre ?":"Are the ideas organised and easy to follow?",
"Interaction":"Interaction", "Le candidat répond-il de manière pertinente dans un échange ?":"Does the candidate respond appropriately in an exchange?",
"Prononciation non évaluée : le navigateur fournit uniquement une transcription. Comme le fichier audio n’est pas analysé acoustiquement, l’application indique « non évaluée » pour la prononciation.":"Pronunciation not assessed: the browser provides only a transcript. Because the audio is not analysed acoustically, the application marks pronunciation as 'not assessed'.",
"Technologie":"Technology", "Utilisation dans le projet":"Use within the project",
"HTML, CSS, JavaScript":"HTML, CSS and JavaScript", "Interface du candidat et transcription dans le navigateur":"Candidate interface and browser-based transcription",
"Node.js et Express":"Node.js and Express", "API du backend et gestion des sessions d’entretien":"Backend API and interview session management",
"Accès sécurisé au modèle Claude":"Secure access to the Claude model", "Évaluation linguistique et génération adaptative des questions":"Language assessment and adaptive question generation",
"Zod / schémas JSON":"Zod / JSON schemas", "Validation stricte des résultats produits par l’IA":"Strict validation of the results produced by the AI",
"GitHub":"GitHub", "Stockage du code et suivi des versions":"Source-code storage and version tracking", "Déploiement automatique et hébergement public":"Automatic deployment and public hosting",
"Positionnement recommandé : utiliser le rapport comme une aide à la décision et un point de départ pour un échange humain, jamais comme une décision automatique définitive.":"Recommended positioning: use the report as decision support and as a starting point for human discussion, never as a definitive automated decision."
}

def replace_paragraph(p):
    if p.text not in T:
        return
    old_rpr = deepcopy(p.runs[0]._r.rPr) if p.runs and p.runs[0]._r.rPr is not None else None
    p.text = T[p.text]
    if old_rpr is not None and p.runs:
        p.runs[0]._r.insert(0, old_rpr)

doc = Document(SOURCE)
for p in doc.paragraphs:
    replace_paragraph(p)
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                replace_paragraph(p)
for section in doc.sections:
    for p in section.header.paragraphs:
        if p.text == "AI English Placement Interviewer  |  Présentation du projet":
            p.text = "AI English Placement Interviewer  |  Project overview"
    for p in section.footer.paragraphs:
        if p.text.startswith("Page "):
            # Keep the existing page field while translating the visible label (identical in English).
            pass

doc.core_properties.title = "AI English Placement Interviewer - Project Overview"
doc.core_properties.subject = "Simple presentation for the internship supervisor"
doc.core_properties.author = "AI English Placement Interviewer project"
doc.save(OUTPUT)
print(OUTPUT)
