from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
from pathlib import Path

OUT = Path(r"C:\Users\Le loup\Documents\CODEX 2\Livrables\Presentation_simple_projet_AI_English_Placement.docx")
OUT.parent.mkdir(parents=True, exist_ok=True)

BLUE = "176B5B"
DARK = "12352F"
MUTED = "64736F"
LIGHT = "EAF3F0"
LIGHTER = "F5F8F7"
BORDER = "C9D8D4"
WHITE = "FFFFFF"

doc = Document()
sec = doc.sections[0]
sec.page_width = Inches(8.5)
sec.page_height = Inches(11)
sec.top_margin = Inches(1)
sec.bottom_margin = Inches(1)
sec.left_margin = Inches(1)
sec.right_margin = Inches(1)
sec.header_distance = Inches(0.492)
sec.footer_distance = Inches(0.492)

def font(run, size=11, bold=False, color="1F2926", italic=False, name="Calibri"):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic
    run.font.color.rgb = RGBColor.from_string(color)

styles = doc.styles
normal = styles["Normal"]
normal.font.name = "Calibri"
normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
normal.font.size = Pt(11)
normal.font.color.rgb = RGBColor.from_string("1F2926")
normal.paragraph_format.space_before = Pt(0)
normal.paragraph_format.space_after = Pt(6)
normal.paragraph_format.line_spacing = 1.10

for name, size, before, after in [("Heading 1", 16, 16, 8), ("Heading 2", 13, 12, 6), ("Heading 3", 12, 8, 4)]:
    st = styles[name]
    st.font.name = "Calibri"
    st._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    st._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    st.font.size = Pt(size)
    st.font.bold = True
    st.font.color.rgb = RGBColor.from_string(BLUE if name != "Heading 3" else DARK)
    st.paragraph_format.space_before = Pt(before)
    st.paragraph_format.space_after = Pt(after)
    st.paragraph_format.keep_with_next = True

for list_name in ["List Bullet", "List Number"]:
    st = styles[list_name]
    st.font.name = "Calibri"
    st.font.size = Pt(11)
    st.paragraph_format.left_indent = Inches(0.5)
    st.paragraph_format.first_line_indent = Inches(-0.25)
    st.paragraph_format.space_after = Pt(8)
    st.paragraph_format.line_spacing = 1.167

if "Lead" not in styles:
    lead = styles.add_style("Lead", WD_STYLE_TYPE.PARAGRAPH)
else:
    lead = styles["Lead"]
lead.font.name = "Calibri"
lead.font.size = Pt(12)
lead.font.color.rgb = RGBColor.from_string(DARK)
lead.paragraph_format.space_after = Pt(10)
lead.paragraph_format.line_spacing = 1.15

def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tcPr.append(shd)
    shd.set(qn("w:fill"), fill)

def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in("w:tcMar")
    if tcMar is None:
        tcMar = OxmlElement("w:tcMar")
        tcPr.append(tcMar)
    for side, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcMar.find(qn(f"w:{side}"))
        if node is None:
            node = OxmlElement(f"w:{side}")
            tcMar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")

def set_table_geometry(table, widths):
    total = sum(widths)
    table.autofit = False
    tblPr = table._tbl.tblPr
    tblW = tblPr.find(qn("w:tblW"))
    if tblW is None:
        tblW = OxmlElement("w:tblW")
        tblPr.append(tblW)
    tblW.set(qn("w:w"), str(total)); tblW.set(qn("w:type"), "dxa")
    tblInd = tblPr.find(qn("w:tblInd"))
    if tblInd is None:
        tblInd = OxmlElement("w:tblInd"); tblPr.append(tblInd)
    tblInd.set(qn("w:w"), "120"); tblInd.set(qn("w:type"), "dxa")
    grid = table._tbl.tblGrid
    for child in list(grid): grid.remove(child)
    for width in widths:
        col = OxmlElement("w:gridCol"); col.set(qn("w:w"), str(width)); grid.append(col)
    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            tcW = cell._tc.get_or_add_tcPr().find(qn("w:tcW"))
            if tcW is None:
                tcW = OxmlElement("w:tcW"); cell._tc.get_or_add_tcPr().append(tcW)
            tcW.set(qn("w:w"), str(widths[idx])); tcW.set(qn("w:type"), "dxa")
            cell.width = Inches(widths[idx] / 1440)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)

def border_table(table, color=BORDER, size="6"):
    tblPr = table._tbl.tblPr
    borders = tblPr.find(qn("w:tblBorders"))
    if borders is None:
        borders = OxmlElement("w:tblBorders"); tblPr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single"); el.set(qn("w:sz"), size); el.set(qn("w:color"), color)
        borders.append(el)

def add_bullet(text):
    p = doc.add_paragraph(style="List Bullet")
    p.add_run(text)
    return p

def add_number(text):
    p = doc.add_paragraph(style="List Number")
    p.add_run(text)
    return p

def add_callout(label, text):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    set_table_geometry(table, [9360])
    border_table(table, color="B7CEC7", size="8")
    cell = table.cell(0, 0); shade(cell, LIGHT)
    p = cell.paragraphs[0]; p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.10
    r = p.add_run(label + " "); font(r, 11, True, DARK)
    r = p.add_run(text); font(r, 11, False, "28433D")
    doc.add_paragraph().paragraph_format.space_after = Pt(0)

def add_page_field(paragraph):
    run = paragraph.add_run()
    fld = OxmlElement("w:fldSimple"); fld.set(qn("w:instr"), "PAGE")
    run._r.addnext(fld)

# Running header/footer
hp = sec.header.paragraphs[0]
hp.text = "AI English Placement Interviewer  |  Présentation du projet"
hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
for r in hp.runs: font(r, 8.5, False, MUTED)
fp = sec.footer.paragraphs[0]
fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
r = fp.add_run("Page "); font(r, 8.5, False, MUTED)
add_page_field(fp)

# Editorial cover
doc.add_paragraph().paragraph_format.space_after = Pt(54)
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(14)
r = p.add_run("PROJET DE STAGE"); font(r, 10, True, BLUE)
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(10)
r = p.add_run("AI English Placement\nInterviewer"); font(r, 29, True, DARK)
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(24)
r = p.add_run("Une plateforme web d’entretien adaptatif pour estimer simplement le niveau d’anglais d’un candidat"); font(r, 14, False, MUTED)

cover = doc.add_table(rows=1, cols=3)
cover.alignment = WD_TABLE_ALIGNMENT.CENTER
set_table_geometry(cover, [3120, 3120, 3120])
border_table(cover, color=LIGHT, size="4")
for idx, (label, value) in enumerate([("FORMAT", "6 questions"), ("RÉSULTAT", "Niveau CECR estimé"), ("IA", "Claude via AWS Bedrock")]):
    cell = cover.cell(0, idx); shade(cell, LIGHTER)
    p = cell.paragraphs[0]; p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(3)
    rr = p.add_run(label); font(rr, 8, True, BLUE)
    p = cell.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.space_after = Pt(0)
    rr = p.add_run(value); font(rr, 10.5, True, DARK)

doc.add_paragraph().paragraph_format.space_after = Pt(80)
p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("Document de présentation simple destiné au tuteur de stage\nVersion du 6 août 2026"); font(r, 10, False, MUTED)

doc.add_page_break()

doc.add_heading("1. Le projet en une phrase", level=1)
p = doc.add_paragraph(style="Lead")
p.add_run("Le projet simule un entretien d’anglais en ligne : le candidat répond à six questions, l’intelligence artificielle analyse ses réponses et produit une estimation structurée de son niveau.")
add_callout("À retenir :", "il s’agit d’un outil de pré-évaluation pour orienter un recrutement ou une formation. Le résultat n’est pas une certification officielle d’anglais.")

doc.add_heading("2. Le besoin auquel il répond", level=1)
doc.add_paragraph("Évaluer rapidement l’anglais d’un candidat demande normalement du temps et une personne capable de mener l’entretien. Cette application propose une première évaluation homogène et disponible à distance.")
add_bullet("Faire passer un premier entretien d’anglais depuis un navigateur web.")
add_bullet("Adapter les questions selon les réponses et le niveau observé.")
add_bullet("Fournir des résultats détaillés, faciles à relire par un recruteur ou un formateur.")
add_bullet("Signaler clairement les limites de l’évaluation pour éviter une décision injuste.")

doc.add_heading("3. Le parcours du candidat", level=1)
steps = [
    "Le candidat ouvre le site et découvre le fonctionnement de l’entretien.",
    "Il renseigne son nom, son adresse e-mail et, si besoin, une référence candidat.",
    "Il accepte l’évaluation et autorise l’accès au microphone.",
    "La première question est affichée et peut aussi être lue à voix haute.",
    "Le candidat répond oralement ; le navigateur transforme sa voix en texte. Il peut également écrire ou corriger la transcription.",
    "Après chaque réponse, Claude l’évalue et choisit la question suivante. Après six réponses, un rapport final est affiché."
]
for step in steps: add_number(step)

doc.add_heading("4. Comment les différentes parties travaillent ensemble", level=1)
table = doc.add_table(rows=1, cols=3)
table.alignment = WD_TABLE_ALIGNMENT.LEFT
headers = ["Partie", "Rôle", "Exemple concret"]
for i, h in enumerate(headers):
    shade(table.cell(0, i), BLUE)
    p = table.cell(0, i).paragraphs[0]; p.paragraph_format.space_after = Pt(0)
    r = p.add_run(h); font(r, 10, True, WHITE)
rows = [
    ("Frontend", "Interface visible dans le navigateur", "Formulaire, microphone, questions, progression et résultat"),
    ("Backend", "Serveur qui organise l’entretien", "Crée la session, conserve l’historique et contrôle les réponses"),
    ("AWS Bedrock", "Passerelle sécurisée vers le modèle d’IA", "Envoie la consigne et la transcription à Claude"),
    ("Claude", "Analyse linguistique et adaptation", "Note la réponse et génère la prochaine question"),
    ("Render", "Hébergement sur Internet", "Rend le frontend et le backend accessibles avec une URL publique")
]
for ridx, values in enumerate(rows):
    cells = table.add_row().cells
    if ridx % 2: [shade(c, LIGHTER) for c in cells]
    for i, value in enumerate(values):
        p = cells[i].paragraphs[0]; p.paragraph_format.space_after = Pt(0); p.paragraph_format.line_spacing = 1.05
        r = p.add_run(value); font(r, 9.5, i == 0, DARK if i == 0 else "1F2926")
set_table_geometry(table, [1700, 3260, 4400])
border_table(table)

doc.add_heading("5. Comment fonctionne l’intelligence artificielle", level=1)
doc.add_paragraph("Claude ne reçoit pas une liste complète de réponses préparées à l’avance. À chaque tour, le backend lui transmet la question, la réponse du candidat, l’historique utile et le niveau actuellement estimé.")
add_number("Claude analyse la réponse selon des règles précises définies dans le projet.")
add_number("Il renvoie une évaluation dans un format technique imposé et validé par le serveur.")
add_number("Il choisit ensuite une question adaptée au niveau et à l’étape de l’entretien.")
add_number("Le serveur refuse une réponse de l’IA si elle ne respecte pas le format attendu.")
add_callout("Pourquoi une API ?", "L’API est le lien sécurisé entre le serveur du projet et Claude. Le navigateur du candidat ne reçoit jamais les identifiants AWS, le modèle utilisé ni les instructions internes.")

doc.add_heading("6. Ce qui est évalué", level=1)
criteria = [
    ("Compréhension", "La réponse correspond-elle à la question ?"),
    ("Fluidité", "La réponse est-elle suffisamment développée et naturelle dans la transcription ?"),
    ("Grammaire", "Les structures de phrases sont-elles correctes et variées ?"),
    ("Vocabulaire", "Les mots sont-ils adaptés et suffisamment précis ?"),
    ("Cohérence", "Les idées sont-elles organisées et faciles à suivre ?"),
    ("Interaction", "Le candidat répond-il de manière pertinente dans un échange ?")
]
table = doc.add_table(rows=1, cols=2)
for i, h in enumerate(["Critère", "Question simple posée par l’évaluation"]):
    shade(table.cell(0, i), BLUE); p=table.cell(0,i).paragraphs[0]; p.paragraph_format.space_after=Pt(0); r=p.add_run(h); font(r,10,True,WHITE)
for ridx, values in enumerate(criteria):
    cells = table.add_row().cells
    if ridx % 2: [shade(c, LIGHTER) for c in cells]
    for i, value in enumerate(values):
        p=cells[i].paragraphs[0]; p.paragraph_format.space_after=Pt(0); r=p.add_run(value); font(r,9.7,i==0,DARK if i==0 else "1F2926")
set_table_geometry(table, [2400, 6960]); border_table(table)

doc.add_heading("7. Le résultat final", level=1)
doc.add_paragraph("Après les six questions, l’application calcule une moyenne pour chaque critère et affiche :")
add_bullet("un niveau CECR estimé, de A1 à C2 ;")
add_bullet("un résumé général et un niveau de confiance ;")
add_bullet("les points forts du candidat ;")
add_bullet("les points à améliorer ;")
add_bullet("les limites à garder en tête avant toute décision.")

doc.add_heading("8. Limites importantes de la version actuelle", level=1)
add_callout("Prononciation non évaluée :", "le navigateur fournit uniquement une transcription. Comme le fichier audio n’est pas analysé acoustiquement, l’application indique « non évaluée » pour la prononciation.")
add_bullet("La transcription automatique peut contenir des erreurs liées au navigateur, au micro ou à l’accent.")
add_bullet("Six questions donnent une estimation utile, mais limitée.")
add_bullet("Les sessions sont conservées temporairement en mémoire et disparaissent si le serveur redémarre.")
add_bullet("Un résultat peu fiable ne doit jamais être présenté comme un refus définitif.")

doc.add_heading("9. Sécurité et protection des informations", level=1)
add_bullet("Les clés AWS sont enregistrées uniquement dans les variables secrètes de Render.")
add_bullet("Elles ne sont ni placées dans le code GitHub ni envoyées au navigateur.")
add_bullet("Le candidat doit donner son accord avant l’utilisation du microphone et de l’évaluation.")
add_bullet("Le serveur vérifie le format des données produites par Claude avant de les utiliser.")
add_bullet("Le projet ne doit pas analyser les émotions, la personnalité ou le comportement du candidat à partir de son visage.")

doc.add_heading("10. Technologies utilisées", level=1)
tech = doc.add_table(rows=1, cols=2)
for i,h in enumerate(["Technologie", "Utilisation dans le projet"]):
    shade(tech.cell(0,i), BLUE); p=tech.cell(0,i).paragraphs[0]; p.paragraph_format.space_after=Pt(0); r=p.add_run(h); font(r,10,True,WHITE)
for ridx, values in enumerate([
    ("HTML, CSS, JavaScript", "Interface du candidat et transcription dans le navigateur"),
    ("Node.js et Express", "API du backend et gestion des sessions d’entretien"),
    ("AWS Bedrock", "Accès sécurisé au modèle Claude"),
    ("Claude", "Évaluation linguistique et génération adaptative des questions"),
    ("Zod / schémas JSON", "Validation stricte des résultats produits par l’IA"),
    ("GitHub", "Stockage du code et suivi des versions"),
    ("Render", "Déploiement automatique et hébergement public")
]):
    cells=tech.add_row().cells
    if ridx%2: [shade(c,LIGHTER) for c in cells]
    for i,value in enumerate(values):
        p=cells[i].paragraphs[0];p.paragraph_format.space_after=Pt(0);r=p.add_run(value);font(r,9.7,i==0,DARK if i==0 else "1F2926")
set_table_geometry(tech,[2800,6560]);border_table(tech)

doc.add_heading("11. État actuel du projet", level=1)
add_bullet("Le frontend et le backend sont réunis dans une application web accessible sur Internet.")
add_bullet("La connexion à AWS Bedrock fonctionne sur Render.")
add_bullet("Un test réel a confirmé que Claude évalue une réponse et génère la question suivante.")
add_bullet("Le déploiement est relié au dépôt GitHub : après publication d’un changement sur la branche principale, Render peut mettre le site à jour automatiquement.")
p=doc.add_paragraph();r=p.add_run("Adresse de démonstration : ");font(r,11,True,DARK);r=p.add_run("https://english-placement-interviewer.onrender.com/");font(r,11,False,BLUE)

doc.add_heading("12. Prochaines évolutions possibles", level=1)
add_number("Ajouter une webcam locale pour rendre l’entretien plus réaliste, sans analyser le visage ni enregistrer la vidéo par défaut.")
add_number("Enregistrer les candidats, les sessions et les rapports dans une vraie base de données.")
add_number("Analyser réellement l’audio pour pouvoir évaluer la prononciation.")
add_number("Créer un espace recruteur pour consulter et comparer les rapports avec les précautions nécessaires.")
add_number("Ajouter davantage de tests, de suivi des erreurs et de mesures de coût des appels à l’IA.")

doc.add_heading("Conclusion", level=1)
doc.add_paragraph("Cette première version démontre qu’un entretien d’anglais peut être organisé automatiquement, tout en gardant une structure contrôlée et des limites explicites. L’objectif n’est pas de remplacer le jugement humain, mais de fournir un premier indicateur cohérent, rapide et traçable pour préparer la suite du processus.")
add_callout("Positionnement recommandé :", "utiliser le rapport comme une aide à la décision et un point de départ pour un échange humain, jamais comme une décision automatique définitive.")

doc.core_properties.title = "Présentation simple du projet AI English Placement Interviewer"
doc.core_properties.subject = "Document de présentation pour le tuteur de stage"
doc.core_properties.author = "Projet AI English Placement Interviewer"
doc.core_properties.keywords = "anglais, entretien, IA, Claude, AWS Bedrock, stage"
doc.save(OUT)
print(OUT)
