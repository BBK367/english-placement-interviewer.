CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE TABLE IF NOT EXISTS interviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(), status VARCHAR(30) NOT NULL DEFAULT 'in_progress',
  started_at TIMESTAMP DEFAULT NOW(), ended_at TIMESTAMP
);
CREATE TABLE IF NOT EXISTS dialogue_turns (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(), interview_id UUID NOT NULL REFERENCES interviews(id) ON DELETE CASCADE,
  turn_number INTEGER NOT NULL, role VARCHAR(20) NOT NULL CHECK (role IN ('user','assistant')),
  content TEXT NOT NULL, created_at TIMESTAMP DEFAULT NOW(), UNIQUE(interview_id, turn_number)
);
CREATE TABLE IF NOT EXISTS reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(), interview_id UUID NOT NULL UNIQUE REFERENCES interviews(id) ON DELETE CASCADE,
  report_json JSONB NOT NULL, created_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS api_usage_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(), interview_id UUID REFERENCES interviews(id) ON DELETE SET NULL,
  service VARCHAR(30) NOT NULL, input_tokens INTEGER, output_tokens INTEGER,
  cache_read_input_tokens INTEGER, cache_write_input_tokens INTEGER, error TEXT, created_at TIMESTAMP DEFAULT NOW()
);
