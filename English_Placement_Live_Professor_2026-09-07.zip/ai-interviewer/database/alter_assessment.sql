-- Extends the legacy recruiter proof of concept for English assessment without modifying it.
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS turn_evaluations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  interview_id UUID NOT NULL REFERENCES interviews(id) ON DELETE CASCADE,
  dialogue_turn_id UUID NOT NULL REFERENCES dialogue_turns(id) ON DELETE CASCADE,
  comprehension NUMERIC(2,1), fluency NUMERIC(2,1), grammar NUMERIC(2,1),
  vocabulary NUMERIC(2,1), coherence NUMERIC(2,1), interaction NUMERIC(2,1),
  pronunciation_status VARCHAR(20) DEFAULT 'not_assessed' CHECK (pronunciation_status IN ('not_assessed','assessed')),
  pronunciation_score NUMERIC(2,1),
  estimated_band VARCHAR(20) CHECK (estimated_band IN ('beginner','elementary','intermediate','upper_intermediate','advanced')),
  estimated_cefr VARCHAR(2) CHECK (estimated_cefr IN ('A1','A2','B1','B2','C1','C2')),
  observed_errors JSONB, evidence_json JSONB, strengths JSONB, improvement_areas JSONB,
  evaluation_status VARCHAR(20) DEFAULT 'ok' CHECK (evaluation_status IN ('ok','failed','skipped')),
  prompt_version VARCHAR(30), model_id VARCHAR(80), created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_turn_evaluations_interview_id ON turn_evaluations(interview_id);

ALTER TABLE interviews ADD COLUMN IF NOT EXISTS current_band VARCHAR(20) DEFAULT 'intermediate';
ALTER TABLE interviews ADD COLUMN IF NOT EXISTS questions_asked INTEGER DEFAULT 0;
ALTER TABLE interviews ADD COLUMN IF NOT EXISTS clarification_count INTEGER DEFAULT 0;
ALTER TABLE interviews ADD COLUMN IF NOT EXISTS mock_mode BOOLEAN DEFAULT FALSE;
ALTER TABLE interviews ADD COLUMN IF NOT EXISTS end_reason VARCHAR(30);
ALTER TABLE dialogue_turns ADD COLUMN IF NOT EXISTS transcript_source VARCHAR(20) CHECK (transcript_source IN ('browser','whisper','transcribe','manual'));
ALTER TABLE dialogue_turns ADD COLUMN IF NOT EXISTS transcript_edited BOOLEAN DEFAULT FALSE;
ALTER TABLE dialogue_turns ADD COLUMN IF NOT EXISTS duration_seconds NUMERIC(6,2);
ALTER TABLE reports ADD COLUMN IF NOT EXISTS estimated_cefr VARCHAR(2) CHECK (estimated_cefr IN ('A1','A2','B1','B2','C1','C2'));
ALTER TABLE reports ADD COLUMN IF NOT EXISTS confidence VARCHAR(10) CHECK (confidence IN ('low','medium','high'));
ALTER TABLE reports ADD COLUMN IF NOT EXISTS dimensions_json JSONB;
ALTER TABLE reports ADD COLUMN IF NOT EXISTS limitations JSONB;
ALTER TABLE reports ADD COLUMN IF NOT EXISTS representative_examples JSONB;
ALTER TABLE reports ADD COLUMN IF NOT EXISTS recommended_course_level VARCHAR(50);
ALTER TABLE reports ADD COLUMN IF NOT EXISTS mock_mode BOOLEAN DEFAULT FALSE;
ALTER TABLE reports ADD COLUMN IF NOT EXISTS prompt_version VARCHAR(30);
