# Project Guide

- The candidate product is the AI English Placement Interviewer.
- Do not reintroduce a generic named assistant persona.
- `backend/routes/cv.js`, `backend/routes/interview.js`, `backend/routes/reports.js`
  and `database/schema.sql` are the legacy recruiter proof of concept.
  Do not modify them.
- English assessment API work belongs in `backend/routes/assessment.js`,
  `backend/services/assessor.js` and `backend/prompts/`, reusing the existing
  `backend/config/db.js` and `backend/services/bedrock.js`.
- The evaluation and report JSON contract is defined by
  `frontend/src/assessment/schemas.ts`. Never define a second schema with
  different field names; reuse or mirror that one exactly.
- Model output must be constrained with a forced Amazon Bedrock Converse tool
  call. Never JSON.parse free-form model text.
- Bedrock stays on @aws-sdk/client-bedrock-runtime. Do not introduce another
  model provider SDK.
- Never send AWS credentials, model IDs, or prompt text to the browser.
- CEFR output is an estimated placement result used as a recruitment
  pre-filter, not an official certification.
- Pronunciation stays "not_assessed" unless real audio was acoustically analysed.
- A low-confidence result must never be presented as a definitive rejection.
