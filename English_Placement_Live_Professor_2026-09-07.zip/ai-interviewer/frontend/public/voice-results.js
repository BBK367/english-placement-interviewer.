const root=document.getElementById('result');
const add=(tag,text)=>{const n=document.createElement(tag);n.textContent=text;root.append(n);};
let data;try{data=JSON.parse(sessionStorage.getItem('voicePlacementReport'));}catch{}
if(!data){add('p','No result is available in this tab. Complete a voice interview first.');}
else if(data.status!=='completed'){add('h2','Insufficient evidence');add('p',data.message);}
else{const r=data.report;add('h2','Estimated CEFR: '+r.estimatedCefr);add('p',r.confidence+' confidence');add('p',r.summary);
const p=r.dimensions.pronunciation;add('h2','MultiPA pronunciation');add('p',p.status==='assessed' && p.score!==null?(p.score*20).toFixed(1)+' / 100':'Not assessed');add('p',p.summary);
add('h2','Language profile');for(const [key,d] of Object.entries(r.dimensions)){if(key!=='pronunciation')add('p',key+': '+d.score.toFixed(1)+'/5 — '+d.summary);}
add('h2','Strengths');for(const x of r.strengths)add('p',x);add('h2','Focus next');for(const x of r.improvementAreas)add('p',x);add('h2','Evidence and limitations');for(const x of r.limitations)add('p',x);}
