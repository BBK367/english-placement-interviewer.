const $ = id => document.getElementById(id);
const screens = ['welcome', 'registration', 'interview', 'loading', 'result'];
let session = null;
let recognition = null;
let transcriptionSupported = true;
let listening = false;
let startedAt = 0;
let finalTranscript = '';
let microphoneBlocked = false;
let answerRecorder = null;
let answerRecordingStream = null;
let answerAudioChunks = [];
let answerAudioBlob = null;
let answerRecordingStart = null;
let answerRecordingFinished = null;
let uploadedAnswerNumber = null;
let silenceTimer = null;
let recognitionEndResolve = null;

function show(name) {
  screens.forEach(id => $(id).classList.toggle('hidden', id !== name));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function toast(message) {
  $('toast').textContent = message;
  $('toast').classList.remove('hidden');
  setTimeout(() => $('toast').classList.add('hidden'), 5000);
}

function speak(text) {
  if (!('speechSynthesis' in window) || !text) return;
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'en-GB';
  utterance.rate = 0.94;
  utterance.onend = () => { if (session?.question?.text === text) $('hint').textContent = 'You can start speaking whenever you are ready.'; };
  speechSynthesis.speak(utterance);
}

function answerRecordingEnabled(data = session) {
  return Boolean(data?.audioRecording?.enabled);
}

function answerAnalysisEnabled(data = session) {
  return Boolean(data?.audioAnalysis?.enabled);
}

function setMicButton(label, active = false) {
  $('micBtn').classList.toggle('active', active);
  $('micBtn').innerHTML = `<span>${active ? '&#9632;' : '&bull;'}</span> ${label}`;
}

function updateSendAvailability() {
  $('sendBtn').disabled = !$('transcript').value.trim();
}

function renderQuestion(data) {
  session = data;
  uploadedAnswerNumber = null;
  answerAudioBlob = null;
  answerAudioChunks = [];
  $('stepLabel').textContent = `Question ${data.questionNumber} of ${data.totalQuestions}`;
  $('progressBar').style.width = `${(data.questionNumber / data.totalQuestions) * 100}%`;
  $('questionText').textContent = data.question.text;
  $('candidateLabel').textContent = `${$('fullName').value} · ${$('candidateReference').value}`;
  $('transcript').value = '';
  finalTranscript = '';
  $('listeningState').classList.add('hidden');
  $('sendBtn').disabled = true;

  if (!transcriptionSupported) {
    $('micBtn').disabled = true;
    $('micBtn').textContent = 'Live transcription unavailable';
    $('hint').textContent = answerRecordingEnabled(data)
      ? 'This browser cannot record the required spoken answer. Use a browser with microphone recording support.'
      : 'Live transcription is not supported by this browser. You can type your answer instead.';
  } else if (microphoneBlocked) {
    $('micBtn').disabled = false;
    setMicButton('Try microphone again');
    $('hint').textContent = answerRecordingEnabled(data)
      ? 'Allow microphone access in your browser site settings, then reload. Each answer must be recorded before it can be sent.'
      : 'Microphone access is blocked. Allow it in your browser site settings and reload, or type your answer.';
  } else {
    $('micBtn').disabled = false;
    setMicButton('Start speaking');
    $('hint').textContent = answerAnalysisEnabled(data)
      ? 'Each spoken answer is recorded, saved locally, and analysed for experimental pronunciation feedback when you send it.'
      : answerRecordingEnabled(data)
        ? 'Each spoken answer is recorded and retained in the local administrator archive when you send it.'
        : 'Take your time. A complete answer gives a more reliable result.';
  }
  show('interview');
  setTimeout(() => speak(data.question.text), 350);
}

function setupRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    transcriptionSupported = false;
    return;
  }
  recognition = new SpeechRecognition();
  recognition.lang = 'en-GB';
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.onresult = event => {
    clearTimeout(silenceTimer);
    let interim = '';
    for (let i = event.resultIndex; i < event.results.length; i += 1) {
      if (event.results[i].isFinal) finalTranscript += `${event.results[i][0].transcript} `;
      else interim += event.results[i][0].transcript;
    }
    $('transcript').value = `${finalTranscript}${interim}`.trim();
    updateSendAvailability();

  };
  recognition.onerror = event => {
    const denied = event.error === 'not-allowed' || event.error === 'service-not-allowed';
    microphoneBlocked = denied;
    stopListening(denied ? 'Try microphone again' : 'Continue speaking');
    stopAnswerRecording();
    if (denied) $('hint').textContent = answerRecordingEnabled()
      ? 'Allow microphone access in your browser site settings, then reload. This spoken answer must be recorded.'
      : 'Allow microphone access in your browser site settings, then reload, or type your answer.';
    toast(denied ? 'Microphone blocked by the browser. Allow it in site settings, then reload.' : 'Live transcription stopped. You can continue by typing.');
  };
  recognition.onend = () => {
    if (recognitionEndResolve) { recognitionEndResolve(); recognitionEndResolve = null; }
    if (listening) {
      try { recognition.start(); } catch (_) {}
    }
  };
}

function releaseAnswerRecordingStream() {
  answerRecordingStream?.getTracks().forEach(track => track.stop());
  answerRecordingStream = null;
}

async function startAnswerRecording() {
  if (!answerRecordingEnabled()) return true;
  if (answerRecorder || answerRecordingStart) return true;
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
    toast('This browser cannot record the required spoken answer. Please use a supported browser.');
    return false;
  }
  answerAudioBlob = null;
  let started = false;
  answerRecordingStart = navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
    answerRecordingStream = stream;
    answerAudioChunks = [];
    const activeRecorder = new MediaRecorder(stream);
    answerRecorder = activeRecorder;
    const mimeType = activeRecorder.mimeType || 'audio/webm';
    answerRecordingFinished = new Promise(resolve => {
      activeRecorder.ondataavailable = event => { if (event.data.size) answerAudioChunks.push(event.data); };
      activeRecorder.onerror = () => {
        releaseAnswerRecordingStream();
        answerRecorder = null;
        toast('This answer could not be recorded. Please try the microphone again before sending it.');
        resolve(null);
      };
      activeRecorder.onstop = () => {
        answerAudioBlob = answerAudioChunks.length ? new Blob(answerAudioChunks, { type: mimeType }) : null;
        releaseAnswerRecordingStream();
        answerRecorder = null;
        resolve(answerAudioBlob);
      };
    });
    activeRecorder.start();
    started = true;
  }).catch(() => {
    microphoneBlocked = true;
    toast('Microphone access was refused. Allow it in browser settings, then try again.');
  }).finally(() => { answerRecordingStart = null; });
  await answerRecordingStart;
  return started;
}

async function stopAnswerRecording() {
  if (answerRecordingStart) await answerRecordingStart;
  if (answerRecorder?.state === 'recording') {
    const complete = answerRecordingFinished;
    answerRecorder.stop();
    await complete;
  }
  return answerAudioBlob;
}

async function startListening() {
  if (!recognition) return;
  speechSynthesis?.cancel();
  if (!(await startAnswerRecording())) return;
  finalTranscript = $('transcript').value.trim() ? `${$('transcript').value.trim()} ` : '';
  startedAt = Date.now();
  listening = true;
  try { recognition.start(); } catch (_) { listening = false; return; }
  setMicButton('Stop speaking', true);
  $('listeningState').classList.remove('hidden');
  if (answerRecordingEnabled()) $('listeningState').lastChild.textContent = ' Recording and transcribing... speak naturally';
}

function stopListening(label = 'Continue speaking') {
  listening = false;
  clearTimeout(silenceTimer);
  silenceTimer = null;
  try { recognition?.stop(); } catch (_) {}
  setMicButton(label);
  $('listeningState').classList.add('hidden');
}

async function uploadAnswerRecording() {
  if (!answerRecordingEnabled()) return;
  if (!answerAudioBlob?.size) throw new Error('Please record this spoken answer before sending it.');
  if (uploadedAnswerNumber === session.questionNumber) return;
  await request(`/api/live/${session.interviewId}/recordings/${session.questionNumber}`, {
    method: 'POST',
    headers: { 'Content-Type': answerAudioBlob.type || 'audio/webm' },
    body: answerAudioBlob
  });
  uploadedAnswerNumber = session.questionNumber;
}

async function request(url, options) {
  const response = await fetch(url, options);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.message || 'Something went wrong.');
  return body;
}

function pronunciationToast(pronunciation, answerNumber) {
  if (!pronunciation || !answerAnalysisEnabled()) return '';
  if (pronunciation.status === 'assessed') return `Answer ${answerNumber}: ${pronunciation.engine === 'multipa' ? 'MultiPA' : 'experimental'} pronunciation score ${Math.round(pronunciation.score)}/100.`;
  return `Answer ${answerNumber}: pronunciation could not be assessed for this recording.`;
}

$('startBtn').addEventListener('click', () => show('registration'));

$('candidateForm').addEventListener('submit', async event => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('button[type=submit]');
  submit.disabled = true;
  try {
    if (navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach(track => track.stop());
      } catch (_) {
        microphoneBlocked = true;
        toast('Microphone blocked by the browser. Allow it in site settings, then reload.');
      }
    }
    const payload = {
      candidate: { fullName: $('fullName').value, email: $('email').value, reference: $('candidateReference').value },
      consents: {
        assessment: $('assessmentConsent').checked,
        microphone: $('microphoneConsent').checked,
        audioRecording: $('audioRecordingConsent').checked,
        audioAnalysis: $('audioAnalysisConsent').checked
      }
    };
    renderQuestion(await request('/api/live/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) }));
  } catch (error) {
    toast(error.message);
  } finally {
    submit.disabled = false;
  }
});

$('micBtn').addEventListener('click', async () => {
  if (!recognition) return;
  if (listening) {
    stopListening();
    await stopAnswerRecording();
  } else {
    await startListening();
  }
});

$('transcript').addEventListener('input', updateSendAvailability);
$('soundBtn').addEventListener('click', () => speak(session?.question?.text));

$('sendBtn').addEventListener('click', async () => {
  if (!$('transcript').value.trim()) return;
  if ($('sendBtn').disabled) return;
  $('sendBtn').disabled = true;
  const recognitionEnded = listening ? new Promise(resolve => {
    const timer = setTimeout(resolve, 1500);
    recognitionEndResolve = () => { clearTimeout(timer); resolve(); };
  }) : Promise.resolve();
  const answeredNumber = session.questionNumber;
  stopListening();
  await recognitionEnded;
  await stopAnswerRecording();
  const transcript = $('transcript').value.trim();
  if (answerRecordingEnabled() && !answerAudioBlob?.size) {
    updateSendAvailability();
    toast('Please press Start speaking and record this answer before sending it.');
    return;
  }
  $('loadingTitle').textContent = answerAnalysisEnabled() ? 'Reviewing your answer and audio...' : 'Reviewing your answer...';
  $('loadingText').textContent = answerAnalysisEnabled()
    ? 'Saving this response and analysing its pronunciation while the interviewer prepares the next question.'
    : answerRecordingEnabled()
      ? 'Saving your response recording, then preparing the next question.'
      : 'The interviewer is preparing the next question.';
  show('loading');
  try {
    await uploadAnswerRecording();
    const data = await request(`/api/live/${session.interviewId}/answer`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transcript, durationSeconds: startedAt ? Math.round((Date.now() - startedAt) / 1000) : null, transcriptEdited: true })
    });
    if (data.status === 'completed') {
      renderReport(data.report);
    } else {
      const message = pronunciationToast(data.pronunciation, answeredNumber);
      renderQuestion(data);
      if (message) toast(message);
    }
  } catch (error) {
    show('interview');
    updateSendAvailability();
    toast(error.message);
  }
});

function renderPronunciation(report) {
  const pronunciation = report.pronunciation;
  const card = $('pronunciationCard');
  if (!pronunciation) {
    card.classList.add('hidden');
    return;
  }
  card.classList.remove('hidden');
  if (pronunciation.status !== 'assessed') {
    $('pronunciationResult').innerHTML = `<p class="pronunciation-status">Not assessed</p><p>${escapeHtml(pronunciation.evidence || 'No audio was acoustically analysed.')}</p>`;
    return;
  }
  const perAnswer = pronunciation.perAnswer?.length
    ? `<h3>Per-answer results</h3><ul>${pronunciation.perAnswer.map(item => `<li><strong>Answer ${escapeHtml(String(item.answerNumber))}:</strong> ${item.status === 'assessed' ? `${escapeHtml(String(Math.round(item.score)))} / 100` : 'not assessed'}${item.evidence ? ` — ${escapeHtml(item.evidence)}` : ''}</li>`).join('')}</ul>`
    : '';
  const wordObservations = pronunciation.wordObservations?.length
    ? `<h3>Words to review</h3><ul>${pronunciation.wordObservations.map(item => {
      const score = item.totalScore === null || item.totalScore === undefined ? 'not available' : `${Math.round(item.totalScore)} / 100`;
      return `<li>${item.answerNumber ? `<strong>Answer ${escapeHtml(String(item.answerNumber))}:</strong> ` : ''}<strong>${escapeHtml(item.word)}</strong> — ${escapeHtml(score)}.</li>`;
    }).join('')}</ul>`
    : '';
  const errors = pronunciation.phonemeErrors?.length
    ? `<ul>${pronunciation.phonemeErrors.map(error => `<li>${error.answerNumber ? `<strong>Answer ${escapeHtml(String(error.answerNumber))}:</strong> ` : ''}<strong>${escapeHtml(error.expected)}</strong> was flagged as ${escapeHtml(error.type)}${error.heard ? ` (model heard ${escapeHtml(error.heard)})` : ''}.</li>`).join('')}</ul>`
    : '<p>No individual phoneme was flagged in the assessed recordings.</p>';
  const fluency = pronunciation.fluency?.speakingRate !== null && pronunciation.fluency?.speakingRate !== undefined
    ? `<p class="fluency-line">Approximate speech-segment rate: ${escapeHtml(String(Math.round(pronunciation.fluency.speakingRate)))} per minute.</p>`
    : '';
  const suggestions = pronunciation.suggestions?.length
    ? `<h3>Suggestions</h3><ul>${pronunciation.suggestions.map(item => `<li>${escapeHtml(item)}</li>`).join('')}</ul>`
    : '';
  const formatAudioScore = value => Number.isFinite(value) ? `${Math.round(value)}/100` : 'not available';
  const dimensions = pronunciation.engine === 'multipa'
    ? `<p class="fluency-line">Audio dimensions — accuracy: ${escapeHtml(formatAudioScore(pronunciation.accuracyScore))}, fluency: ${escapeHtml(formatAudioScore(pronunciation.fluency?.rhythmScore))}, prosody: ${escapeHtml(formatAudioScore(pronunciation.prosodyScore))}.</p>`
    : '';
  const detail = wordObservations || `<h3>Phoneme observations</h3>${errors}`;
  const engineLabel = pronunciation.engine === 'multipa' ? 'MultiPA pretrained-model average' : 'experimental average';
  $('pronunciationResult').innerHTML = `<div class="pronunciation-score"><strong>${escapeHtml(String(pronunciation.score))}</strong><span>/ 100 ${engineLabel}</span></div><p>${escapeHtml(pronunciation.evidence)}</p>${perAnswer}${dimensions}${fluency}${detail}${suggestions}`;
}

function renderReport(report) {
  $('cefr').textContent = report.estimatedCefr;
  $('summary').textContent = report.summary;
  $('confidence').textContent = `${report.confidence} confidence${report.confidenceScore !== undefined ? ` (${report.confidenceScore}/100)` : ''}`;
  if (new URLSearchParams(window.location.search).get('demoConfidence') === '1') {
    $('confidence').textContent = 'DEMO — simulated high confidence (90/100). Calculated: ' + report.confidence + (report.confidenceScore !== undefined ? ' (' + report.confidenceScore + '/100)' : '') + '. Not a reliability measurement.';
  }
  $('scores').innerHTML = Object.entries(report.averages).map(([name, value]) => `<div class="score"><span>${name}</span><div class="bar"><i style="width:${value * 20}%"></i></div><strong>${value}</strong></div>`).join('');
  $('strengths').innerHTML = (report.strengths.length ? report.strengths : ['Completed the adaptive interview']).map(item => `<li>${escapeHtml(item)}</li>`).join('');
  $('improvements').innerHTML = (report.improvementAreas.length ? report.improvementAreas : ['Continue practising extended answers']).map(item => `<li>${escapeHtml(item)}</li>`).join('');
  $('notice').innerHTML = `<strong>Important:</strong> This is an estimated recruitment pre-screening result, not an official language certification. ${report.pronunciation?.status === 'assessed' ? 'Pronunciation feedback is experimental and based on the recorded interview answers.' : 'Pronunciation was not assessed.'}`;
  renderPronunciation(report);
  show('result');
}

function escapeHtml(value) {
  const div = document.createElement('div');
  div.textContent = value;
  return div.innerHTML;
}

$('restartBtn').addEventListener('click', async () => {
  stopListening();
  await stopAnswerRecording();
  session = null;
  show('welcome');
});

setupRecognition();
