const el=id=>document.getElementById(id);
let finishing=false, countdown=null, concluding=false;
let ctx,stream,source,capture,events,id,active=false,sequence=Promise.resolve(),pending=0,nextTime=0,sources=new Set();
function clearPlayback(){for(const s of sources){try{s.stop();}catch{}}sources.clear();nextTime=ctx?.currentTime || 0;}
async function stop(){clearInterval(countdown);active=false;events?.close();capture?.disconnect();source?.disconnect();stream?.getTracks().forEach(t=>t.stop());clearPlayback();if(ctx && ctx.state!=='closed')await ctx.close();if(id){fetch('/api/voice/'+id,{method:'DELETE',keepalive:true});id=null;}el('start').disabled=false;el('stop').disabled=true;}
function fail(message){el('status').textContent=message;stop();}
function play(base64){const raw=Uint8Array.from(atob(base64),c=>c.charCodeAt(0));const view=new DataView(raw.buffer);const buffer=ctx.createBuffer(1,raw.length/2,24000);const samples=buffer.getChannelData(0);for(let i=0;i<samples.length;i++)samples[i]=view.getInt16(i*2,true)/32768;const s=ctx.createBufferSource();s.buffer=buffer;s.connect(ctx.destination);nextTime=Math.max(ctx.currentTime+0.025,nextTime);s.start(nextTime);nextTime+=buffer.duration;sources.add(s);s.onended=()=>sources.delete(s);if(nextTime-ctx.currentTime>15)fail('Audio playback fell behind. Please restart.');}
function showReport(data){
 sessionStorage.setItem('voicePlacementReport',JSON.stringify(data));
 window.location.assign('/voice-results.html');
}
async function conclude(){
 if(concluding || finishing || !id)return;
 concluding=true;clearInterval(countdown);el('stop').disabled=true;
 try{const r=await fetch('/api/voice/'+id+'/conclude',{method:'POST'});if(!r.ok)throw Error('Could not start the conclusion.');const data=await r.json();
 el('status').textContent='Final question: '+data.question;
 el('stop').textContent='I have finished — show results';el('stop').disabled=false;
 const end=Date.now()+45000;countdown=setInterval(()=>{const left=Math.max(0,Math.ceil((end-Date.now())/1000));el('timer').textContent='Conclusion: '+left+'s';if(!left)finish();},250);
 }catch(e){concluding=false;el('status').textContent=e.message;el('stop').disabled=false;}
}

async function finish(){
 if(finishing || !id)return;finishing=true;clearInterval(countdown);el('stop').disabled=true;el('status').textContent='Interview complete. Analysing language and pronunciation…';
 capture?.disconnect();source?.disconnect();stream?.getTracks().forEach(t=>t.stop());clearPlayback();
 await sequence;active=false;const sessionId=id;
 try{const r=await fetch('/api/voice/'+sessionId+'/finish',{method:'POST'});const data=await r.json();if(!r.ok)throw Error(data.message);showReport(data);el('status').textContent='Assessment complete.';}catch(e){el('status').textContent=e.message;}finally{await stop();finishing=false;}
}
el('stop').onclick=()=>concluding?finish():conclude();
el('start').onclick=async()=>{
 if(!el('consent').checked || !el('assessmentConsent').checked){el('status').textContent='Please agree to audio transmission first.';return;}
 concluding=false;el('stop').textContent='Go to final question';el('report').hidden=true;el('transcript').replaceChildren();el('start').disabled=true;el('status').textContent='Connecting…';
 try{
 ctx=new AudioContext({sampleRate:16000});await ctx.resume();
 stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true}});
 if(ctx.sampleRate!==16000)throw Error('This browser cannot capture at 16 kHz. Try another browser.');
 const response=await fetch('/api/voice/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({consent:true,assessmentConsent:true,duration:Number(el("duration").value)})});if(!response.ok)throw Error('Voice session could not start.');id=(await response.json()).id;
 await ctx.audioWorklet.addModule('/voice-capture.js');capture=new AudioWorkletNode(ctx,'voice-capture');source=ctx.createMediaStreamSource(stream);source.connect(capture);capture.connect(ctx.destination);
 active=true;pending=0;sequence=Promise.resolve();el('stop').disabled=false;
 capture.port.onmessage=({data})=>{if(!active)return;if(pending>20){fail('Network too slow for live audio. Please restart.');return;}const bytes=new ArrayBuffer(data.length*2),v=new DataView(bytes);for(let i=0;i<data.length;i++)v.setInt16(i*2,Math.max(-1,Math.min(1,data[i]))*32767,true);const sessionId=id;pending++;sequence=sequence.then(async()=>{if(!active || id!==sessionId)return;const r=await fetch('/api/voice/'+sessionId+'/audio',{method:'POST',headers:{'Content-Type':'application/octet-stream'},body:bytes});if(!r.ok)throw Error('Audio connection lost.');}).catch(e=>fail(e.message)).finally(()=>pending--);};
 events=new EventSource('/api/voice/'+id+'/events');events.onmessage=({data})=>{const e=JSON.parse(data);if(e.type==='ready'){el('status').textContent='Connected. Say hello — you can interrupt the interviewer.';const end=Date.now()+Number(el('duration').value)*1000;countdown=setInterval(()=>{const left=Math.max(0,Math.ceil((end-Date.now())/1000));el('timer').textContent=Math.floor(left/60)+':'+String(left%60).padStart(2,'0');if(!left)conclude();},250);}if(e.type==='failure')fail(e.data.message);if(e.type==='audioOutput' && active && !finishing)play(e.data.content);if(e.type==='contentEnd' && e.data.stopReason==='INTERRUPTED')clearPlayback();if(e.type==='textOutput'){if(/"interrupted"\s*:\s*true/.test(e.data.content)){clearPlayback();return;}const p=document.createElement('p');p.textContent=(e.data.role==='USER'?'You: ':'Interviewer: ')+e.data.content;el('transcript').append(p);}};events.onerror=()=>{if(active && !finishing)fail('Voice connection closed. You can restart the conversation.');};
 }catch(e){fail(e.message);}
};window.addEventListener('pagehide',()=>stop());