const $ = id => document.getElementById(id);
let administratorCode = '';
let activeAudioUrl = null;

function showArchive() {
  $('adminLogin').classList.add('hidden');
  $('adminArchive').classList.remove('hidden');
}

async function archiveRequest(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { ...(options.headers || {}), 'x-live-audio-admin-code': administratorCode }
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.message || 'The archive request failed.');
  }
  return response;
}

function makeText(tag, text, className = '') {
  const element = document.createElement(tag);
  element.textContent = text;
  if (className) element.className = className;
  return element;
}

function formatBytes(bytes) {
  return `${Math.max(1, Math.round(Number(bytes || 0) / 1024))} KB`;
}

async function playRecording(recording, button) {
  if (activeAudioUrl) URL.revokeObjectURL(activeAudioUrl);
  button.disabled = true;
  button.textContent = 'Loading…';
  try {
    const response = await archiveRequest(`/api/live/admin/recordings/${recording.id}/audio`);
    activeAudioUrl = URL.createObjectURL(await response.blob());
    const player = new Audio(activeAudioUrl);
    player.addEventListener('ended', () => {
      URL.revokeObjectURL(activeAudioUrl);
      activeAudioUrl = null;
    }, { once: true });
    await player.play();
  } catch (error) {
    window.alert(error.message);
  } finally {
    button.disabled = false;
    button.textContent = 'Play recording';
  }
}

function renderRecordings(recordings) {
  const list = $('recordingList');
  list.replaceChildren();
  $('archiveEmpty').classList.toggle('hidden', recordings.length !== 0);
  for (const recording of recordings) {
    const card = document.createElement('article');
    card.className = 'recording-item';
    const title = makeText('h2', `${recording.candidate.fullName || 'Unnamed candidate'} · Answer ${recording.answerNumber}`);
    const candidate = makeText('p', `${recording.candidate.email || 'No email'}${recording.candidate.reference ? ` · ${recording.candidate.reference}` : ''}`, 'recording-meta');
    const question = makeText('p', recording.questionText || 'Question text unavailable.', 'recording-question');
    const details = makeText('p', `${new Date(recording.recordedAt).toLocaleString()} · ${formatBytes(recording.byteSize)}`, 'recording-meta');
    const controls = document.createElement('div');
    controls.className = 'recording-controls';
    const play = makeText('button', 'Play recording', 'secondary-btn');
    play.type = 'button';
    play.addEventListener('click', () => playRecording(recording, play));
    const remove = makeText('button', 'Delete permanently', 'delete-btn');
    remove.type = 'button';
    remove.addEventListener('click', async () => {
      if (!window.confirm(`Permanently delete the recording for ${recording.candidate.fullName || 'this candidate'}? This cannot be undone.`)) return;
      remove.disabled = true;
      try {
        await archiveRequest(`/api/live/admin/recordings/${recording.id}`, { method: 'DELETE' });
        await loadArchive();
      } catch (error) {
        window.alert(error.message);
        remove.disabled = false;
      }
    });
    controls.append(play, remove);
    card.append(title, candidate, question, details, controls);
    list.append(card);
  }
}

async function loadArchive() {
  $('refreshArchive').disabled = true;
  try {
    const response = await archiveRequest('/api/live/admin/recordings');
    const data = await response.json();
    renderRecordings(data.recordings || []);
  } catch (error) {
    $('adminError').textContent = error.message;
    $('adminError').classList.remove('hidden');
    $('adminArchive').classList.add('hidden');
    $('adminLogin').classList.remove('hidden');
  } finally {
    $('refreshArchive').disabled = false;
  }
}

$('adminLoginForm').addEventListener('submit', async event => {
  event.preventDefault();
  administratorCode = $('adminCode').value;
  $('adminError').classList.add('hidden');
  try {
    const response = await archiveRequest('/api/live/admin/recordings');
    const data = await response.json();
    showArchive();
    renderRecordings(data.recordings || []);
  } catch (error) {
    $('adminError').textContent = error.message;
    $('adminError').classList.remove('hidden');
    administratorCode = '';
  }
});

$('refreshArchive').addEventListener('click', loadArchive);
