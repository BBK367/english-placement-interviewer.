import { z } from 'zod';

export const bandSchema=z.enum(['beginner','elementary','intermediate','upper_intermediate','advanced']);
export const cefrSchema=z.enum(['A1','A2','B1','B2','C1','C2']);
export const stageSchema=z.enum(['warm_up','experience','interaction','opinion','scenario','closing']);
export const competencySchema=z.enum(['comprehension','fluency','grammar','vocabulary','coherence','interaction']);
const scoredEvidenceSchema=z.object({score:z.number().min(0).max(5),evidence:z.string()}).strict();
export const answerEvaluationSchema=z.object({
  comprehension:scoredEvidenceSchema,fluency:scoredEvidenceSchema,grammar:scoredEvidenceSchema,vocabulary:scoredEvidenceSchema,coherence:scoredEvidenceSchema,interaction:scoredEvidenceSchema,
  pronunciation:z.object({status:z.enum(['not_assessed','assessed']),score:z.number().min(0).max(5).nullable(),evidence:z.string()}).strict(),
  observedErrors:z.array(z.object({category:z.enum(['grammar','vocabulary','coherence','interaction']),example:z.string(),suggestedCorrection:z.string()}).strict()),strengths:z.array(z.string()),improvementAreas:z.array(z.string())
}).strict();
export const nextQuestionSchema=z.object({id:z.string(),text:z.string(),difficulty:bandSchema,competencyTarget:competencySchema,stage:stageSchema}).strict();
export const evaluationResponseSchema=z.object({answerEvaluation:answerEvaluationSchema,estimatedBand:bandSchema,estimatedCefr:cefrSchema,nextAction:z.enum(['ask_next_question','finish_interview']),nextQuestion:nextQuestionSchema.nullable(),shouldFinish:z.boolean(),finishReason:z.string()}).strict();
const reportDimensionSchema=z.object({score:z.number().min(0).max(5),summary:z.string()}).strict();
const averagesSchema=z.object({comprehension:z.number().min(0).max(5),fluency:z.number().min(0).max(5),grammar:z.number().min(0).max(5),vocabulary:z.number().min(0).max(5),coherence:z.number().min(0).max(5),interaction:z.number().min(0).max(5)}).strict();
const fusionSchema=z.object({estimatedCefr:cefrSchema,estimatedBand:bandSchema,languageScore:z.number().min(0).max(5),speechScore:z.number().min(0).max(5).nullable(),globalScore:z.number().min(0).max(5),weights:z.object({language:z.number(),speech:z.number()}).strict()}).strict();
export const finalEnglishReportSchema=z.object({estimatedCefr:cefrSchema,estimatedBand:bandSchema,confidence:z.enum(['low','medium','high']),summary:z.string(),dimensions:z.object({comprehension:reportDimensionSchema,fluency:reportDimensionSchema,grammar:reportDimensionSchema,vocabulary:reportDimensionSchema,coherence:reportDimensionSchema,interaction:reportDimensionSchema,pronunciation:z.object({status:z.enum(['not_assessed','assessed']),score:z.number().min(0).max(5).nullable(),summary:z.string()}).strict()}).strict(),strengths:z.array(z.string()),improvementAreas:z.array(z.string()),representativeExamples:z.array(z.object({example:z.string(),observation:z.string()}).strict()),recommendedCourseLevel:z.string(),limitations:z.array(z.string()),confidenceScore:z.number().min(0).max(100).optional(),confidenceReasons:z.array(z.string()),averages:averagesSchema.optional(),fusion:fusionSchema.optional(),audioCoverage:z.number().min(0).max(100).nullable().optional(),audioCoverageByAnswer:z.array(z.object({answerNumber:z.number(),recordedDuration:z.number(),analyzedDuration:z.number(),coveragePercent:z.number().min(0).max(100).nullable()}).strict()),rawEvaluations:z.array(z.unknown()).optional()}).strict();

