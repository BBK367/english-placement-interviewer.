import { describe, expect, it } from 'vitest';
import { evaluationResponseSchema } from './schemas';

describe('shared assessment contract', () => {
  it('rejects a renamed CEFR field', () => {
    expect(() => evaluationResponseSchema.parse({ cefr: 'B1' })).toThrow();
  });
});
