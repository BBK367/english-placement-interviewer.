export type CefrLevel = 'A1'|'A2'|'B1'|'B2'|'C1'|'C2';
export type AbilityBand = 'beginner'|'elementary'|'intermediate'|'upper_intermediate'|'advanced';
export type InterviewStage = 'warm_up'|'experience'|'interaction'|'opinion'|'scenario'|'closing';
export type Competency = 'comprehension'|'fluency'|'grammar'|'vocabulary'|'coherence'|'interaction';
export type InterviewStatus = 'setup'|'ready'|'asking_question'|'waiting_for_answer'|'recording'|'reviewing_transcript'|'submitting'|'processing'|'completed'|'failed';
export type RecordingState = 'idle'|'requesting'|'recording'|'recorded'|'error';
export type SpeechRecognitionState = 'unsupported'|'idle'|'listening'|'stopping'|'error';

export interface InterviewQuestion { id:string; text:string; difficulty:AbilityBand; competencyTarget:Competency; stage:InterviewStage; }
export interface TranscriptSegment { text:string; final:boolean; confidence?:number; }
export interface CandidateAnswer { questionId:string; transcript:string; transcriptEdited:boolean; durationSeconds:number; clarificationRequired:boolean; submittedAt:string; }
export interface ScoredEvidence { score:number; evidence:string; }
export interface AnswerEvaluation {
  comprehension:ScoredEvidence; fluency:ScoredEvidence; grammar:ScoredEvidence; vocabulary:ScoredEvidence; coherence:ScoredEvidence; interaction:ScoredEvidence;
  pronunciation:{status:'not_assessed'|'assessed';score:number|null;evidence:string};
  observedErrors:Array<{category:'grammar'|'vocabulary'|'coherence'|'interaction';example:string;suggestedCorrection:string}>;
  strengths:string[]; improvementAreas:string[];
}
export interface EvaluationResponse { answerEvaluation:AnswerEvaluation;estimatedBand:AbilityBand;estimatedCefr:CefrLevel;nextAction:'ask_next_question'|'finish_interview';nextQuestion:InterviewQuestion|null;shouldFinish:boolean;finishReason:string; }
export interface ReportDimension {score:number;summary:string}
export interface FinalEnglishReport {
  estimatedCefr:CefrLevel;estimatedBand:AbilityBand;confidence:'low'|'medium'|'high';summary:string;
  dimensions:Record<Competency,ReportDimension>&{pronunciation:{status:'not_assessed'|'assessed';score:number|null;summary:string}};
  strengths:string[];improvementAreas:string[];representativeExamples:Array<{example:string;observation:string}>;recommendedCourseLevel:string;limitations:string[];
  interviewDurationSeconds?:number;questionsAnswered?:number;recommendedLearningObjectives?:string[];mockMode?:boolean;
}
export interface InterviewSession { id:string;status:InterviewStatus;language:'en-US'|'en-GB';startedAt:string;question:InterviewQuestion;questionNumber:number;answers:CandidateAnswer[];evaluations:EvaluationResponse[];report?:FinalEnglishReport; }

