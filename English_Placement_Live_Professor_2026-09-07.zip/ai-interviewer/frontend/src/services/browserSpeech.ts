import type { SpeechToTextService, TextToSpeechService } from './contracts';
import type { InterviewLanguage } from '../config';

interface RecognitionResultEventLike { resultIndex:number;results:ArrayLike<{isFinal:boolean;0:{transcript:string;confidence:number}}>; }
interface RecognitionErrorEventLike { error:string; }
interface RecognitionLike {lang:string;continuous:boolean;interimResults:boolean;onresult:((event:RecognitionResultEventLike)=>void)|null;onerror:((event:RecognitionErrorEventLike)=>void)|null;onend:(()=>void)|null;start():void;stop():void;abort():void;}
type RecognitionConstructor=new()=>RecognitionLike;

declare global { interface Window { SpeechRecognition?:RecognitionConstructor;webkitSpeechRecognition?:RecognitionConstructor; } }

const speechErrors:Record<string,string>={
  'no-speech':'No speech was detected. You can try again or type your answer.',
  'audio-capture':'No working microphone was found.',
  'not-allowed':'Microphone permission was denied. You can still type your answer.',
  'service-not-allowed':'Speech recognition permission was denied. You can still type your answer.',
  network:'Browser speech recognition could not reach its service. You can still type your answer.'
};

export class BrowserSpeechToTextService implements SpeechToTextService {
  private recognition:RecognitionLike|null=null;
  private active=false;
  readonly supported:boolean;
  constructor(private readonly language:InterviewLanguage){this.supported=Boolean(window.SpeechRecognition||window.webkitSpeechRecognition);}
  start(onSegment:(segment:{text:string;final:boolean;confidence?:number})=>void,onError:(message:string)=>void):void{
    if(this.active)return; const Constructor=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!Constructor){onError('Speech recognition is not supported in this browser. Type your answer instead.');return;}
    this.dispose(); const recognition=new Constructor(); this.recognition=recognition; this.active=true;
    recognition.lang=this.language; recognition.continuous=false; recognition.interimResults=true;
    recognition.onresult=event=>{for(let i=event.resultIndex;i<event.results.length;i+=1){const result=event.results[i];if(result)onSegment({text:result[0].transcript,final:result.isFinal,confidence:result[0].confidence});}};
    recognition.onerror=event=>{this.active=false;onError(speechErrors[event.error]||'Speech recognition stopped. You can continue by typing.');};
    recognition.onend=()=>{this.active=false;}; recognition.start();
  }
  stop():void{if(!this.active)return;this.active=false;try{this.recognition?.stop();}catch{this.recognition?.abort();}}
  dispose():void{this.active=false;if(this.recognition){this.recognition.onresult=null;this.recognition.onerror=null;this.recognition.onend=null;try{this.recognition.abort();}catch{ /* already stopped */ }}this.recognition=null;}
}

export function selectEnglishVoice(voices:SpeechSynthesisVoice[],language:InterviewLanguage):SpeechSynthesisVoice|undefined{
  return voices.find(v=>v.lang.toLowerCase()===language.toLowerCase())||voices.find(v=>v.lang.toLowerCase().startsWith('en'));
}
export class BrowserTextToSpeechService implements TextToSpeechService{
  readonly supported='speechSynthesis' in window;constructor(private readonly language:InterviewLanguage){}
  speak(text:string):void{if(!this.supported)return;this.stop();const utterance=new SpeechSynthesisUtterance(text);utterance.lang=this.language;utterance.voice=selectEnglishVoice(window.speechSynthesis.getVoices(),this.language)||null;utterance.rate=.94;window.speechSynthesis.speak(utterance);}
  stop():void{if(this.supported)window.speechSynthesis.cancel();}dispose():void{this.stop();}
}

