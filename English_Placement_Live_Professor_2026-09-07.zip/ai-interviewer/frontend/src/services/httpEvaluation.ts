import { evaluationResponseSchema, finalEnglishReportSchema } from '../assessment/schemas';
import type { InterviewEvaluationService } from './contracts';
import type { CandidateAnswer, EvaluationResponse, FinalEnglishReport, InterviewSession } from '../types';
export class HttpInterviewEvaluationService implements InterviewEvaluationService{
  constructor(private readonly baseUrl:string){}
  async evaluate(session:InterviewSession,answer:CandidateAnswer):Promise<EvaluationResponse>{const r=await fetch(`${this.baseUrl}/api/assessment/${session.id}/evaluate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(answer)});if(!r.ok)throw new Error('The evaluation service is temporarily unavailable.');return evaluationResponseSchema.parse(await r.json());}
  async createReport(session:InterviewSession):Promise<FinalEnglishReport>{const r=await fetch(`${this.baseUrl}/api/assessment/${session.id}/report`,{method:'POST'});if(!r.ok)throw new Error('The report service is temporarily unavailable.');return finalEnglishReportSchema.parse(await r.json());}
}
