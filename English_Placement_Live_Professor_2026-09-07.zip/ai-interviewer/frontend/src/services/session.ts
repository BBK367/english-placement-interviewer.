import { config, type InterviewLanguage } from '../config';
import type { InterviewSessionService } from './contracts';
import type { InterviewSession } from '../types';

const KEY='english-placement-session-v2';
export const firstQuestion={id:'warm-up-1',text:'Could you introduce yourself and tell me what you usually do during a normal week?',difficulty:'intermediate',competencyTarget:'interaction',stage:'warm_up'} as const;
export class BrowserInterviewSessionService implements InterviewSessionService{
  async create(language:InterviewLanguage):Promise<InterviewSession>{const session:InterviewSession={id:crypto.randomUUID(),status:'waiting_for_answer',language,startedAt:new Date().toISOString(),question:firstQuestion,questionNumber:1,answers:[],evaluations:[]};this.save(session);return session;}
  save(session:InterviewSession):void{sessionStorage.setItem(KEY,JSON.stringify(session));}
  load():InterviewSession|null{try{const value=sessionStorage.getItem(KEY);return value?JSON.parse(value) as InterviewSession:null;}catch{return null;}}
  clear():void{sessionStorage.removeItem(KEY);}
}
export const maxQuestions=config.maxQuestions;

