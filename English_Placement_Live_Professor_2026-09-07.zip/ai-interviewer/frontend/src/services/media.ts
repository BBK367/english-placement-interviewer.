import type { MediaUploadService } from './contracts';
import type { InterviewQuestion } from '../types';

export class LocalMediaService implements MediaUploadService { async upload():Promise<null>{return null;} }
export class HttpMediaUploadService implements MediaUploadService {
  constructor(private readonly baseUrl:string){}
  async upload(sessionId:string,question:InterviewQuestion,blob:Blob):Promise<{id:string}>{
    const response=await fetch(`${this.baseUrl}/api/live/${sessionId}/recordings/${question.id}`,{method:'POST',headers:{'Content-Type':blob.type},body:blob});
    if(!response.ok)throw new Error('The recording could not be uploaded.');return {id:question.id};
  }
}

