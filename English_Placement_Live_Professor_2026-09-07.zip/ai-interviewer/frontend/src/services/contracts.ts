import type { CandidateAnswer, EvaluationResponse, FinalEnglishReport, InterviewQuestion, InterviewSession, TranscriptSegment } from '../types';

export interface SpeechToTextService { supported:boolean;start(onSegment:(segment:TranscriptSegment)=>void,onError:(message:string)=>void):void;stop():void;dispose():void; }
export interface TextToSpeechService { supported:boolean;speak(text:string):void;stop():void;dispose():void; }
export interface InterviewEvaluationService { evaluate(session:InterviewSession,answer:CandidateAnswer):Promise<EvaluationResponse>;createReport(session:InterviewSession):Promise<FinalEnglishReport>; }
export interface MediaUploadService { upload(sessionId:string,question:InterviewQuestion,blob:Blob):Promise<{id:string}|null>; }
export interface InterviewSessionService { create(language:'en-US'|'en-GB'):Promise<InterviewSession>;save(session:InterviewSession):void;load():InterviewSession|null;clear():void; }

