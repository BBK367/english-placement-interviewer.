const allowedLanguages = ['en-US', 'en-GB'] as const;
export type InterviewLanguage = (typeof allowedLanguages)[number];

function numberSetting(value: string | undefined, fallback: number, min: number, max: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : fallback;
}

export function normaliseInterviewLanguage(value: string | undefined): InterviewLanguage {
  return allowedLanguages.includes(value as InterviewLanguage) ? value as InterviewLanguage : 'en-US';
}

export const config = {
  mockMode: import.meta.env.VITE_MOCK_MODE !== 'false',
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5001',
  interviewLanguage: normaliseInterviewLanguage(import.meta.env.VITE_INTERVIEW_LANGUAGE),
  maxQuestions: numberSetting(import.meta.env.VITE_MAX_QUESTIONS, 10, 8, 12),
  maxAnswerSeconds: numberSetting(import.meta.env.VITE_MAX_ANSWER_SECONDS, 180, 30, 180)
};

