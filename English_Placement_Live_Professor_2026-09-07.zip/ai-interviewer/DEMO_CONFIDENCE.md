# Demonstration confidence display

Start the application using the existing setup instructions, then open:

http://localhost:5001/?demoConfidence=1

This view displays a simulated high confidence of 90/100, explicitly labelled DEMO. The calculated confidence remains visible alongside it. Scores, CEFR placement, backend confidence and saved evidence are not changed. Without this URL parameter, the normal calculated confidence is shown.

This is a presentation mode, not a correction or validation of the assessment. Mac M1 execution and real-time voice latency have not been verified for this release. Dependencies and pretrained model assets must be installed/downloaded separately. No credentials or candidate recordings are included.
