# AI English Placement Interviewer

## Setup

1. Run `npm install`.
2. Create the database, then run `psql -d ai_interviewer -f database/schema.sql` and `psql -d ai_interviewer -f database/alter_assessment.sql`.
3. Copy `.env.example` to `.env` and configure AWS credentials and `BEDROCK_MODEL_ID` outside the browser.
4. Start with `npm start --workspace backend`.

Run contract tests with `npm test`. Run the live Bedrock smoke test with `node backend/test-assessor.js`.

## Six-question demo

The browser demo is served by the backend at `/`. It records candidate identity and consent in a temporary in-memory session, requests browser microphone access for live transcription, and supports typed answers as a fallback. Sessions are cleared whenever the server restarts.

With separate consent, the browser also records one audio clip per spoken answer. The local prototype retains each clip together with minimal review metadata (candidate, question, date and format) in `data/live-audio-archive`; the clips are not public static files. An administrator can play or permanently delete them at `/admin.html` using the server-only `LIVE_AUDIO_ADMIN_CODE`. This is local prototype storage only: Render Free has an ephemeral filesystem and must not be used for retained interview audio.

When a candidate opts into audio recording, every spoken answer must be recorded before it is sent. With the additional audio-analysis consent, the Node.js backend reads each saved answer from the local archive and sends a request-only copy to the optional self-hosted **pretrained MultiPA** pronunciation worker. Audio is never sent to Claude. MultiPA analyses the recorded signal for pronunciation accuracy, fluency and prosody, creates its own internal speech transcript for open responses, and returns advisory per-answer results. A worker failure always returns `not_assessed` rather than an invented score.

See [the free/open-source benchmark](docs/pronunciation-benchmark.md) for the comparison, test result and limitations.
For a simple, shareable explanation of the MultiPA paper, the current
architecture, validation plan and server requirements, see the
[MultiPA project review](docs/multipa-project-review.md).

## Optional pronunciation worker

The worker is experimental and intentionally separate from the Render Node.js service. It uses the free, open-source **MultiPA** research model with published pretrained weights; candidate recordings are not used for training. It requires Python, PyTorch, FFmpeg, Whisper, HuBERT and RoBERTa, so it is not suitable for Render Free.

To run it locally with Docker:

```bash
docker build -t pronunciation-worker pronunciation-worker
docker run --rm -p 8000:8000 pronunciation-worker
```

Then set this **server-only** environment variable before starting the backend:

```bash
PRONUNCIATION_WORKER_URL=http://localhost:8000
```

For a remote worker, set a long random `PRONUNCIATION_WORKER_API_KEY` both on
the Node.js backend and on the worker. The key is forwarded only server to
server; it is never included in browser code. Do not put this setting, audio,
AWS credentials, prompts or model identifiers in frontend code. The worker
accepts a maximum 8 MB / 120-second recording. A cold model can take a long time
to load; validate latency and human agreement before using it beyond the
prototype.

See [the Linux VM deployment guide](pronunciation-worker/DEPLOY_ORACLE_VM.md)
for the reusable Render + HTTPS worker architecture.
For a temporary Apple Silicon test machine, see the
[Mac mini M1 setup guide](pronunciation-worker/DEPLOY_MAC_MINI_M1.md).
To launch the complete Node.js demonstration and the worker together with one
Docker command, see [the full Docker demonstration guide](docs/run-full-demo-with-docker.md).

## Deploy to Render

This repository includes `render.yaml` for a free Render web service.

1. Create a new Render Blueprint from this GitHub repository.
2. Enter `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` in the Render dashboard when prompted.
3. Deploy and open the generated HTTPS URL. If temporary credentials are used later, add `AWS_SESSION_TOKEN` manually as a secret.

Never commit `.env`, AWS credentials, worker keys or exported credential files.
The free Render service sleeps after inactivity and all in-memory interview
sessions are lost on restart. Bedrock model calls remain chargeable to the
configured AWS account. The Python pronunciation worker is not deployed by
`render.yaml`; configure its HTTPS URL and matching server-only key only after
the separate worker VM is ready.
