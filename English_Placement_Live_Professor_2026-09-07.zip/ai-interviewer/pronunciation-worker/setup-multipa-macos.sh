#!/usr/bin/env bash
#
# Native Apple Silicon setup for the pretrained MultiPA worker.
# This script downloads published model weights only. It never downloads
# SpeechOcean training data and never trains a candidate-specific model.
#
set -eo pipefail

WORKER_ROOT="$(cd "$(dirname "$0")" && pwd)"
PYTHON_BIN="$MULTIPA_PYTHON"
if [[ -z "$PYTHON_BIN" ]]; then PYTHON_BIN="python3.9"; fi
set -u
VENV_DIR="$WORKER_ROOT/.venv-macos"
SOURCE_DIR="$WORKER_ROOT/vendor/MultiPA"
FAIRSEQ_DIR="$WORKER_ROOT/vendor/fairseq"
MODELS_DIR="$WORKER_ROOT/models"
MULTIPA_COMMIT="a8d83ec1d80f9db60e6d32227cb1c562ee5e6022"

if [[ "$(uname -s)" != "Darwin" || "$(uname -m)" != "arm64" ]]; then
  echo "This installer is intended for an Apple Silicon Mac (arm64)."
  exit 1
fi

if ! xcode-select -p >/dev/null 2>&1; then
  echo "Install Apple's command line tools first: xcode-select --install"
  exit 1
fi

for command in git ffmpeg "$PYTHON_BIN"; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "Missing $command. Install the prerequisites in DEPLOY_MAC_MINI_M1.md."
    exit 1
  fi
done

"$PYTHON_BIN" -m venv "$VENV_DIR"
PYTHON="$VENV_DIR/bin/python"

"$PYTHON" -m pip install --upgrade pip==24.0 setuptools==75.3.4 wheel
# The PyPI macOS/arm64 wheel includes the Apple Metal (MPS) backend.
"$PYTHON" -m pip install torch==2.2.2 torchaudio==2.2.2
"$PYTHON" -m pip install docopt-ng==0.9.0
"$PYTHON" -m pip install --no-deps num2words==0.5.13
"$PYTHON" -m pip install --no-build-isolation -r "$WORKER_ROOT/requirements.txt"
"$PYTHON" -m pip install Cython==0.29.36

if [[ ! -d "$FAIRSEQ_DIR/.git" ]]; then
  mkdir -p "$(dirname "$FAIRSEQ_DIR")"
  git clone --branch v0.12.2 --depth 1 --recurse-submodules https://github.com/facebookresearch/fairseq.git "$FAIRSEQ_DIR"
fi
git -C "$FAIRSEQ_DIR" fetch --depth 1 origin v0.12.2
git -C "$FAIRSEQ_DIR" checkout v0.12.2
# fairseq builds native extensions on macOS.
CFLAGS="-stdlib=libc++" "$PYTHON" -m pip install --no-build-isolation --no-deps "$FAIRSEQ_DIR"

if [[ ! -d "$SOURCE_DIR/.git" ]]; then
  mkdir -p "$(dirname "$SOURCE_DIR")"
  git clone https://github.com/yuwchen/MultiPA.git "$SOURCE_DIR"
fi
git -C "$SOURCE_DIR" fetch --depth 1 origin "$MULTIPA_COMMIT"
git -C "$SOURCE_DIR" checkout "$MULTIPA_COMMIT"
if git -C "$SOURCE_DIR" apply --check "$WORKER_ROOT/patches/multipa-cpu-device.patch"; then
  git -C "$SOURCE_DIR" apply "$WORKER_ROOT/patches/multipa-cpu-device.patch"
elif ! git -C "$SOURCE_DIR" apply --reverse --check "$WORKER_ROOT/patches/multipa-cpu-device.patch"; then
  echo "The MultiPA device patch does not match the pinned upstream source."
  exit 1
fi

NLTK_DATA="$MODELS_DIR/nltk_data"
"$PYTHON" -c "import nltk; data=r'$NLTK_DATA'; nltk.download('cmudict', download_dir=data); nltk.download('punkt', download_dir=data); nltk.download('averaged_perceptron_tagger', download_dir=data)"

export MULTIPA_SOURCE_DIR="$SOURCE_DIR"
export MULTIPA_MODELS_DIR="$MODELS_DIR"
export PYTORCH_ENABLE_MPS_FALLBACK=1
"$PYTHON" "$WORKER_ROOT/setup_multipa_assets.py"

"$PYTHON" - <<'PYTHON_CHECK'
import torch
print("PyTorch:", torch.__version__)
print("Apple Metal (MPS) available:", torch.backends.mps.is_available())
if not torch.backends.mps.is_available():
    raise SystemExit("MPS is unavailable. Update macOS/PyTorch or use PRONUNCIATION_DEVICE=cpu.")
PYTHON_CHECK

echo
echo "MultiPA is installed with published pretrained weights."
echo "Start it with:"
echo "  PYTORCH_ENABLE_MPS_FALLBACK=1 PRONUNCIATION_DEVICE=mps MULTIPA_SOURCE_DIR=$SOURCE_DIR MULTIPA_MODELS_DIR=$MODELS_DIR $PYTHON -m uvicorn app:app --host 127.0.0.1 --port 8000"
