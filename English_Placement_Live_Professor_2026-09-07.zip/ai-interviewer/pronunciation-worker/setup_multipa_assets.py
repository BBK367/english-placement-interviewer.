"""Download MultiPA's published inference assets; it never trains a model."""
from __future__ import annotations

import os
import shutil
import tarfile
import urllib.request
import zipfile
from pathlib import Path

from huggingface_hub import snapshot_download


HUBERT_URL = "https://dl.fbaipublicfiles.com/hubert/hubert_base_ls960.pt"
ROBERTA_URL = "https://dl.fbaipublicfiles.com/fairseq/models/roberta.base.tar.gz"


def models_dir() -> Path:
    return Path(os.getenv("MULTIPA_MODELS_DIR", Path(__file__).resolve().parent / "models")).expanduser().resolve()


def download(url: str, target: Path):
    if target.is_file() and target.stat().st_size > 0:
        print(f"Already present: {target.name}")
        return
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_suffix(f"{target.suffix}.partial")
    print(f"Downloading pretrained asset: {target.name}")
    try:
        urllib.request.urlretrieve(url, partial)
        partial.replace(target)
    finally:
        partial.unlink(missing_ok=True)


def extract_roberta(archive: Path, target: Path):
    if (target / "model.pt").is_file() and (target / "dict.txt").is_file():
        return
    staging = target.parent / ".roberta-staging"
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:gz") as package:
        root = staging.resolve()
        for member in package.getmembers():
            destination = (staging / member.name).resolve()
            if root not in destination.parents and destination != root:
                raise RuntimeError("Unsafe path in the published RoBERTa archive.")
        package.extractall(staging)
    model = next(staging.rglob("model.pt"), None)
    dictionary = next(staging.rglob("dict.txt"), None)
    if not model or not dictionary:
        raise RuntimeError("The published RoBERTa archive did not contain model.pt and dict.txt.")
    target.mkdir(parents=True, exist_ok=True)
    shutil.copy2(model, target / "model.pt")
    shutil.copy2(dictionary, target / "dict.txt")
    shutil.rmtree(staging, ignore_errors=True)


def extract_multipa_checkpoint(archive: Path, target: Path):
    """Copy the released `PRO/best` checkpoint out of its published zip."""
    if target.is_file():
        return
    if not archive.is_file():
        raise RuntimeError("The released MultiPA checkpoint archive was not downloaded.")
    with zipfile.ZipFile(archive) as package:
        member = next((item for item in package.namelist() if item.endswith("/PRO/best")), None)
        if not member:
            raise RuntimeError("The released MultiPA archive did not contain PRO/best.")
        target.parent.mkdir(parents=True, exist_ok=True)
        with package.open(member) as source, target.open("wb") as destination:
            shutil.copyfileobj(source, destination)


def main():
    root = models_dir()
    root.mkdir(parents=True, exist_ok=True)
    # Keep g2p-en's NLTK resources beside the persistent model cache. The
    # worker sets NLTK_DATA to this same directory at inference time, so a
    # Docker volume or service account never needs an implicit user-home
    # download during a candidate assessment.
    import nltk
    nltk_data = root / "nltk_data"
    for resource in ("cmudict", "punkt", "averaged_perceptron_tagger"):
        nltk.download(resource, download_dir=str(nltk_data), quiet=True)
    download(HUBERT_URL, root / "hubert_base_ls960.pt")
    roberta_archive = root / "roberta.base.tar.gz"
    download(ROBERTA_URL, roberta_archive)
    extract_roberta(roberta_archive, root / "roberta.base")
    checkpoint_dir = root / "multipa"
    checkpoint = checkpoint_dir / "PRO" / "best"
    if not checkpoint.is_file():
        print("Downloading released MultiPA assessment checkpoint from Hugging Face")
        snapshot_download(repo_id="yuwchen/multipa", local_dir=str(checkpoint_dir))
    extract_multipa_checkpoint(checkpoint_dir / "model_assessment_val9_r1.zip", checkpoint)
    if not checkpoint.is_file():
        raise RuntimeError("The MultiPA download completed but PRO/best was not found.")
    # Pre-fetch the compact English Whisper model used by the CPU prototype so
    # the first candidate answer does not trigger a download. A larger medium
    # model can be prefetched on a stronger server by setting MULTIPA_PRELOAD_MEDIUM=1.
    import whisper

    whisper_cache = root / "whisper-cache"
    whisper_models = ["base.en"]
    if os.getenv("MULTIPA_PRELOAD_MEDIUM") == "1":
        whisper_models.append("medium.en")
    for model_name in whisper_models:
        print(f"Downloading released Whisper checkpoint: {model_name}")
        whisper.load_model(model_name, download_root=str(whisper_cache))
    print("Pretrained MultiPA assets are ready. No training was performed.")


if __name__ == "__main__":
    main()
