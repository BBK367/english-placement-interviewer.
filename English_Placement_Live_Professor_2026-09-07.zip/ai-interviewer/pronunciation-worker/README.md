# Pretrained MultiPA pronunciation worker

This optional Python service gives the English Placement Interviewer an acoustic
pronunciation signal for **every consented recorded answer**. It uses the
published MultiPA research model for open English responses. MultiPA outputs
audio-based accuracy, fluency, prosody and word-level scores; Claude continues
to evaluate only the text for grammar, vocabulary, coherence and interaction.

No candidate recording is used to train the model. The setup downloads only
the released MultiPA checkpoint and its published HuBERT/RoBERTa/Whisper
dependencies. The browser never receives AWS credentials, model identifiers,
worker keys or prompt text. The audio is sent only from the Node backend to
this self-hosted worker and is decoded in a temporary directory.

## Important limits

- MultiPA is a research model, not Azure Pronunciation Assessment and not an
  official CEFR certification.
- It was benchmarked on short English learner recordings. The worker segments
  longer answers at Whisper's natural timestamped speech boundaries into pieces
  of at most 15 seconds, following the upstream recommendation. It combines
  the resulting numerical scores with a duration-weighted average. Fixed
  bounded windows are used only when Whisper cannot provide usable boundaries.
- It internally transcribes speech with Whisper in open-response mode. This is
  more suitable than relying only on the browser transcript, but recognition
  errors can still affect word-level feedback.
- The project applies CPU/Windows compatibility fixes to the upstream code.
  They do **not** change any pretrained model weight. The model takes roughly
  3 GB of RAM once warmed and CPU inference is slow; use a GPU or a stronger
  Linux server for a multi-candidate deployment.
- Scores remain advisory and must never cause an automatic recruitment
  rejection. Before production, compare a set of recordings with ratings from
  an English teacher or qualified reviewer.

## Recommended deployment: Linux VM + Docker

Use the VM instructions in [DEPLOY_ORACLE_VM.md](DEPLOY_ORACLE_VM.md). Docker
downloads the released model assets only once into the persistent model volume
on its first start:

```bash
cd pronunciation-worker
cp .env.example .env
docker compose up -d --build
curl https://pronunciation.example.com/health
```

`/health` returns `configured: true` once the released assets are present.
Warm the model before a demonstration:

```bash
curl -X POST https://pronunciation.example.com/warmup \
  -H "x-worker-api-key: YOUR_SERVER_ONLY_KEY"
```

### Docker modes

The standard Docker command creates a CPU-only worker:

```bash
docker compose up -d --build
```

For a Linux server with a compatible NVIDIA GPU and NVIDIA Container Toolkit,
use the GPU overlay. It installs CUDA-enabled PyTorch and exposes one GPU to
the worker:

```bash
docker compose -f docker-compose.yml -f docker-compose.gpu.yml up -d --build
docker compose -f docker-compose.yml -f docker-compose.gpu.yml exec pronunciation-worker python -c "import torch; print(torch.cuda.is_available())"
```

The command must print `True` before setting
`PRONUNCIATION_WORKER_URL` on the Node.js backend. The Linux Docker
configuration is not the Apple Silicon route; see the native M1 guide below.

## Apple Silicon test deployment

A Mac mini M1 with 16 GB unified memory can run a local prototype, but it is
not equivalent to an NVIDIA CUDA server. The worker now supports PyTorch's
Apple Metal (MPS) device; because MultiPA/Fairseq is a research stack, its
latency and compatibility must be benchmarked on the actual machine before a
live demonstration. Use the native macOS instructions in
[DEPLOY_MAC_MINI_M1.md](DEPLOY_MAC_MINI_M1.md), not the Linux Docker image.

## Native Windows prototype

The setup prefers a local Python 3.9 installation, then uses the bundled
runtime when present. Run:

```powershell
powershell -ExecutionPolicy Bypass -File .\pronunciation-worker\setup-multipa.ps1
powershell -ExecutionPolicy Bypass -File .\pronunciation-worker\start-local.ps1
```

The first command installs the public inference dependencies and downloads the
released weights plus local phoneme resources. It does **not** run training.
The second asks for a local archive administrator code, starts the worker on
`127.0.0.1:8000`, configures the Node backend to call it server-to-server, and
starts the website on `http://localhost:5004/`.
