# Deploy the pronunciation worker on a free Linux VM

This is a **prototype deployment** for the existing Node.js application on
Render. The browser never calls this VM directly: it sends the recording to
the Node.js backend, which then forwards it to the worker over HTTPS.

The worker is experimental, uses pretrained MultiPA to analyse each recorded
answer for audio accuracy, fluency and prosody, and must not be used as an
automatic rejection tool. MultiPA generates its own internal transcript for
open-response scoring; it does not train on candidate recordings.

## What the VM is for

AWS Bedrock evaluates the transcript. It does not run the open-source PyTorch
MultiPA model, so a separate machine is required for acoustic analysis. The
same worker can serve a small number of candidates sequentially. Start with a
2-CPU, 12-GB-RAM Linux VM for a CPU-only prototype; a compatible GPU gives a
much better response time.

Oracle Cloud's current Always Free offer is the first option to try. Capacity
is not guaranteed, and users must check the current terms and their chosen
region before creating anything.

## 1. Create the VM in Oracle Cloud

In the Oracle Cloud console, create an **Always Free eligible** Ubuntu 24.04
VM. If it is available in the chosen region, select `VM.Standard.A1.Flex` with
2 OCPUs and 12 GB memory. Add an SSH key. Do not place AWS credentials or the
worker API key in the VM name, tags or public notes.

Configure the network firewall/security list:

- TCP 22: only from the administrator's IP address.
- TCP 80 and TCP 443: public, so Caddy can obtain and renew an HTTPS
  certificate.
- Do **not** open TCP 8000. Docker keeps the Python worker private inside the
  VM.

## 2. Give the VM a DNS name

Create an `A` DNS record such as `pronunciation.example.com` pointing to the
VM public IPv4 address. A domain already controlled by the project or a
controlled free dynamic-DNS subdomain is sufficient. Wait until the DNS record
resolves before starting Caddy; HTTPS cannot be issued without it.

## 3. Install Docker on Ubuntu

Connect by SSH, then install Docker Engine and Docker Compose using Docker's
official Ubuntu instructions. Confirm the installation with:

```bash
docker --version
docker compose version
```

### Optional NVIDIA GPU host

For a responsive pronunciation demonstration, a Linux host with an NVIDIA GPU
is preferable. Install the NVIDIA driver and NVIDIA Container Toolkit on the
host, then verify Docker can see the GPU before deploying the project:

```bash
nvidia-smi
docker run --rm --gpus all nvidia/cuda:12.1.1-base-ubuntu22.04 nvidia-smi
```

Do not use this NVIDIA Docker path for a Mac mini M1. Apple Metal acceleration
requires the native macOS setup in [DEPLOY_MAC_MINI_M1.md](DEPLOY_MAC_MINI_M1.md).

Clone this repository on the VM and enter the worker folder:

```bash
git clone <the-private-project-repository-url> ai-interviewer
cd ai-interviewer/pronunciation-worker
```

For a private repository, use a deploy key or a short-lived GitHub token in
the SSH session. Do not save that token in this repository.

## 4. Configure and launch

Create the untracked deployment environment file:

```bash
cp .env.example .env
openssl rand -hex 32
nano .env
```

Set the DNS name and paste the generated random value:

```dotenv
PRONUNCIATION_WORKER_DOMAIN=pronunciation.example.com
PRONUNCIATION_WORKER_API_KEY=the-long-random-value
```

Build and start the two private services. Use the first command for CPU-only
deployment:

```bash
docker compose up -d --build
docker compose ps
curl https://pronunciation.example.com/health
```

For an NVIDIA GPU host, use the GPU Docker overlay instead:

```bash
docker compose -f docker-compose.yml -f docker-compose.gpu.yml up -d --build
docker compose -f docker-compose.yml -f docker-compose.gpu.yml exec pronunciation-worker python -c "import torch; assert torch.cuda.is_available(); print(torch.cuda.get_device_name(0))"
```

The first container start downloads the released pretrained MultiPA, HuBERT,
RoBERTa and Whisper assets and can take several minutes. The Docker volume
preserves this model cache through container restarts. No recording is stored
in the volume: audio remains in a temporary directory only while it is
assessed.

## 5. Connect Render to the worker

In Render, set these two **server-only environment variables** for the Node.js
service, then redeploy:

```dotenv
PRONUNCIATION_WORKER_URL=https://pronunciation.example.com
PRONUNCIATION_WORKER_API_KEY=the-same-long-random-value
```

The API key travels only between the Node.js backend and the VM. It is never
included in frontend JavaScript or sent to candidates.

## Verification and recovery

From the VM, inspect the logs after a first recording:

```bash
docker compose logs --tail=100 pronunciation-worker
docker compose logs --tail=100 caddy
```

If the worker is unavailable, the application correctly returns
`not_assessed`; it must never fabricate a pronunciation score. Keep the VM
small for the one-candidate prototype. Increase CPU/RAM or add a queue only
after real load testing demonstrates the need.
