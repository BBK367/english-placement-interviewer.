"""Adapter around the official pretrained MultiPA inference components.

The upstream project is installed separately at ``MULTIPA_SOURCE_DIR`` so this
application does not silently retrain or alter its published weights.  This
module only loads the released checkpoint and turns its 0-10 predictions into
the API's 0-100 advisory score format.
"""
from __future__ import annotations

import importlib
import os
import sys
import threading
import time
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np


SAMPLE_RATE = 16000
MAX_SEGMENT_SECONDS = 15
MIN_SEGMENT_SECONDS = 0.5


class MultiPAConfigurationError(RuntimeError):
    """The released model assets have not been installed on this worker."""


def _path_from_env(name: str, default: Path) -> Path:
    return Path(os.getenv(name, str(default))).expanduser().resolve()


def _score_as_percent(value) -> float:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return 0.0
    return round(max(0.0, min(10.0, value)) * 10, 1)


def fixed_windows(total_samples: int) -> List[Tuple[int, int]]:
    """Fallback only: return contiguous windows no longer than MultiPA allows."""
    maximum = SAMPLE_RATE * MAX_SEGMENT_SECONDS
    minimum = int(SAMPLE_RATE * MIN_SEGMENT_SECONDS)
    return [
        (offset, min(offset + maximum, total_samples))
        for offset in range(0, total_samples, maximum)
        if min(offset + maximum, total_samples) - offset >= minimum
    ]


def whisper_windows(segments, total_samples: int) -> List[Tuple[int, int, Optional[str]]]:
    """Group Whisper speech segments without cutting a spoken phrase.

    MultiPA's released inference path is intended for short recordings.  The
    worker therefore groups Whisper's own timestamped speech segments into
    windows of at most ``MAX_SEGMENT_SECONDS``.  A rare Whisper segment that
    is itself too long falls back to a bounded fixed window; it is re-
    transcribed later rather than reusing a partial transcript.
    """
    maximum = SAMPLE_RATE * MAX_SEGMENT_SECONDS
    minimum = int(SAMPLE_RATE * MIN_SEGMENT_SECONDS)
    parsed = []
    for segment in segments or []:
        try:
            start = max(0, min(total_samples, int(float(segment["start"]) * SAMPLE_RATE)))
            end = max(start, min(total_samples, int(float(segment["end"]) * SAMPLE_RATE)))
        except (KeyError, TypeError, ValueError):
            continue
        text = str(segment.get("text") or "").strip()
        if end - start >= minimum and text:
            parsed.append((start, end, text))

    if not parsed:
        return []

    windows = []
    group_start = group_end = None
    group_text = []

    def flush_group():
        nonlocal group_start, group_end, group_text
        if group_start is not None and group_end is not None and group_end - group_start >= minimum:
            windows.append((group_start, group_end, " ".join(group_text)))
        group_start = group_end = None
        group_text = []

    for start, end, text in parsed:
        if end - start > maximum:
            flush_group()
            # Whisper did not give us a safe boundary inside this unusually
            # long speech segment.  Keep the model's maximum instead of
            # silently feeding it an out-of-distribution recording.
            for window_start, window_end in fixed_windows(end - start):
                windows.append((start + window_start, start + window_end, None))
            continue
        if group_start is not None and end - group_start > maximum:
            flush_group()
        if group_start is None:
            group_start = start
        group_end = end
        group_text.append(text)
    flush_group()
    return windows


def resolve_device(torch, requested_device: str) -> str:
    """Choose CUDA first, then Apple Metal, then CPU.

    MultiPA is primarily validated with CUDA.  MPS support is intentionally
    opt-in/testable for Apple Silicon and always has a CPU fallback through
    PyTorch when an operator is unsupported.
    """
    requested_device = (requested_device or "auto").lower()
    if requested_device not in {"auto", "cpu", "cuda", "mps"}:
        raise MultiPAConfigurationError(
            "PRONUNCIATION_DEVICE must be one of auto, cpu, cuda or mps."
        )
    mps_backend = getattr(torch.backends, "mps", None)
    mps_available = bool(mps_backend and mps_backend.is_available())
    if requested_device == "cuda":
        if not torch.cuda.is_available():
            raise MultiPAConfigurationError("PRONUNCIATION_DEVICE is cuda but no compatible GPU is available.")
        return "cuda"
    if requested_device == "mps":
        if not mps_available:
            raise MultiPAConfigurationError(
                "PRONUNCIATION_DEVICE is mps but this macOS/PyTorch installation has no available Apple Metal device."
            )
        return "mps"
    if requested_device == "cpu":
        return "cpu"
    if torch.cuda.is_available():
        return "cuda"
    if mps_available:
        return "mps"
    return "cpu"


class MultiPAEngine:
    """Load MultiPA once and serialise predictions to protect small CPUs/GPUs."""

    def __init__(self):
        self.source_dir = _path_from_env(
            "MULTIPA_SOURCE_DIR", Path(__file__).resolve().parent / "vendor" / "MultiPA"
        )
        self.models_dir = _path_from_env(
            "MULTIPA_MODELS_DIR", Path(__file__).resolve().parent / "models"
        )
        self.hubert_path = _path_from_env(
            "MULTIPA_HUBERT_PATH", self.models_dir / "hubert_base_ls960.pt"
        )
        self.roberta_dir = _path_from_env("MULTIPA_ROBERTA_DIR", self.models_dir / "roberta.base")
        self.checkpoint_dir = _path_from_env("MULTIPA_CHECKPOINT_DIR", self.models_dir / "multipa")
        self._check_required_paths()

        # Keep Hugging Face / Charsiu downloads with the local worker models.
        # This avoids relying on a machine-wide user cache that may be blocked
        # when the worker is started from a service or another Windows account.
        huggingface_cache = self.models_dir / "huggingface-cache"
        huggingface_cache.mkdir(parents=True, exist_ok=True)
        # Explicitly override an inherited user cache.  In particular, an
        # existing ``TRANSFORMERS_CACHE`` may point to a directory that a
        # Windows service account cannot write to; ``setdefault`` would leave
        # that broken value in place.
        os.environ["HF_HOME"] = str(huggingface_cache)
        os.environ["TRANSFORMERS_CACHE"] = str(huggingface_cache)
        os.environ["XDG_CACHE_HOME"] = str(self.models_dir / "cache")
        nltk_data = self.models_dir / "nltk_data"
        nltk_data.mkdir(parents=True, exist_ok=True)
        # g2p-en (used by the phoneme aligner) attempts an implicit NLTK
        # download when this resource is absent.  Keeping its data beside the
        # worker avoids an inaccessible per-user AppData folder.
        os.environ["NLTK_DATA"] = str(nltk_data)

        # Imports are deliberately lazy: /health must remain inexpensive and a
        # Node-only deployment must not fail just by importing FastAPI.
        if str(self.source_dir) not in sys.path:
            sys.path.insert(0, str(self.source_dir))
        try:
            import torch
            import fairseq
            import whisper
            from fairseq.models.roberta import RobertaModel
            from Charsiu import charsiu_forced_aligner
            from model_assessment import PronunciationPredictor
            import utils_assessment
        except ImportError as error:
            raise MultiPAConfigurationError(
                "MultiPA Python dependencies are not installed. Run the worker setup before enabling pronunciation analysis."
            ) from error

        self.torch = torch
        self.fairseq = fairseq
        self.whisper = whisper
        self.RobertaModel = RobertaModel
        self.charsiu_forced_aligner = charsiu_forced_aligner
        self.PronunciationPredictor = PronunciationPredictor
        self.utils = utils_assessment
        self.device = torch.device(resolve_device(torch, os.getenv("PRONUNCIATION_DEVICE", "auto")))
        if self.device.type == "cpu":
            available_threads = os.cpu_count() or 1
            requested_threads = int(os.getenv("MULTIPA_CPU_THREADS", min(8, available_threads)))
            torch.set_num_threads(max(1, min(requested_threads, available_threads)))
            try:
                torch.set_num_interop_threads(1)
            except RuntimeError:
                # PyTorch permits this setting only before any parallel work;
                # it is still safe to continue with its existing setting.
                pass
        self._predict_lock = threading.Lock()
        self._load_models()

    @classmethod
    def required_paths_present(cls) -> bool:
        source_dir = _path_from_env(
            "MULTIPA_SOURCE_DIR", Path(__file__).resolve().parent / "vendor" / "MultiPA"
        )
        models_dir = _path_from_env("MULTIPA_MODELS_DIR", Path(__file__).resolve().parent / "models")
        hubert_path = _path_from_env("MULTIPA_HUBERT_PATH", models_dir / "hubert_base_ls960.pt")
        roberta_dir = _path_from_env("MULTIPA_ROBERTA_DIR", models_dir / "roberta.base")
        checkpoint_dir = _path_from_env("MULTIPA_CHECKPOINT_DIR", models_dir / "multipa")
        return all((
            (source_dir / "model_assessment.py").is_file(),
            hubert_path.is_file(),
            (roberta_dir / "model.pt").is_file(),
            (roberta_dir / "dict.txt").is_file(),
            (checkpoint_dir / "PRO" / "best").is_file(),
        ))

    def _check_required_paths(self):
        if self.required_paths_present():
            return
        raise MultiPAConfigurationError(
            "The pretrained MultiPA assets are not installed yet. Run pronunciation-worker/setup-multipa.ps1 "
            "or deploy the MultiPA Docker worker; no model training is required."
        )

    def _load_models(self):
        torch = self.torch
        self.word_model = self.RobertaModel.from_pretrained(str(self.roberta_dir), checkpoint_file="model.pt")
        self.word_model.eval()
        whisper_cache = str(self.models_dir / "whisper-cache")
        short_model_name = os.getenv("MULTIPA_WHISPER_SHORT_MODEL", "base.en")
        segment_model_name = os.getenv("MULTIPA_WHISPER_SEGMENT_MODEL", "base.en")
        self.whisper_model_short = self.whisper.load_model(
            short_model_name, device=self.device, download_root=whisper_cache
        )
        # On the CPU prototype both roles normally use base.en.  Reuse the
        # loaded model rather than keeping two identical 145 MB copies.
        self.whisper_model_segments = (
            self.whisper_model_short if segment_model_name == short_model_name
            else self.whisper.load_model(
                segment_model_name, device=self.device, download_root=whisper_cache
            )
        )
        self.alignment_model = self.charsiu_forced_aligner(aligner="charsiu/en_w2v2_fc_10ms")
        ssl_model, _, _ = self.fairseq.checkpoint_utils.load_model_ensemble_and_task([str(self.hubert_path)])
        self.assessment_model = self.PronunciationPredictor(ssl_model[0], 768, 768).to(self.device)
        self.assessment_model.eval()
        state = torch.load(self.checkpoint_dir / "PRO" / "best", map_location=self.device)
        self.assessment_model.load_state_dict(state)

    def _transcript(self, waveform, whisper_model):
        return self.utils.get_transcript(waveform, whisper_model)

    def _normalise_transcript(self, transcript):
        return self.utils.convert_num_to_word(
            self.utils.remove_pun_except_apostrophe(str(transcript or "")).lower()
        )

    def _split(self, waveform):
        if waveform.size <= SAMPLE_RATE * MAX_SEGMENT_SECONDS:
            return [(waveform, None)]
        try:
            # Reuse the segment model that MultiPA already loads.  Its
            # timestamped speech boundaries avoid fixed cuts through words or
            # sentences, and its text can be reused as the target transcript
            # when this is the same model as the short-transcript model.
            transcript_result = self.utils.get_transcript(
                waveform, self.whisper_model_segments, return_seg=True
            )
            windows = whisper_windows(transcript_result.get("segments"), waveform.size)
            if windows:
                return [
                    (waveform[start:end], transcript)
                    for start, end, transcript in windows
                ]
        except Exception as error:
            print(f"Whisper segmentation unavailable; using bounded fallback: {type(error).__name__}", flush=True)

        # Preserve the maximum supported recording length even if Whisper is
        # temporarily unavailable.  These fallback windows are re-transcribed
        # by MultiPA, so no partial text is trusted.
        return [(waveform[start:end], None) for start, end in fixed_windows(waveform.size)]

    def _infer_segment(self, waveform, segment_transcript=None):
        torch = self.torch
        timing_started = time.perf_counter()

        def timing(label):
            if os.getenv("MULTIPA_DEBUG_TIMING") == "1":
                elapsed = time.perf_counter() - timing_started
                print(f"MultiPA {label}: {elapsed:.1f}s", flush=True)

        timing("segment started")
        target_transcript = self._normalise_transcript(segment_transcript)
        if not target_transcript:
            target_transcript = self._normalise_transcript(
                self._transcript(waveform, self.whisper_model_segments)
            )
        perceived_transcript = target_transcript if self.whisper_model_segments is self.whisper_model_short else self._normalise_transcript(
            self._transcript(waveform, self.whisper_model_short)
        )
        if not target_transcript.strip() or not perceived_transcript.strip():
            raise RuntimeError("MultiPA could not obtain an internal speech transcript.")
        timing("transcript ready")
        (
            predicted_words,
            phone_features,
            word_features,
            phone_vectors,
            target_word_embeddings,
            perceived_word_embeddings,
            word_phone_map,
        ) = self.utils.feature_extraction(
            waveform, target_transcript, perceived_transcript,
            alignment_model=self.alignment_model, word_model=self.word_model,
        )
        timing("phoneme features ready")
        if len(predicted_words) == 0:
            raise RuntimeError("MultiPA could not align the spoken words to audio.")
        word_times = [[
            (int(float(word[0]) * SAMPLE_RATE), int(float(word[1]) * SAMPLE_RATE))
            for word in predicted_words
        ]]
        signal = torch.from_numpy(np.asarray(waveform, dtype=np.float32)).reshape(1, -1).to(self.device)
        inputs = [
            torch.from_numpy(array).float().unsqueeze(0).to(self.device)
            for array in (perceived_word_embeddings, target_word_embeddings, phone_features, word_features, phone_vectors)
        ]
        perceived_embeddings, target_embeddings, phone_features, word_features, phone_vectors = inputs
        with torch.no_grad():
            scores = self.assessment_model(
                signal, perceived_embeddings, target_embeddings, phone_features, word_features,
                phone_vectors, [word_phone_map], word_times,
            )
        timing("acoustic score ready")
        utterance_accuracy, utterance_fluency, utterance_prosody, utterance_total, word_accuracy, word_stress, word_total = scores
        words = [str(word[-1]).lower() for word in predicted_words]
        def values(tensor):
            return np.asarray(tensor.detach().cpu().numpy()).reshape(-1).tolist()
        return {
            "duration": waveform.size / SAMPLE_RATE,
            "accuracy": _score_as_percent(values(utterance_accuracy)[0]),
            "fluency": _score_as_percent(values(utterance_fluency)[0]),
            "prosody": _score_as_percent(values(utterance_prosody)[0]),
            "total": _score_as_percent(values(utterance_total)[0]),
            "words": words,
            "word_accuracy": [_score_as_percent(item) for item in values(word_accuracy)],
            "word_stress": [_score_as_percent(item) for item in values(word_stress)],
            "word_total": [_score_as_percent(item) for item in values(word_total)],
        }

    def assess(self, waveform, _duration_seconds):
        waveform = np.asarray(waveform, dtype=np.float32).reshape(-1)
        if waveform.size < SAMPLE_RATE // 2:
            return {"status": "not_assessed", "evidence": "The recording is too short for MultiPA to analyse reliably."}
        recording_duration = waveform.size / SAMPLE_RATE
        skipped_reasons = []
        with self._predict_lock:
            segment_results = []
            for segment, segment_transcript in self._split(waveform):
                try:
                    segment_results.append(self._infer_segment(segment, segment_transcript))
                except Exception as error:
                    skipped_reasons.append(f"{type(error).__name__}: {error}")
                    print(f"MultiPA segment skipped: {type(error).__name__}: {error}", flush=True)
            if self.device.type == "cuda":
                self.torch.cuda.empty_cache()
            elif self.device.type == "mps" and hasattr(self.torch, "mps") and hasattr(self.torch.mps, "empty_cache"):
                self.torch.mps.empty_cache()
        if not segment_results:
            return {"status": "not_assessed", "evidence": "MultiPA could not analyse enough intelligible speech in this answer."}

        weight = sum(item["duration"] for item in segment_results)
        def weighted(metric):
            return round(sum(item[metric] * item["duration"] for item in segment_results) / weight, 1)
        observations = []
        recognised_words = 0
        for item in segment_results:
            for word, accuracy, stress, total in zip(item["words"], item["word_accuracy"], item["word_stress"], item["word_total"]):
                if word:
                    recognised_words += 1
                    observations.append({
                        "word": word, "accuracyScore": accuracy,
                        "stressScore": stress, "totalScore": total,
                    })
        observations.sort(key=lambda item: item["totalScore"])
        analysed_duration = sum(item["duration"] for item in segment_results)
        # Keep pauses from the complete answer in the speaking-rate signal.
        # The score itself remains duration-weighted across only the assessed
        # speech windows, so a long silence cannot invent a pronunciation
        # score but is still visible in the fluency evidence.
        speaking_rate = round(recognised_words * 60 / recording_duration, 1) if recording_duration else None
        accuracy = weighted("accuracy")
        fluency = weighted("fluency")
        prosody = weighted("prosody")
        suggestions = []
        if accuracy < 65:
            suggestions.append("Repeat a few short parts more slowly and focus on making each word understandable.")
        if fluency < 65:
            suggestions.append("Use short pauses between ideas, then practise linking words at a comfortable pace.")
        if prosody < 65:
            suggestions.append("Practise stressing the important words in each sentence and vary your intonation naturally.")
        return {
            "status": "assessed",
            "engine": "multipa",
            "recordedDuration": recording_duration,
            "analyzedDuration": analysed_duration,
            "analyzedSegments": len(segment_results),
            "skippedSegments": len(skipped_reasons),
            "skippedReasons": skipped_reasons[:8],
            "score": weighted("total"),
            "accuracyScore": accuracy,
            "prosodyScore": prosody,
            "wordObservations": observations[:8],
            "phonemeErrors": [],
            "fluency": {
                "speakingRate": speaking_rate,
                "rhythmScore": fluency,
                "monotonyScore": None,
            },
            "suggestions": suggestions[:3],
            "evidence": (
                "Pretrained MultiPA open-response result based on the recorded audio. "
                f"Whisper divided this answer into {len(segment_results)} speech segment(s) of at most "
                f"{MAX_SEGMENT_SECONDS} seconds ({round(analysed_duration, 1)} seconds analysed from "
                f"{round(recording_duration, 1)} seconds recorded). It creates internal speech transcripts and is "
                "an experimental pre-screening signal, not a certification."
            ),
        }
