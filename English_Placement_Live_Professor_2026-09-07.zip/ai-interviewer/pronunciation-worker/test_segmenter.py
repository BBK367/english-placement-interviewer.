"""Fast unit tests for the Whisper-aware MultiPA segmentation policy."""

import unittest
import sys
from pathlib import Path
import numpy as np

# Allow this fast unit test to run from the repository root or the worker
# directory without loading any model assets.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from multipa_engine import (
    MAX_SEGMENT_SECONDS, SAMPLE_RATE, MultiPAConfigurationError,
    MultiPAEngine, resolve_device, whisper_windows,
)


class WhisperWindowTests(unittest.TestCase):
    def test_nearby_whisper_segments_are_grouped_without_crossing_the_limit(self):
        windows = whisper_windows([
            {"start": 0.0, "end": 4.0, "text": "Hello"},
            {"start": 4.3, "end": 9.0, "text": "my name is Alex"},
            {"start": 9.2, "end": 14.8, "text": "and I work in sales"},
        ], 20 * SAMPLE_RATE)
        self.assertEqual(len(windows), 1)
        start, end, transcript = windows[0]
        self.assertEqual((start, end), (0, int(14.8 * SAMPLE_RATE)))
        self.assertEqual(transcript, "Hello my name is Alex and I work in sales")

    def test_a_natural_boundary_starts_a_new_window_before_the_limit_is_crossed(self):
        windows = whisper_windows([
            {"start": 0.0, "end": 10.0, "text": "First sentence"},
            {"start": 10.5, "end": 18.0, "text": "Second sentence"},
        ], 20 * SAMPLE_RATE)
        self.assertEqual(len(windows), 2)
        self.assertEqual(windows[0][2], "First sentence")
        self.assertEqual(windows[1][2], "Second sentence")
        self.assertTrue(all(end - start <= MAX_SEGMENT_SECONDS * SAMPLE_RATE for start, end, _ in windows))

    def test_an_unusually_long_whisper_segment_keeps_the_model_limit(self):
        windows = whisper_windows([
            {"start": 2.0, "end": 20.0, "text": "A very long uninterrupted sentence"},
        ], 22 * SAMPLE_RATE)
        self.assertEqual(len(windows), 2)
        self.assertEqual(windows[0], (2 * SAMPLE_RATE, 17 * SAMPLE_RATE, None))
        self.assertEqual(windows[1], (17 * SAMPLE_RATE, 20 * SAMPLE_RATE, None))

    def test_engine_uses_whisper_timestamps_instead_of_fixed_15_second_cuts(self):
        class FakeUtils:
            @staticmethod
            def get_transcript(_waveform, _model, return_seg=False):
                self.assertTrue(return_seg)
                return {"segments": [
                    {"start": 0.0, "end": 9.0, "text": "First natural phrase"},
                    {"start": 9.5, "end": 18.0, "text": "Second natural phrase"},
                ]}

        engine = object.__new__(MultiPAEngine)
        engine.utils = FakeUtils()
        engine.whisper_model_segments = object()
        output = engine._split(np.zeros(21 * SAMPLE_RATE, dtype=np.float32))
        self.assertEqual(len(output), 2)
        self.assertEqual(output[0][1], "First natural phrase")
        self.assertEqual(output[1][1], "Second natural phrase")
        self.assertEqual(len(output[0][0]), 9 * SAMPLE_RATE)
        self.assertEqual(len(output[1][0]), int(8.5 * SAMPLE_RATE))

    def test_device_selection_prefers_cuda_then_apple_metal_then_cpu(self):
        class FakeMps:
            @staticmethod
            def is_available():
                return True

        class FakeCuda:
            @staticmethod
            def is_available():
                return False

        class FakeTorch:
            cuda = FakeCuda()

            class backends:
                mps = FakeMps()

        self.assertEqual(resolve_device(FakeTorch(), "auto"), "mps")
        self.assertEqual(resolve_device(FakeTorch(), "cpu"), "cpu")
        with self.assertRaises(MultiPAConfigurationError):
            resolve_device(FakeTorch(), "cuda")


if __name__ == "__main__":
    unittest.main()
