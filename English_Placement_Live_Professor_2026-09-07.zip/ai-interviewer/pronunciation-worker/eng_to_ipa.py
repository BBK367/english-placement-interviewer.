"""English text to IPA adapter for the local pronunciation worker.

``pronounce-assess`` expects the old :mod:`eng_to_ipa` package.  This small
drop-in replacement uses CMUdict, which is bundled with the local worker, to
phonemise the *candidate transcript* for each answer.  Unknown words are
marked with ``*`` because pronounce-assess deliberately ignores those words.
That makes the resulting score an experimental transcript-aligned signal, not
an assessment of words the worker could not map to phonemes.
"""
from __future__ import annotations

import re
from functools import lru_cache

import cmudict


_WORD = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?")
_STRESS = re.compile(r"\d")

# CMUdict uses ARPAbet.  The wav2vec2 TIMIT model used by pronounce-assess
# accepts the corresponding IPA-like symbols below (the upstream package also
# normalises a few equivalent variants during matching).
_ARPABET_TO_IPA = {
    "AA": "\u0251", "AE": "\u00e6", "AH": "\u0259", "AO": "\u0251", "AW": "a\u028a",
    "AY": "a\u026a", "B": "b", "CH": "t\u0283", "D": "d", "DH": "\u00f0",
    "EH": "\u025b", "ER": "\u0259r", "EY": "e\u026a", "F": "f", "G": "g",
    "HH": "h", "IH": "\u026a", "IY": "i", "JH": "d\u0292", "K": "k",
    "L": "l", "M": "m", "N": "n", "NG": "\u014b", "OW": "o\u028a",
    "OY": "\u0254\u026a", "P": "p", "R": "r", "S": "s", "SH": "\u0283",
    "T": "t", "TH": "\u03b8", "UH": "\u028a", "UW": "u", "V": "v",
    "W": "w", "Y": "j", "Z": "z", "ZH": "\u0292",
}


@lru_cache(maxsize=1)
def _dictionary():
    return cmudict.dict()


def _pronunciation_for(word: str):
    """Find the most common CMUdict pronunciation for a transcript word."""
    dictionary = _dictionary()
    candidates = [word.lower()]
    # CMUdict commonly contains the base word but not every spoken contraction.
    if word.lower().endswith("'s"):
        candidates.append(word[:-2].lower())
    if word.lower().endswith("n't"):
        candidates.append(word[:-3].lower())
    for candidate in candidates:
        pronunciations = dictionary.get(candidate)
        if pronunciations:
            return pronunciations[0]
    return None


def _to_ipa(pronunciation):
    return "".join(
        _ARPABET_TO_IPA.get(_STRESS.sub("", phoneme), "")
        for phoneme in pronunciation
    )


def phonemize(text: str):
    """Return ``(ipa, recognised_word_count, word_count)`` for English text."""
    words = _WORD.findall(str(text or ""))
    converted = []
    recognised = 0
    for word in words:
        pronunciation = _pronunciation_for(word)
        if pronunciation:
            ipa = _to_ipa(pronunciation)
            if ipa:
                converted.append(ipa)
                recognised += 1
                continue
        # The upstream package discards tokens ending in '*'.
        converted.append(f"{word.lower()}*")
    return " ".join(converted), recognised, len(words)


def convert(text, keep_punct=False, stress_marks=None):
    """Compatibility API used by pronounce-assess.

    ``keep_punct`` and ``stress_marks`` are accepted for the upstream API but
    are intentionally not used: the worker needs a stable phoneme sequence.
    """
    ipa, _recognised, _total = phonemize(text)
    return ipa
