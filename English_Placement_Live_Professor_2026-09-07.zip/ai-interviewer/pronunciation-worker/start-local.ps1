$ErrorActionPreference = 'Stop'

$workerRoot = $PSScriptRoot
$projectRoot = Split-Path -Parent $workerRoot
$fullPython = Join-Path $env:LocalAppData 'Programs\Python\Python39\python.exe'
$bundledPython = Join-Path $workerRoot 'runtime\python38\python.exe'
$venvPython = Join-Path $workerRoot '.venv\Scripts\python.exe'
$workerPython = if (Test-Path -LiteralPath $fullPython) { $fullPython } elseif (Test-Path -LiteralPath $bundledPython) { $bundledPython } else { $venvPython }
$multipaSource = Join-Path $workerRoot 'vendor\MultiPA'
$modelsPath = Join-Path $workerRoot 'models'
$backendRoot = Join-Path $projectRoot 'backend'

if (-not (Test-Path -LiteralPath $workerPython)) {
  throw 'MultiPA is not installed. Run pronunciation-worker\setup-multipa.ps1 first.'
}
if (-not (Test-Path -LiteralPath (Join-Path $multipaSource 'model_assessment.py')) -or -not (Test-Path -LiteralPath (Join-Path $modelsPath 'multipa\PRO\best'))) {
  throw 'The pretrained MultiPA assets are not installed. Run pronunciation-worker\setup-multipa.ps1 first.'
}

if (-not $env:LIVE_AUDIO_ADMIN_CODE) {
  $secureArchiveCode = Read-Host 'Choose a local audio archive administrator code' -AsSecureString
  $archiveCodePointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureArchiveCode)
  try {
    $env:LIVE_AUDIO_ADMIN_CODE = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($archiveCodePointer)
  } finally {
    [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($archiveCodePointer)
  }
  if ([string]::IsNullOrWhiteSpace($env:LIVE_AUDIO_ADMIN_CODE)) {
    throw 'A local audio archive administrator code is required to start the prototype.'
  }
}

$env:PRONUNCIATION_ENGINE = 'multipa'
$env:PRONUNCIATION_DEVICE = 'cpu'
$env:PRONUNCIATION_TIMEOUT_MS = '300000'
if (-not $env:MULTIPA_CPU_THREADS) { $env:MULTIPA_CPU_THREADS = [string][Math]::Min(8, [Environment]::ProcessorCount) }
$env:MULTIPA_SOURCE_DIR = $multipaSource
$env:MULTIPA_MODELS_DIR = $modelsPath
$worker = Start-Process -FilePath $workerPython `
  -ArgumentList @('-m', 'uvicorn', 'app:app', '--host', '127.0.0.1', '--port', '8000') `
  -WorkingDirectory $workerRoot -WindowStyle Hidden -PassThru

$env:PORT = '5004'
$env:PRONUNCIATION_WORKER_URL = 'http://127.0.0.1:8000'
$backend = Start-Process -FilePath 'npm.cmd' -ArgumentList 'start' `
  -WorkingDirectory $backendRoot -WindowStyle Hidden -PassThru

Write-Host 'Pronunciation worker started (PID' $worker.Id ').'
Write-Host 'Interview website started (PID' $backend.Id ').'
Write-Host 'Open http://localhost:5004/'
Write-Host 'Open http://localhost:5004/admin.html to review or delete retained recordings.'
