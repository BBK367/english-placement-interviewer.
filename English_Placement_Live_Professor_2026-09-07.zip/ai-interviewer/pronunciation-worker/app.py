"""Self-hosted API for pretrained MultiPA pronunciation assessment.

The audio stays on this worker.  The Node backend sends an answer recording,
not the AWS credentials or any Bedrock prompt.  MultiPA produces advisory
audio scores only; it is never used as an automatic employment decision.
"""
import os
import secrets
import subprocess
import tempfile
from functools import lru_cache
from pathlib import Path
from typing import Optional

import imageio_ffmpeg
import librosa
from fastapi import FastAPI, Header, HTTPException, Request

from multipa_engine import MultiPAConfigurationError, MultiPAEngine


app = FastAPI(title="Pretrained MultiPA pronunciation worker")
MAX_BYTES = 8 * 1024 * 1024
MAX_DURATION_SECONDS = 120


def suffix_for(content_type: str):
    content_type = (content_type or "").lower()
    if "ogg" in content_type:
        return ".ogg"
    if "mp4" in content_type or "m4a" in content_type:
        return ".m4a"
    if "wav" in content_type:
        return ".wav"
    return ".webm"


def worker_is_configured():
    return MultiPAEngine.required_paths_present()


@lru_cache(maxsize=1)
def engine():
    return MultiPAEngine()


def authenticate_worker(x_worker_api_key: Optional[str]):
    """Require a server-to-server key whenever one has been configured."""
    expected_key = os.getenv("PRONUNCIATION_WORKER_API_KEY")
    if expected_key and not secrets.compare_digest(x_worker_api_key or "", expected_key):
        raise HTTPException(status_code=401, detail="Invalid pronunciation worker credentials.")


@app.get("/health")
def health():
    return {
        "status": "ok",
        "engine": "multipa",
        "mode": "pretrained-open-response-per-answer",
        "configured": worker_is_configured(),
    }


@app.post("/warmup")
def warmup(x_worker_api_key: Optional[str] = Header(default=None)):
    authenticate_worker(x_worker_api_key)
    try:
        engine()
    except MultiPAConfigurationError as error:
        raise HTTPException(status_code=503, detail=str(error)) from error
    return {"status": "ready", "engine": "multipa", "mode": "pretrained-open-response-per-answer"}


@app.post("/assess")
async def assess(request: Request, x_worker_api_key: Optional[str] = Header(default=None)):
    authenticate_worker(x_worker_api_key)
    audio = await request.body()
    if not audio or len(audio) > MAX_BYTES:
        raise HTTPException(status_code=400, detail="Audio must be between 1 byte and 8 MB.")

    with tempfile.TemporaryDirectory() as temporary_directory:
        source = Path(temporary_directory) / f"recording{suffix_for(request.headers.get('content-type', ''))}"
        decoded = Path(temporary_directory) / "converted.wav"
        source.write_bytes(audio)
        try:
            subprocess.run(
                [imageio_ffmpeg.get_ffmpeg_exe(), "-y", "-i", str(source), "-ac", "1", "-ar", "16000", str(decoded)],
                check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=30,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as error:
            raise HTTPException(status_code=400, detail="The response audio could not be decoded.") from error

        waveform, _ = librosa.load(decoded, sr=16000, mono=True)
        duration_seconds = waveform.size / 16000
        if waveform.size == 0 or duration_seconds > MAX_DURATION_SECONDS:
            raise HTTPException(
                status_code=400,
                detail=f"Audio must contain speech and be at most {MAX_DURATION_SECONDS} seconds long.",
            )
        try:
            return engine().assess(waveform, duration_seconds)
        except MultiPAConfigurationError as error:
            return {"status": "not_assessed", "evidence": str(error)}
        except Exception as error:  # Do not manufacture a score after a model failure.
            print(f"MultiPA assessment failed: {type(error).__name__}: {error}", flush=True)
            return {
                "status": "not_assessed",
                "evidence": "The pretrained MultiPA model could not produce a stable result for this recording.",
            }
