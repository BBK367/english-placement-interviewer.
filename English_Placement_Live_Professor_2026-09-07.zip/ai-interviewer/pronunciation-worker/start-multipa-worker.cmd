@echo off
setlocal

set "WORKER_DIR=%~dp0"
set "PYTHON=%LOCALAPPDATA%\Programs\Python\Python39\python.exe"
if not exist "%PYTHON%" set "PYTHON=%WORKER_DIR%runtime\python38\python.exe"
if not exist "%PYTHON%" (
  echo MultiPA Python runtime was not found. Run setup-multipa.ps1 first.
  exit /b 1
)

if "%PRONUNCIATION_PORT%"=="" set "PRONUNCIATION_PORT=8000"
if "%PRONUNCIATION_DEVICE%"=="" set "PRONUNCIATION_DEVICE=cpu"
set "MULTIPA_SOURCE_DIR=%WORKER_DIR%vendor\MultiPA"
set "MULTIPA_MODELS_DIR=%WORKER_DIR%models"
set "HF_HOME=%MULTIPA_MODELS_DIR%\huggingface-cache"
set "TRANSFORMERS_CACHE=%HF_HOME%"
set "XDG_CACHE_HOME=%MULTIPA_MODELS_DIR%\cache"
if not exist "%HF_HOME%" mkdir "%HF_HOME%"
if not exist "%XDG_CACHE_HOME%" mkdir "%XDG_CACHE_HOME%"

cd /d "%WORKER_DIR%"
"%PYTHON%" -m uvicorn app:app --host 127.0.0.1 --port %PRONUNCIATION_PORT%
