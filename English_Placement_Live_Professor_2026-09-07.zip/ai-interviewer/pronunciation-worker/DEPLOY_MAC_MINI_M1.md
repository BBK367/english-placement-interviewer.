# Run the pretrained MultiPA worker on a Mac mini M1 (16 GB)

## Honest expectation

A Mac mini M1 with 16 GB unified memory can be a good **prototype and test**
machine. Its eight-core Apple GPU is not an NVIDIA CUDA GPU: it uses Apple's
Metal backend (MPS). The worker now supports the MPS device, but MultiPA and
Fairseq were primarily developed around CPU/CUDA environments. Treat MPS as a
benchmarkable option, not a performance guarantee.

Do not use the Linux Docker image on this Mac for MPS acceleration. Docker
containers on macOS do not expose the Apple Metal GPU in the same way as a
native macOS Python process. Use the native setup below.

## What this machine needs

- macOS 14 or later recommended;
- 16 GB unified memory;
- 40 GB free disk space for Python packages, models and caches;
- internet access for the first model download;
- Xcode Command Line Tools;
- Homebrew;
- no AWS credentials are needed on this machine when it runs only the
  pronunciation worker.

## 1. Install the prerequisites

Open Terminal and run:

~~~
xcode-select --install
~~~

After the command-line tools installation completes, install Homebrew if it is
not already present, then run:

~~~
brew install python@3.9 ffmpeg cmake git
~~~

Confirm that the Terminal is running natively on Apple Silicon:

~~~
uname -m
# expected result: arm64
~~~

## 2. Get the project and install the worker

Clone the project, then run the Apple Silicon installer:

~~~
git clone <YOUR_REPOSITORY_URL> ai-interviewer
cd ai-interviewer
chmod +x pronunciation-worker/setup-multipa-macos.sh
pronunciation-worker/setup-multipa-macos.sh
~~~

The installation creates pronunciation-worker/.venv-macos, compiles the
legacy Fairseq dependency, downloads the released MultiPA/HuBERT/RoBERTa/
Whisper weights, and verifies that PyTorch can see MPS. It does **not** train
anything and it does not download candidate recordings.

If the final check says that MPS is unavailable, update macOS and reinstall
PyTorch. The worker can still be tested with PRONUNCIATION_DEVICE=cpu, but
CPU latency may be too high for a live interview.

## 3. Start the pronunciation worker with Apple GPU acceleration

~~~
cd ai-interviewer/pronunciation-worker
export PYTORCH_ENABLE_MPS_FALLBACK=1
export PRONUNCIATION_DEVICE=mps
export MULTIPA_SOURCE_DIR="$PWD/vendor/MultiPA"
export MULTIPA_MODELS_DIR="$PWD/models"
export PRONUNCIATION_WORKER_API_KEY="$(openssl rand -hex 32)"
.venv-macos/bin/python -m uvicorn app:app --host 127.0.0.1 --port 8000
~~~

PYTORCH_ENABLE_MPS_FALLBACK=1 lets PyTorch run an unsupported Metal operation
on CPU instead of failing. This is safer for a research stack, but it can make
one answer slower. The server log must be retained during the first test.

From a second Terminal window, test the service:

~~~
curl http://127.0.0.1:8000/health
curl -X POST http://127.0.0.1:8000/warmup \
  -H "x-worker-api-key: THE_SAME_VALUE"
~~~

/health should report configured: true. /warmup loads the models before the
demonstration, so the first candidate does not wait for downloads and
initialisation.

## 4. Benchmark before using it for a live demonstration

Use three consented English recordings: one short (about 10 seconds), one near
15 seconds, and one long answer (30–60 seconds). Record:

- warm-up time;
- response time for each answer;
- whether MPS remains available or falls back to CPU;
- whether the Whisper segmentation creates sensible sentence boundaries;
- whether a qualified English reviewer agrees broadly with accuracy, fluency
  and prosody feedback.

The long answer should be automatically split by Whisper's timestamped speech
boundaries into segments no longer than 15 seconds. This does not limit the
candidate's answer length.

## 5. Connect it to the Node.js site only after the local benchmark

The browser must never call this worker directly. Configure these values only
on the Node.js backend:

~~~
PRONUNCIATION_WORKER_URL=https://YOUR-PRIVATE-WORKER-URL
PRONUNCIATION_WORKER_API_KEY=THE_SAME_LONG_RANDOM_VALUE
~~~

For a remote demonstration, put the worker behind HTTPS and protect it with
the API key. Do not expose port 8000 to the public internet without a reverse
proxy and authentication. Keep candidate recordings private and retain the
administrator deletion option.

## Transcription architecture

The application has two separate transcription paths:

~~~
Browser Web Speech API -> visible live transcript -> Claude text evaluation
Recorded answer -> Whisper inside MultiPA -> timestamps/alignment -> audio pronunciation result
~~~

The browser path is built-in browser functionality, not an extension. The
Whisper transcript is internal to the pronunciation worker; it currently does
not replace the browser transcript sent to Claude.
