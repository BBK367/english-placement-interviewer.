$ErrorActionPreference = 'Stop'

# MultiPA's upstream dependency set is reproducible on Python 3.9. This script only installs
# public, pretrained inference dependencies; it does not download training data
# or start a training job.
$workerRoot = $PSScriptRoot
$bundledPython = Join-Path $workerRoot 'runtime\python38\python.exe'
$fullPython = Join-Path $env:LocalAppData 'Programs\Python\Python39\python.exe'
$pythonCommand = if ($env:MULTIPA_PYTHON) { $env:MULTIPA_PYTHON } elseif (Test-Path -LiteralPath $fullPython) { $fullPython } elseif (Test-Path -LiteralPath $bundledPython) { $bundledPython } else { 'python3.9' }
$workerPython = if ($env:MULTIPA_PYTHON) { $env:MULTIPA_PYTHON } elseif (Test-Path -LiteralPath $fullPython) { $fullPython } elseif (Test-Path -LiteralPath $bundledPython) { $bundledPython } else { Join-Path $workerRoot '.venv\Scripts\python.exe' }
$sourceDir = Join-Path $workerRoot 'vendor\MultiPA'
$fairseqDir = Join-Path $workerRoot 'vendor\fairseq'
$modelsDir = Join-Path $workerRoot 'models'

function Enable-VisualCppBuildTools {
  $buildToolsRoot = 'C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC'
  $windowsSdkRoot = 'C:\Program Files (x86)\Windows Kits\10'
  $msvc = Get-ChildItem -LiteralPath $buildToolsRoot -Directory -ErrorAction Stop |
    Sort-Object Name | Select-Object -Last 1
  $sdk = Get-ChildItem -LiteralPath (Join-Path $windowsSdkRoot 'Include') -Directory -ErrorAction Stop |
    Sort-Object Name | Select-Object -Last 1
  $msvcPath = $msvc.FullName
  $sdkVersion = $sdk.Name
  $msvcBin = Join-Path $msvcPath 'bin\Hostx64\x64'
  $sdkBin = Join-Path $windowsSdkRoot "bin\$sdkVersion\x64"
  if (-not (Test-Path -LiteralPath (Join-Path $msvcBin 'cl.exe'))) {
    throw 'Microsoft C++ Build Tools are required to build the released fairseq package on Windows.'
  }
  $env:Path = "$msvcBin;$sdkBin;$env:Path"
  $env:INCLUDE = "$(Join-Path $msvcPath 'include');$(Join-Path $windowsSdkRoot "Include\$sdkVersion\ucrt");$(Join-Path $windowsSdkRoot "Include\$sdkVersion\shared");$(Join-Path $windowsSdkRoot "Include\$sdkVersion\um");$env:INCLUDE"
  $env:LIB = "$(Join-Path $msvcPath 'lib\x64');$(Join-Path $windowsSdkRoot "Lib\$sdkVersion\ucrt\x64");$(Join-Path $windowsSdkRoot "Lib\$sdkVersion\um\x64");$env:LIB"
}

& $pythonCommand --version
if ($LASTEXITCODE -ne 0) { throw 'Python 3.9 could not be started.' }
if (-not (Test-Path -LiteralPath $workerPython) -and $pythonCommand -ne $bundledPython -and $pythonCommand -ne $fullPython) {
  & $pythonCommand -m venv (Join-Path $workerRoot '.venv')
}

 # fairseq 0.12.x depends on an old OmegaConf metadata format. pip 24.0 is
 # recent enough for the other wheels but still resolves that published set.
& $workerPython -m pip install --upgrade pip==24.0 setuptools==75.3.4 wheel
if ($LASTEXITCODE -ne 0) { throw 'Unable to upgrade the Python packaging tools.' }
& $workerPython -m pip install torch==2.2.2 --index-url https://download.pytorch.org/whl/cpu
if ($LASTEXITCODE -ne 0) { throw 'Unable to install the CPU build of PyTorch.' }
& $workerPython -m pip install torchaudio==2.2.2 --index-url https://download.pytorch.org/whl/cpu
if ($LASTEXITCODE -ne 0) { throw 'Unable to install the matching CPU build of torchaudio.' }
& $workerPython -m pip install docopt-ng==0.9.0
if ($LASTEXITCODE -ne 0) { throw 'Unable to install the compatible docopt replacement.' }
& $workerPython -m pip install --no-deps num2words==0.5.13
if ($LASTEXITCODE -ne 0) { throw 'Unable to install num2words.' }
& $workerPython -m pip install --no-build-isolation -r (Join-Path $workerRoot 'requirements.txt')
if ($LASTEXITCODE -ne 0) { throw 'Unable to install the MultiPA Python requirements.' }
Enable-VisualCppBuildTools
# The PyPI fairseq archive is incomplete on Windows (it omits a generated C++
# source file). The pinned upstream source has the missing source; its setup
# script is patched only to replace a Windows-blocked symlink with a copy.
& $workerPython -m pip install Cython==0.29.36
if ($LASTEXITCODE -ne 0) { throw 'Unable to install Cython for fairseq.' }
if (-not (Test-Path -LiteralPath (Join-Path $fairseqDir '.git'))) {
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $fairseqDir) | Out-Null
  git clone --branch v0.12.2 --depth 1 --recurse-submodules https://github.com/facebookresearch/fairseq.git $fairseqDir
}
Push-Location $fairseqDir
try {
  git -c "safe.directory=$fairseqDir" fetch --depth 1 origin v0.12.2
  git -c "safe.directory=$fairseqDir" checkout v0.12.2
  $fairseqSetup = Join-Path $fairseqDir 'setup.py'
  $setupContent = Get-Content -LiteralPath $fairseqSetup -Raw
  if ($setupContent -notmatch 'import shutil') {
    $setupContent = $setupContent -replace '(?m)^import os\r?$', "import os`r`nimport shutil"
  }
  $oldSymlink = '            os.symlink(os.path.join("..", "examples"), fairseq_examples)'
  $windowsExamples = @'
            examples_source = os.path.join(os.path.dirname(__file__), "examples")
            if os.name == "nt":
                # Windows users commonly do not have the privilege required to
                # create symlinks. A local copy is sufficient for package_data.
                shutil.copytree(examples_source, fairseq_examples)
            else:
                os.symlink(examples_source, fairseq_examples)
'@.TrimEnd()
  if ($setupContent.Contains($oldSymlink)) {
    $setupContent = $setupContent.Replace($oldSymlink, $windowsExamples)
  }
  $setupContent = $setupContent.Replace(
    'examples_source = os.path.join("..", "examples")',
    'examples_source = os.path.join(os.path.dirname(__file__), "examples")'
  )
  $oldCleanup = @'
        if "build_ext" not in sys.argv[1:] and os.path.islink(fairseq_examples):
            os.unlink(fairseq_examples)
'@.TrimEnd()
  $windowsCleanup = @'
        if "build_ext" not in sys.argv[1:]:
            if os.path.islink(fairseq_examples):
                os.unlink(fairseq_examples)
            elif os.name == "nt" and os.path.isdir(fairseq_examples):
                shutil.rmtree(fairseq_examples)
'@.TrimEnd()
  if ($setupContent.Contains($oldCleanup)) {
    $setupContent = $setupContent.Replace($oldCleanup, $windowsCleanup)
  }
  Set-Content -LiteralPath $fairseqSetup -Value $setupContent -NoNewline -Encoding utf8
} finally {
  Pop-Location
}
& $workerPython -m pip install --no-build-isolation --no-deps $fairseqDir
if ($LASTEXITCODE -ne 0) { throw 'Unable to install fairseq from its patched upstream source without replacing the CPU-only PyTorch build.' }
$nltkData = Join-Path $modelsDir 'nltk_data'
& $workerPython -c "import nltk; data=r'$nltkData'; nltk.download('cmudict', download_dir=data); nltk.download('punkt', download_dir=data); nltk.download('averaged_perceptron_tagger', download_dir=data)"
if ($LASTEXITCODE -ne 0) { throw 'Unable to install the required NLTK pronunciation data.' }

if (-not (Test-Path -LiteralPath (Join-Path $sourceDir '.git'))) {
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $sourceDir) | Out-Null
  if (Test-Path -LiteralPath (Join-Path $sourceDir 'model_assessment.py')) {
    # Some archive extractors omit the upstream .git folder.  Recreate only
    # the repository metadata so the pinned checkout below remains rerunnable.
    git -C $sourceDir init
    git -C $sourceDir remote add origin https://github.com/yuwchen/MultiPA.git
  } else {
    git clone https://github.com/yuwchen/MultiPA.git $sourceDir
  }
}
Push-Location $sourceDir
try {
  git -c "safe.directory=$sourceDir" fetch --depth 1 origin a8d83ec1d80f9db60e6d32227cb1c562ee5e6022
  git -c "safe.directory=$sourceDir" checkout a8d83ec1d80f9db60e6d32227cb1c562ee5e6022
  $patchPath = Join-Path $workerRoot 'patches\multipa-cpu-device.patch'
  $previousPreference = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  git -c "safe.directory=$sourceDir" apply --check $patchPath 2>$null
  $patchApplies = $LASTEXITCODE -eq 0
  git -c "safe.directory=$sourceDir" apply --reverse --check $patchPath 2>$null
  $patchAlreadyApplied = $LASTEXITCODE -eq 0
  $ErrorActionPreference = $previousPreference
  if ($patchApplies) {
    git -c "safe.directory=$sourceDir" apply $patchPath
  } elseif (-not $patchAlreadyApplied) {
    throw 'The MultiPA CPU compatibility patch no longer matches the pinned upstream source.'
  }

  # MultiPA uses librosa.sequence.dtw with only two monotonic transitions.
  # Importing that optional JIT module can take several minutes on Windows,
  # so replace it with the equivalent small NumPy routine for this worker.
  $utilsPath = Join-Path $sourceDir 'utils.py'
  $utilsContent = Get-Content -LiteralPath $utilsPath -Raw
  $dtwImport = 'from librosa.sequence import dtw'
  $dtwReplacement = @'


def _monotonic_dtw(cost):
    """DTW for the exact two-step alignment used by ``forced_align``."""
    frame_count, phone_count = cost.shape
    if frame_count == 0 or phone_count == 0:
        raise ValueError("Cannot align an empty audio or phoneme sequence.")
    cumulative = np.full((frame_count, phone_count), np.inf, dtype=np.float32)
    came_from_same_phone = np.zeros((frame_count, phone_count), dtype=np.bool_)
    cumulative[0, 0] = cost[0, 0]
    for frame in range(1, frame_count):
        cumulative[frame, 0] = cumulative[frame - 1, 0] + cost[frame, 0]
        for phone in range(1, min(phone_count, frame + 1)):
            stay_cost = cumulative[frame - 1, phone]
            advance_cost = cumulative[frame - 1, phone - 1]
            if stay_cost <= advance_cost:
                cumulative[frame, phone] = stay_cost + cost[frame, phone]
                came_from_same_phone[frame, phone] = True
            else:
                cumulative[frame, phone] = advance_cost + cost[frame, phone]
    phone = phone_count - 1
    if not np.isfinite(cumulative[-1, phone]):
        phone = int(np.argmin(cumulative[-1]))
    path = []
    for frame in range(frame_count - 1, -1, -1):
        path.append((frame, phone))
        if frame and phone and not came_from_same_phone[frame, phone]:
            phone -= 1
    return cumulative, np.asarray(path[::-1], dtype=np.int64)
'@.TrimEnd()
  if ($utilsContent.Contains($dtwImport)) {
    $utilsContent = $utilsContent.Replace($dtwImport, $dtwReplacement)
    $utilsContent = $utilsContent.Replace("D,align = dtw(C=-cost[:,phone_ids],`n                  step_sizes_sigma=np.array([[1, 1], [1, 0]]))", 'D,align = _monotonic_dtw(-cost[:,phone_ids])')
    Set-Content -LiteralPath $utilsPath -Value $utilsContent -NoNewline -Encoding utf8
  } elseif (-not $utilsContent.Contains('def _monotonic_dtw')) {
    throw 'The MultiPA DTW compatibility patch no longer matches the pinned upstream source.'
  }
} finally {
  Pop-Location
}

$env:MULTIPA_SOURCE_DIR = $sourceDir
$env:MULTIPA_MODELS_DIR = $modelsDir
& $workerPython (Join-Path $workerRoot 'setup_multipa_assets.py')
if ($LASTEXITCODE -ne 0) { throw 'Unable to download the released MultiPA model assets.' }
Write-Host 'MultiPA is installed with released pretrained weights. No training was performed.'
