$ErrorActionPreference = 'Stop'

Write-Host 'Configuration AWS Bedrock pour le backend' -ForegroundColor Cyan
Write-Host 'Les secrets saisis restent sur cette machine.'

$accessKey = Read-Host 'AWS Access Key ID'
$secretSecure = Read-Host 'AWS Secret Access Key' -AsSecureString
$region = Read-Host 'Region AWS (ex: eu-west-1)'
$modelId = Read-Host 'Bedrock Model ID exact'
$hasToken = Read-Host 'As-tu aussi un AWS Session Token ? (o/N)'
$tokenSecure = $null
if ($hasToken -match '^[oOyY]') {
  $tokenSecure = Read-Host 'AWS Session Token' -AsSecureString
}

if ([string]::IsNullOrWhiteSpace($accessKey) -or [string]::IsNullOrWhiteSpace($region) -or [string]::IsNullOrWhiteSpace($modelId)) {
  throw 'Access Key, region et Model ID sont obligatoires.'
}

$secret = [System.Net.NetworkCredential]::new('', $secretSecure).Password
$awsDirectory = Join-Path $env:USERPROFILE '.aws'
New-Item -ItemType Directory -Force -Path $awsDirectory | Out-Null

$credentialLines = @(
  '[default]'
  "aws_access_key_id=$accessKey"
  "aws_secret_access_key=$secret"
)
if ($tokenSecure) {
  $token = [System.Net.NetworkCredential]::new('', $tokenSecure).Password
  $credentialLines += "aws_session_token=$token"
}

$credentialsPath = Join-Path $awsDirectory 'credentials'
$configPath = Join-Path $awsDirectory 'config'
[System.IO.File]::WriteAllLines($credentialsPath, $credentialLines, [System.Text.UTF8Encoding]::new($false))
[System.IO.File]::WriteAllLines($configPath, @('[default]', "region=$region"), [System.Text.UTF8Encoding]::new($false))

$projectDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$envPath = Join-Path $projectDirectory '.env'
$envLines = @(
  'PORT=5002'
  "AWS_REGION=$region"
  "BEDROCK_MODEL_ID=$modelId"
  'BEDROCK_PROMPT_CACHE=true'
  'ASSESSOR_PROMPT_VERSION=assessor-v1'
)
[System.IO.File]::WriteAllLines($envPath, $envLines, [System.Text.UTF8Encoding]::new($false))

$secret = $null
$token = $null
Write-Host 'Configuration enregistree. Tu peux fermer cette fenetre.' -ForegroundColor Green
Read-Host 'Appuie sur Entree pour terminer'
