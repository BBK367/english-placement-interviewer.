// Explainable placement rubric. Language remains the larger component because
// CEFR measures communicative competence, while speech is a required second gate.
const CEFR_LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
const LANGUAGE_WEIGHTS = { comprehension: .22, grammar: .22, vocabulary: .20, coherence: .16, interaction: .12, fluency: .08 };
const SPEECH_WEIGHTS = { pronunciation: .55, acousticFluency: .25, prosody: .20 };
function avg(values) { const v = values.filter(Number.isFinite); return v.length ? v.reduce((a,b)=>a+b,0)/v.length : null; }
function scale5(v) { return Number.isFinite(v) ? Math.max(0, Math.min(100, v * 20)) : null; }
function scoreClaude(evaluations) { return avg(evaluations.map(e => Object.entries(LANGUAGE_WEIGHTS).reduce((s,[k,w]) => s + (scale5(e.answerEvaluation[k]?.score) ?? 0) * w, 0))); }
function scoreSpeech(pronunciation) {
  if (!pronunciation || pronunciation.status !== 'assessed') return null;
  const values = { pronunciation: pronunciation.accuracyScore ?? pronunciation.score, acousticFluency: pronunciation.fluency?.rhythmScore, prosody: pronunciation.prosodyScore };
  const available = Object.entries(SPEECH_WEIGHTS).filter(([k]) => Number.isFinite(values[k]));
  return available.length ? available.reduce((s,[k,w]) => s + values[k] * w, 0) / available.reduce((s,[,w]) => s + w, 0) : null;
}
function estimateCefr(globalScore) { return CEFR_LEVELS[Math.max(0, Math.min(5, Math.floor(globalScore / 16.67)))]; }
function fuseCefr(evaluations, pronunciation) {
  const languageScore = scoreClaude(evaluations) ?? 0;
  const speechScore = scoreSpeech(pronunciation);
  const globalScore = speechScore === null ? languageScore : languageScore * .65 + speechScore * .35;
  const cefr = estimateCefr(globalScore);
  return { estimatedCefr: cefr, estimatedBand: { A1:'beginner', A2:'elementary', B1:'intermediate', B2:'upper_intermediate', C1:'advanced', C2:'advanced' }[cefr], languageScore: Number(languageScore.toFixed(1)), speechScore: speechScore === null ? null : Number(speechScore.toFixed(1)), globalScore: Number(globalScore.toFixed(1)), pronunciationRequired: true, speechAssessed: speechScore !== null, weights: { language: .65, speech: speechScore === null ? 0 : .35, languageDimensions: LANGUAGE_WEIGHTS, speechDimensions: SPEECH_WEIGHTS } };
}
module.exports = { fuseCefr, estimateCefr, LANGUAGE_WEIGHTS, SPEECH_WEIGHTS };
