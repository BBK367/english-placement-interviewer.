const MAX_AUDIO_BYTES = 8 * 1024 * 1024;
const VALID_STATUSES = new Set(['assessed', 'not_assessed']);
const VALID_ENGINES = new Set(['multipa', 'phoneme_baseline']);
const WORKER_TIMEOUT_MS = Math.min(Math.max(Number(process.env.PRONUNCIATION_TIMEOUT_MS) || 180000, 30000), 300000);

function boundedNumber(value, min, max) {
  const number = Number(value);
  return Number.isFinite(number) && number >= min && number <= max ? number : null;
}

function normalizePronunciationResult(value) {
  if (!value || typeof value !== 'object' || !VALID_STATUSES.has(value.status)) throw new Error('Pronunciation worker returned an invalid status');
  if (value.status === 'not_assessed') {
    return {
      status: 'not_assessed', score: null,
      evidence: typeof value.evidence === 'string' ? value.evidence.slice(0, 500) : 'The open-source pronunciation worker did not assess this recording.',
      engine: null, accuracyScore: null, prosodyScore: null, wordObservations: [],
      phonemeErrors: [], fluency: null, suggestions: []
    };
  }

  const score = boundedNumber(value.score, 0, 100);
  if (score === null) throw new Error('Pronunciation worker returned an invalid score');
  const wordObservations = Array.isArray(value.wordObservations) ? value.wordObservations.slice(0, 8).flatMap(item => {
    if (!item || typeof item !== 'object' || typeof item.word !== 'string' || !item.word.trim()) return [];
    const totalScore = boundedNumber(item.totalScore, 0, 100);
    return [{
      word: item.word.trim().slice(0, 80),
      accuracyScore: boundedNumber(item.accuracyScore, 0, 100),
      stressScore: boundedNumber(item.stressScore, 0, 100),
      totalScore
    }];
  }) : [];
  const phonemeErrors = Array.isArray(value.phonemeErrors) ? value.phonemeErrors.slice(0, 12).flatMap(item => {
    if (!item || typeof item !== 'object' || typeof item.expected !== 'string') return [];
    return [{
      expected: item.expected.slice(0, 20), heard: typeof item.heard === 'string' ? item.heard.slice(0, 20) : '',
      type: ['mispronounced', 'omitted'].includes(item.type) ? item.type : 'mispronounced',
      score: boundedNumber(item.score, 0, 100)
    }];
  }) : [];
  const fluency = value.fluency && typeof value.fluency === 'object' ? {
    speakingRate: boundedNumber(value.fluency.speakingRate, 0, 400),
    rhythmScore: boundedNumber(value.fluency.rhythmScore, 0, 100),
    monotonyScore: boundedNumber(value.fluency.monotonyScore, 0, 100)
  } : null;
  const suggestions = Array.isArray(value.suggestions) ? value.suggestions.filter(item => typeof item === 'string').slice(0, 3).map(item => item.slice(0, 240)) : [];
  return {
    status: 'assessed', score,
    recordedDuration: boundedNumber(value.recordedDuration, 0, 120),
    analyzedDuration: boundedNumber(value.analyzedDuration, 0, 120),
    analyzedSegments: Number.isInteger(value.analyzedSegments) ? value.analyzedSegments : null,
    skippedSegments: Number.isInteger(value.skippedSegments) ? value.skippedSegments : null,
    skippedReasons: Array.isArray(value.skippedReasons) ? value.skippedReasons.filter(item => typeof item === 'string').slice(0, 8) : [],
    evidence: typeof value.evidence === 'string' ? value.evidence.slice(0, 500) : 'Audio was assessed with an open-source acoustic model.',
    engine: VALID_ENGINES.has(value.engine) ? value.engine : 'phoneme_baseline',
    accuracyScore: boundedNumber(value.accuracyScore, 0, 100),
    prosodyScore: boundedNumber(value.prosodyScore, 0, 100),
    wordObservations, phonemeErrors, fluency, suggestions
  };
}

function unavailable(reason) {
  return {
    status: 'not_assessed', score: null, evidence: reason, engine: null,
    accuracyScore: null, prosodyScore: null, wordObservations: [],
    phonemeErrors: [], fluency: null, suggestions: []
  };
}

async function assessPronunciation({ audio, contentType, referenceText, fetchImpl = fetch }) {
  if (!Buffer.isBuffer(audio) || audio.length === 0) return unavailable('No audio recording was received.');
  if (audio.length > MAX_AUDIO_BYTES) return unavailable('The audio recording exceeds the eight megabyte assessment limit.');
  if (typeof referenceText !== 'string' || !referenceText.trim()) return unavailable('No transcript was available to align this audio response.');
  if (referenceText.length > 1000) return unavailable('This answer transcript is too long for the pronunciation assessment limit.');
  const workerUrl = process.env.PRONUNCIATION_WORKER_URL;
  if (!workerUrl) return unavailable('Open-source pronunciation analysis is not configured on this deployment.');
  const workerApiKey = process.env.PRONUNCIATION_WORKER_API_KEY;
  let endpoint;
  try { endpoint = new URL('/assess', workerUrl); }
  catch (_) { return unavailable('The pronunciation worker address is invalid.'); }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), WORKER_TIMEOUT_MS);
  try {
    const response = await fetchImpl(endpoint, {
      method: 'POST', signal: controller.signal,
      headers: {
        'content-type': contentType || 'application/octet-stream',
        'x-reference-text': referenceText.trim(),
        ...(workerApiKey ? { 'x-worker-api-key': workerApiKey } : {})
      },
      body: audio
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) return unavailable('The open-source pronunciation worker could not assess this recording.');
    return normalizePronunciationResult(data);
  } catch (error) {
    return unavailable(error.name === 'AbortError' ? 'Pronunciation analysis timed out.' : 'The open-source pronunciation worker is unavailable.');
  } finally { clearTimeout(timer); }
}

module.exports = { assessPronunciation, normalizePronunciationResult, MAX_AUDIO_BYTES };
