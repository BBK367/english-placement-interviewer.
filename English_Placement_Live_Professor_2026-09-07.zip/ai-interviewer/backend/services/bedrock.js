const { BedrockRuntimeClient } = require('@aws-sdk/client-bedrock-runtime');

console.log('AWS Bedrock configuration', {
  region: process.env.AWS_REGION || 'eu-west-1',
  hasAccessKeyId: Boolean(process.env.AWS_ACCESS_KEY_ID),
  hasSecretAccessKey: Boolean(process.env.AWS_SECRET_ACCESS_KEY)
});

module.exports = new BedrockRuntimeClient({ region: process.env.AWS_REGION || 'eu-west-1' });
