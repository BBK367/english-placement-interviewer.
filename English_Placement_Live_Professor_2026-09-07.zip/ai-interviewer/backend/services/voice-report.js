const fs = require('node:fs');
const path = require('node:path');
const { assessTurn } = require('./assessor');
const { assessPronunciation } = require('./pronunciation');
const { analyseChunks, aggregate } = require('./partial-pronunciation');
const { fuseCefr } = require('./cefr-scoring');
const { evaluationResponseSchema, finalEnglishReportSchema } = require('../../shared/assessment-schemas');
function wav(pcm) {
 const h=Buffer.alloc(44);h.write('RIFF');h.writeUInt32LE(36+pcm.length,4);h.write('WAVEfmt ',8);h.writeUInt32LE(16,16);h.writeUInt16LE(1,20);h.writeUInt16LE(1,22);h.writeUInt32LE(16000,24);h.writeUInt32LE(32000,28);h.writeUInt16LE(2,32);h.writeUInt16LE(16,34);h.write('data',36);h.writeUInt32LE(pcm.length,40);return Buffer.concat([h,pcm]);
}
async function voiceReport(session) {
 const turns=session.transcript.filter(t=>t.role==='USER' && t.text.trim());
 const candidate=turns.map(t=>t.text).join(' ');
 const words=candidate.trim().split(/\s+/).filter(Boolean).length;
 if(words<15) return {status:'insufficient_evidence',message:'Too little recognised speech to estimate CEFR. Try a longer interview with several complete answers.'};
 const pcm=Buffer.concat(session.audio);
 // Split at the worker duration limit; never truncate the microphone recording.
 const audioJob=analyseChunks(pcm,audio=>assessPronunciation({audio,contentType:'audio/wav',referenceText:candidate.slice(0,1000)}),wav);
 const prompt=fs.readFileSync(path.join(__dirname,'../prompts/assessor.en.txt'),'utf8')+'\nEvaluate the entire supplied conversation, not only the last answer. Only USER utterances are candidate evidence. Assistant utterances are context only. Do not infer pronunciation from text. This short interview can support only a provisional placement. Text fluency is not acoustic fluency.';
 const result=await assessTurn({systemPrompt:prompt,history:[],candidateAnswer:JSON.stringify(session.transcript),currentBand:'intermediate',questionsAsked:turns.length,stage:'closing'});
 const evaluation=evaluationResponseSchema.parse(result.evaluation);
 const audioResults=await audioJob;
 // Only pretrained MultiPA is used for full-conversation chunks; baseline alignment would need per-turn timestamps.
 const assessed=audioResults.filter(x=>x.status==='assessed' && x.engine==='multipa');
 const pronunciation=aggregate(audioResults);
 const fusion=fuseCefr([evaluation],pronunciation),a=evaluation.answerEvaluation;
 const complete=assessed.length===audioResults.length && assessed.length>0;
 const confidence=words>=100 && turns.length>=3 && complete?'medium':'low';
 const dimensions=Object.fromEntries(['comprehension','fluency','grammar','vocabulary','coherence','interaction'].map(k=>[k,{score:a[k].score,summary:a[k].evidence}]));
 dimensions.pronunciation={status:pronunciation.status,score:pronunciation.score===null?null:pronunciation.score/20,summary:complete?'Recorded microphone audio analysed with pretrained MultiPA.':pronunciation.status==='assessed'?'Partial MultiPA analysis: successful passages contribute to the oral score; failed passages are excluded. Confidence remains limited.':'No usable MultiPA result: placement uses language evidence only.'};
 const report=finalEnglishReportSchema.parse({estimatedCefr:fusion.estimatedCefr,estimatedBand:fusion.estimatedBand,confidence,summary:'Provisional placement from a short voice interview. Language: '+fusion.languageScore+'/100; speech: '+(fusion.speechScore??'unavailable')+'/100.',dimensions,strengths:a.strengths,improvementAreas:a.improvementAreas,representativeExamples:a.observedErrors.map(x=>({example:x.example,observation:x.suggestedCorrection})),recommendedCourseLevel:fusion.estimatedCefr,limitations:['Short screening, not a certification. Confidence is an evidence heuristic, not a probability.',words+' candidate words across '+turns.length+' recognised turns.',assessed.length+'/'+audioResults.length+' audio chunks assessed by MultiPA. Microphone echo may affect results.','The 65/35 fusion and CEFR thresholds are experimental and not human-calibrated.']});
 return {status:'completed',report};
}
module.exports={voiceReport,wav};
