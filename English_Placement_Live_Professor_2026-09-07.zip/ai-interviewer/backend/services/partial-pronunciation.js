// Recover failed long chunks once as smaller, non-overlapping chunks.
// A successful parent is never re-scored; failed parents are replaced by children.
async function analyseChunks(pcm, assess, wrap) {
 const results=[];
 async function run(chunk, retry) {
  let result;try{result=await assess(wrap(chunk));}catch{result={status:'not_assessed',evidence:'The pronunciation worker is unavailable.'};}
  const seconds=chunk.length/32000;
  const valid=result?.status==='assessed' && result.engine==='multipa' && Number.isFinite(result.score) && result.score>=0 && result.score<=100;
  const infrastructure=/unavailable|not configured|address is invalid|timed out/i.test(result?.evidence || '');
  if(!valid && retry && seconds>15 && !infrastructure){
   const middle=Math.floor(chunk.length/4)*2;
   await run(chunk.subarray(0,middle),false);await run(chunk.subarray(middle),false);return;
  }
  results.push({...result,status:valid?'assessed':'not_assessed',recordedDuration:seconds});
 }
 for(let n=0;n<pcm.length;n+=32000*60)await run(pcm.subarray(n,n+32000*60),true);
 return results;
}
function aggregate(results) {
 const assessed=results.filter(x=>x.status==='assessed' && x.engine==='multipa' && Number.isFinite(x.score));
 const weight=x=>Number.isFinite(x.analyzedDuration) && x.analyzedDuration>0?Math.min(x.analyzedDuration,x.recordedDuration):x.recordedDuration;
 const mean=key=>{const valid=assessed.filter(x=>Number.isFinite(key(x)) && weight(x)>0);const total=valid.reduce((s,x)=>s+weight(x),0);return total?valid.reduce((s,x)=>s+key(x)*weight(x),0)/total:null;};
 const score=mean(x=>x.score);
 return {status:score===null?'not_assessed':'assessed',score,accuracyScore:mean(x=>x.accuracyScore),prosodyScore:mean(x=>x.prosodyScore),fluency:{rhythmScore:mean(x=>x.fluency?.rhythmScore)}};
}
module.exports={analyseChunks,aggregate};
