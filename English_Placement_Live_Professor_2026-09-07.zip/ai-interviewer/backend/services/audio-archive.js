const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');

// This matches the maximum body accepted by the pronunciation worker, so an
// answer retained for per-answer analysis is always small enough to assess.
const MAX_RECORDING_BYTES = 8 * 1024 * 1024;
const DEFAULT_ARCHIVE_DIRECTORY = path.resolve(__dirname, '../../data/live-audio-archive');

function extensionFor(contentType) {
  const type = String(contentType || '').toLowerCase().split(';', 1)[0];
  if (type === 'audio/ogg') return '.ogg';
  if (type === 'audio/wav' || type === 'audio/wave' || type === 'audio/x-wav') return '.wav';
  if (type === 'audio/mp4' || type === 'audio/m4a') return '.m4a';
  return '.webm';
}

function safeMetadata(metadata) {
  return {
    id: metadata.id,
    interviewId: metadata.interviewId,
    candidate: {
      fullName: metadata.candidate?.fullName || '',
      email: metadata.candidate?.email || '',
      reference: metadata.candidate?.reference || ''
    },
    answerNumber: metadata.answerNumber,
    questionId: metadata.questionId,
    questionText: metadata.questionText,
    contentType: metadata.contentType,
    byteSize: metadata.byteSize,
    recordedAt: metadata.recordedAt
  };
}

function createAudioArchive({ directory = process.env.LIVE_AUDIO_ARCHIVE_DIR || DEFAULT_ARCHIVE_DIRECTORY } = {}) {
  const archiveDirectory = path.resolve(directory);

  async function ensureDirectory() {
    await fs.mkdir(archiveDirectory, { recursive: true });
  }

  function metadataPath(id) {
    if (!/^[a-f0-9-]{36}$/i.test(id)) throw new Error('Invalid recording identifier.');
    return path.join(archiveDirectory, `${id}.json`);
  }

  async function readMetadata(id) {
    try {
      return JSON.parse(await fs.readFile(metadataPath(id), 'utf8'));
    } catch (error) {
      if (error.code === 'ENOENT') return null;
      throw error;
    }
  }

  return {
    async save({ interviewId, candidate, answerNumber, question, audio, contentType }) {
      if (!Buffer.isBuffer(audio) || audio.length === 0 || audio.length > MAX_RECORDING_BYTES) {
        throw new Error('A recording must contain audio and be no larger than eight megabytes.');
      }
      if (!Number.isInteger(answerNumber) || answerNumber < 1 || answerNumber > 6) {
        throw new Error('Invalid answer number for the recording.');
      }
      await ensureDirectory();
      const id = crypto.randomUUID();
      const extension = extensionFor(contentType);
      const audioFileName = `${id}${extension}`;
      const metadata = {
        id,
        interviewId: String(interviewId),
        candidate: {
          fullName: String(candidate?.fullName || '').slice(0, 200),
          email: String(candidate?.email || '').slice(0, 320),
          reference: String(candidate?.reference || '').slice(0, 120)
        },
        answerNumber,
        questionId: String(question?.id || '').slice(0, 120),
        questionText: String(question?.text || '').slice(0, 1000),
        audioFileName,
        contentType: String(contentType || 'audio/webm').slice(0, 100),
        byteSize: audio.length,
        recordedAt: new Date().toISOString()
      };
      await fs.writeFile(path.join(archiveDirectory, audioFileName), audio, { flag: 'wx' });
      try {
        await fs.writeFile(metadataPath(id), JSON.stringify(metadata), { flag: 'wx' });
      } catch (error) {
        await fs.unlink(path.join(archiveDirectory, audioFileName)).catch(() => {});
        throw error;
      }
      return safeMetadata(metadata);
    },

    async list() {
      await ensureDirectory();
      const names = await fs.readdir(archiveDirectory);
      const metadata = await Promise.all(names.filter(name => name.endsWith('.json')).map(async name => {
        try { return JSON.parse(await fs.readFile(path.join(archiveDirectory, name), 'utf8')); }
        catch (_) { return null; }
      }));
      return metadata.filter(Boolean).map(safeMetadata).sort((left, right) => right.recordedAt.localeCompare(left.recordedAt));
    },

    async getAudio(id) {
      const metadata = await readMetadata(id);
      if (!metadata) return null;
      const audioPath = path.resolve(archiveDirectory, metadata.audioFileName || '');
      if (!audioPath.startsWith(`${archiveDirectory}${path.sep}`)) throw new Error('Invalid recording path.');
      try {
        await fs.access(audioPath);
        return { metadata: safeMetadata(metadata), audioPath };
      } catch (error) {
        if (error.code === 'ENOENT') return null;
        throw error;
      }
    },

    async delete(id) {
      const metadata = await readMetadata(id);
      if (!metadata) return false;
      const audioPath = path.resolve(archiveDirectory, metadata.audioFileName || '');
      if (!audioPath.startsWith(`${archiveDirectory}${path.sep}`)) throw new Error('Invalid recording path.');
      await fs.unlink(audioPath).catch(error => { if (error.code !== 'ENOENT') throw error; });
      await fs.unlink(metadataPath(id));
      return true;
    }
  };
}

module.exports = { createAudioArchive, MAX_RECORDING_BYTES };
