const fs = require('node:fs');
const path = require('node:path');
const { ConverseCommand } = require('@aws-sdk/client-bedrock-runtime');
const bedrock = require('./bedrock');
const { sendWithRetry } = require('./assessor');

const bands = ['beginner','elementary','intermediate','upper_intermediate','advanced'];
const dimension = { type: 'object', additionalProperties: false, required: ['score','summary'], properties: { score: { type: 'number', minimum: 0, maximum: 5 }, summary: { type: 'string' } } };
const reportSchema = { type: 'object', additionalProperties: false,
  required: ['estimatedCefr','estimatedBand','confidence','summary','dimensions','strengths','improvementAreas','representativeExamples','recommendedCourseLevel','limitations'],
  properties: {
    estimatedCefr: { enum: ['A1','A2','B1','B2','C1','C2'] }, estimatedBand: { enum: bands }, confidence: { enum: ['low','medium','high'] }, summary: { type: 'string' },
    dimensions: { type: 'object', additionalProperties: false, required: ['comprehension','fluency','grammar','vocabulary','coherence','interaction','pronunciation'], properties: { comprehension: dimension, fluency: dimension, grammar: dimension, vocabulary: dimension, coherence: dimension, interaction: dimension, pronunciation: { type: 'object', additionalProperties: false, required: ['status','score','summary'], properties: { status: { enum: ['not_assessed','assessed'] }, score: { type: ['number','null'], minimum: 0, maximum: 5 }, summary: { type: 'string' } } } } },
    strengths: { type: 'array', items: { type: 'string' } }, improvementAreas: { type: 'array', items: { type: 'string' } },
    representativeExamples: { type: 'array', items: { type: 'object', additionalProperties: false, required: ['example','observation'], properties: { example: { type: 'string' }, observation: { type: 'string' } } } },
    recommendedCourseLevel: { type: 'string' }, limitations: { type: 'array', items: { type: 'string' } }
  }
};
const prompt = fs.readFileSync(path.join(__dirname, '../prompts/reporter.en.txt'), 'utf8');

async function createReport(evaluations) {
  const response = await sendWithRetry({ modelId: process.env.BEDROCK_MODEL_ID,
    system: [{ text: prompt }], messages: [{ role: 'user', content: [{ text: JSON.stringify(evaluations) }] }],
    toolConfig: { tools: [{ toolSpec: { name: 'submit_report', description: 'Submit the final evidence-based English placement report.', inputSchema: { json: reportSchema } } }], toolChoice: { tool: { name: 'submit_report' } } },
    inferenceConfig: { temperature: 0, maxTokens: 3000 }
  });
  const block = response.output?.message?.content?.find(item => item.toolUse);
  if (!block) throw new Error('Bedrock response did not contain the required submit_report tool call');
  return { report: block.toolUse.input, usage: response.usage || {} };
}
module.exports = { createReport, reportToolSchema: reportSchema };
