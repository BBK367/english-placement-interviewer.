const express = require('express');
const fs = require('node:fs');
const path = require('node:path');
const db = require('../config/db');
const { assessTurn } = require('../services/assessor');
const { createReport } = require('../services/reporter');
const { evaluationResponseSchema, finalEnglishReportSchema } = require('../../shared/assessment-schemas');

const router = express.Router();
const systemPrompt = fs.readFileSync(path.join(__dirname, '../prompts/assessor.en.txt'), 'utf8');
const promptVersion = process.env.ASSESSOR_PROMPT_VERSION || 'assessor-v1';
const stages = ['warm_up','experience','interaction','opinion','scenario','closing'];
const cefrForBand = { beginner: 'A1', elementary: 'A2', intermediate: 'B1', upper_intermediate: 'B2', advanced: 'C1' };
const fallbackQuestions = {
  beginner: 'What do you usually do in the morning?', elementary: 'Can you describe a place you enjoy visiting?',
  intermediate: 'Tell me about a challenge you solved at work or school.', upper_intermediate: 'How would you handle a disagreement with a colleague?',
  advanced: 'What trade-offs should organisations consider when adopting artificial intelligence?'
};

const stageFor = count => stages[Math.min(Math.floor(count / 2), stages.length - 1)];
const usageValues = usage => [usage.inputTokens || 0, usage.outputTokens || 0, usage.cacheReadInputTokens || 0, usage.cacheWriteInputTokens || 0];
async function logUsage(client, interviewId, usage = {}, error = null) {
  const values = usageValues(usage);
  await client.query('INSERT INTO api_usage_logs (interview_id,service,input_tokens,output_tokens,cache_read_input_tokens,cache_write_input_tokens,error) VALUES ($1,$2,$3,$4,$5,$6,$7)', [interviewId, 'claude', ...values, error ? String(error.name || 'BedrockError').slice(0, 200) : null]);
}
async function failedEvaluation(client, interview, turnId, error) {
  await client.query("INSERT INTO turn_evaluations (interview_id,dialogue_turn_id,evaluation_status,prompt_version,model_id) VALUES ($1,$2,'failed',$3,$4)", [interview.id, turnId, promptVersion, process.env.BEDROCK_MODEL_ID || null]);
  await logUsage(client, interview.id, {}, error);
  const failures = await client.query("SELECT evaluation_status FROM turn_evaluations WHERE interview_id=$1 ORDER BY created_at DESC LIMIT 3", [interview.id]);
  const stop = failures.rows.length === 3 && failures.rows.every(row => row.evaluation_status === 'failed');
  const count = Number(interview.questions_asked || 0) + 1;
  const question = stop ? null : { id: `fallback-${count}`, text: fallbackQuestions[interview.current_band] || fallbackQuestions.intermediate, difficulty: interview.current_band || 'intermediate', competencyTarget: 'interaction', stage: stageFor(count) };
  await client.query("UPDATE interviews SET questions_asked=$2, status=CASE WHEN $3 THEN 'completed' ELSE status END, ended_at=CASE WHEN $3 THEN NOW() ELSE ended_at END, end_reason=CASE WHEN $3 THEN 'service_error' ELSE end_reason END WHERE id=$1", [interview.id, count, stop]);
  if (question) await client.query("INSERT INTO dialogue_turns (interview_id,turn_number,role,content) SELECT $1,COALESCE(MAX(turn_number),0)+1,'assistant',$2 FROM dialogue_turns WHERE interview_id=$1", [interview.id, question.text]);
  return { answerEvaluation: {
    comprehension: { score: 0, evidence: 'Evaluation unavailable.' }, fluency: { score: 0, evidence: 'Evaluation unavailable.' }, grammar: { score: 0, evidence: 'Evaluation unavailable.' }, vocabulary: { score: 0, evidence: 'Evaluation unavailable.' }, coherence: { score: 0, evidence: 'Evaluation unavailable.' }, interaction: { score: 0, evidence: 'Evaluation unavailable.' },
    pronunciation: { status: 'not_assessed', score: null, evidence: 'No audio was analysed.' }, observedErrors: [], strengths: [], improvementAreas: []
  }, estimatedBand: interview.current_band || 'intermediate', estimatedCefr: cefrForBand[interview.current_band] || 'B1', nextAction: stop ? 'finish_interview' : 'ask_next_question', nextQuestion: question, shouldFinish: stop, finishReason: stop ? 'service_error' : 'evaluation_temporarily_unavailable' };
}

router.post('/:interviewId/evaluate', async (req, res) => {
  const { transcript, durationSeconds, clarificationRequired = false, transcriptEdited = false } = req.body || {};
  if (typeof transcript !== 'string' || !transcript.trim()) return res.status(400).json({ message: 'A transcript is required.' });
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const found = await client.query('SELECT * FROM interviews WHERE id=$1 FOR UPDATE', [req.params.interviewId]);
    if (!found.rowCount) { await client.query('ROLLBACK'); return res.status(404).json({ message: 'Interview not found.' }); }
    const interview = found.rows[0];
    if (interview.status !== 'in_progress') { await client.query('ROLLBACK'); return res.status(400).json({ message: 'Interview is not in progress.' }); }
    const historyResult = await client.query('SELECT role,content FROM dialogue_turns WHERE interview_id=$1 ORDER BY turn_number ASC', [interview.id]);
    const inserted = await client.query("INSERT INTO dialogue_turns (interview_id,turn_number,role,content,transcript_source,transcript_edited,duration_seconds) SELECT $1,COALESCE(MAX(turn_number),0)+1,'user',$2,'browser',$3,$4 FROM dialogue_turns WHERE interview_id=$1 RETURNING id", [interview.id, transcript.trim(), transcriptEdited, durationSeconds || null]);
    if (clarificationRequired) await client.query('UPDATE interviews SET clarification_count=clarification_count+1 WHERE id=$1', [interview.id]);
    let raw;
    try {
      raw = await assessTurn({ systemPrompt, history: historyResult.rows.map(row => ({ role: row.role, text: row.content })), candidateAnswer: transcript.trim(), currentBand: interview.current_band || 'intermediate', questionsAsked: Number(interview.questions_asked || 0), stage: stageFor(Number(interview.questions_asked || 0)) });
    } catch (error) {
      const response = await failedEvaluation(client, interview, inserted.rows[0].id, error);
      await client.query('COMMIT');
      return res.status(200).json(evaluationResponseSchema.parse(response));
    }
    let evaluation;
    try { evaluation = evaluationResponseSchema.parse(raw.evaluation); }
    catch (error) {
      console.error('Invalid Bedrock evaluation contract', error.issues);
      await failedEvaluation(client, interview, inserted.rows[0].id, error);
      await client.query('COMMIT');
      return res.status(502).json({ message: 'Invalid evaluation response.' });
    }
    const a = evaluation.answerEvaluation;
    await client.query(`INSERT INTO turn_evaluations (interview_id,dialogue_turn_id,comprehension,fluency,grammar,vocabulary,coherence,interaction,pronunciation_status,pronunciation_score,estimated_band,estimated_cefr,observed_errors,evidence_json,strengths,improvement_areas,evaluation_status,prompt_version,model_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,'ok',$17,$18)`, [interview.id, inserted.rows[0].id, a.comprehension.score, a.fluency.score, a.grammar.score, a.vocabulary.score, a.coherence.score, a.interaction.score, a.pronunciation.status, a.pronunciation.score, evaluation.estimatedBand, evaluation.estimatedCefr, JSON.stringify(a.observedErrors), JSON.stringify({ comprehension:a.comprehension.evidence, fluency:a.fluency.evidence, grammar:a.grammar.evidence, vocabulary:a.vocabulary.evidence, coherence:a.coherence.evidence, interaction:a.interaction.evidence, pronunciation:a.pronunciation.evidence }), JSON.stringify(a.strengths), JSON.stringify(a.improvementAreas), promptVersion, process.env.BEDROCK_MODEL_ID || null]);
    const count = Number(interview.questions_asked || 0) + 1;
    const finish = count < 8 ? false : count >= 12 ? true : evaluation.shouldFinish;
    evaluation.shouldFinish = finish; evaluation.nextAction = finish ? 'finish_interview' : 'ask_next_question';
    if (finish) evaluation.nextQuestion = null;
    if (!finish && !evaluation.nextQuestion) evaluation.nextQuestion = { id: `server-fallback-${count}`, text: fallbackQuestions[evaluation.estimatedBand], difficulty: evaluation.estimatedBand, competencyTarget: 'interaction', stage: stageFor(count) };
    await client.query("UPDATE interviews SET current_band=$2,questions_asked=$3,status=CASE WHEN $4 THEN 'completed' ELSE status END,ended_at=CASE WHEN $4 THEN NOW() ELSE ended_at END WHERE id=$1", [interview.id, evaluation.estimatedBand, count, finish]);
    if (!finish && evaluation.nextQuestion) await client.query("INSERT INTO dialogue_turns (interview_id,turn_number,role,content) SELECT $1,COALESCE(MAX(turn_number),0)+1,'assistant',$2 FROM dialogue_turns WHERE interview_id=$1", [interview.id, evaluation.nextQuestion.text]);
    await logUsage(client, interview.id, raw.usage);
    await client.query('COMMIT');
    return res.json(evaluationResponseSchema.parse(evaluation));
  } catch (error) { await client.query('ROLLBACK'); console.error('Assessment route failed', error.name); return res.status(500).json({ message: 'Assessment request failed.' }); }
  finally { client.release(); }
});

function confidenceFor(rows, mockMode) {
  if (mockMode || rows.length < 6 || rows.filter(row => Number(row.word_count) < 15).length / rows.length > 0.3) return 'low';
  const indexes = rows.map(row => ['A1','A2','B1','B2','C1','C2'].indexOf(row.estimated_cefr));
  return rows.length >= 10 && Math.max(...indexes) - Math.min(...indexes) <= 1 ? 'high' : 'medium';
}
router.post('/:interviewId/report', async (req, res) => {
  const client = await db.connect();
  try {
    const found = await client.query('SELECT * FROM interviews WHERE id=$1', [req.params.interviewId]);
    if (!found.rowCount) return res.status(404).json({ message: 'Interview not found.' });
    if (found.rows[0].status !== 'completed') return res.status(400).json({ message: 'Interview is not completed.' });
    const result = await client.query("SELECT te.*,array_length(regexp_split_to_array(trim(dt.content),'\\s+'),1) AS word_count,dt.transcript_source,dt.transcript_edited FROM turn_evaluations te JOIN dialogue_turns dt ON dt.id=te.dialogue_turn_id WHERE te.interview_id=$1 AND te.evaluation_status='ok' ORDER BY te.created_at", [req.params.interviewId]);
    if (!result.rowCount) return res.status(400).json({ message: 'No successful evaluations are available.' });
    const failed = await client.query("SELECT COUNT(*)::int AS count FROM turn_evaluations WHERE interview_id=$1 AND evaluation_status='failed'", [req.params.interviewId]);
    const generated = await createReport(result.rows);
    const confidence = confidenceFor(result.rows, found.rows[0].mock_mode);
    const sources = [...new Set(result.rows.map(row => row.transcript_source || 'unknown'))];
    const limitations = [`Transcript source: ${sources.join(', ')}.`, 'Pronunciation was not assessed; no audio was analysed.', 'This is an estimated placement result, not an official certification.'];
    if (result.rows.some(row => row.transcript_edited)) limitations.push('Some transcripts were manually corrected; grammar scores should be interpreted with caution.');
    if (failed.rows[0].count) limitations.push(`${failed.rows[0].count} failed evaluation turn(s) were excluded.`);
    const cautiousSummary = /available evidence suggests/i.test(generated.report.summary) ? generated.report.summary : `The available evidence suggests ${generated.report.estimatedCefr}. ${generated.report.summary}`;
    const report = finalEnglishReportSchema.parse({ ...generated.report, summary: cautiousSummary, confidence, limitations });
    await client.query(`INSERT INTO reports (interview_id,report_json,estimated_cefr,confidence,dimensions_json,limitations,representative_examples,recommended_course_level,mock_mode,prompt_version) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT (interview_id) DO UPDATE SET report_json=EXCLUDED.report_json,estimated_cefr=EXCLUDED.estimated_cefr,confidence=EXCLUDED.confidence,dimensions_json=EXCLUDED.dimensions_json,limitations=EXCLUDED.limitations,representative_examples=EXCLUDED.representative_examples,recommended_course_level=EXCLUDED.recommended_course_level,mock_mode=EXCLUDED.mock_mode,prompt_version=EXCLUDED.prompt_version`, [req.params.interviewId, JSON.stringify(report), report.estimatedCefr, confidence, JSON.stringify(report.dimensions), JSON.stringify(limitations), JSON.stringify(report.representativeExamples), report.recommendedCourseLevel, found.rows[0].mock_mode, 'reporter-v1']);
    await logUsage(client, req.params.interviewId, generated.usage);
    return res.json(report);
  } catch (error) { console.error('Report generation failed', error.name); return res.status(502).json({ message: 'Report generation failed.' }); }
  finally { client.release(); }
});
router.get('/:interviewId/report', async (req, res) => {
  try { const result = await db.query('SELECT report_json FROM reports WHERE interview_id=$1', [req.params.interviewId]); return result.rowCount ? res.json(result.rows[0].report_json) : res.status(404).json({ message: 'Report not found.' }); }
  catch (error) { return res.status(500).json({ message: 'Could not load report.' }); }
});
module.exports = router;
