const express = require('express');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { assessTurn, nextConversationQuestion } = require('../services/assessor');
const { assessPronunciation } = require('../services/pronunciation');
const { createAudioArchive } = require('../services/audio-archive');
const { evaluationResponseSchema } = require('../../shared/assessment-schemas');
const { fuseCefr } = require('../services/cefr-scoring');

const router = express.Router();
const sessions = new Map();
const audioArchive = createAudioArchive();
const systemPrompt = fs.readFileSync(path.join(__dirname, '../prompts/assessor.en.txt'), 'utf8');
const MAX_QUESTIONS = 6;
const firstQuestion = {
  id: 'warm-up-1',
  text: 'Hello! To begin, could you introduce yourself and tell me what you do?',
  difficulty: 'intermediate',
  competencyTarget: 'interaction',
  stage: 'warm_up'
};
const stages = ['warm_up', 'experience', 'interaction', 'opinion', 'scenario', 'closing'];
const fallbackByBand = {
  beginner: 'What do you enjoy doing in your free time?',
  elementary: 'Can you describe a typical day at work or school?',
  intermediate: 'Tell me about a problem you solved recently.',
  upper_intermediate: 'How would you manage a disagreement in a team?',
  advanced: 'What makes a difficult professional decision fair?'
};

function stageFor(answered) {
  return stages[Math.min(answered, stages.length - 1)];
}

function notAssessed(evidence) {
  return {
    status: 'not_assessed', score: null, evidence, engine: null,
    accuracyScore: null, prosodyScore: null, wordObservations: [],
    phonemeErrors: [], fluency: null, suggestions: []
  };
}

function average(values) {
  const numeric = values.filter(value => Number.isFinite(value));
  return numeric.length ? Number((numeric.reduce((sum, value) => sum + value, 0) / numeric.length).toFixed(1)) : null;
}

function summarisePronunciation(session) {
  const perAnswer = session.pronunciationByAnswer || [];
  const assessed = perAnswer.filter(item => item.status === 'assessed');
  if (!assessed.length) {
    const evidence = session.consents.audioAnalysis
      ? 'No spoken answer could be acoustically assessed by the experimental pronunciation worker.'
      : 'The candidate did not consent to per-answer pronunciation analysis.';
    return { ...notAssessed(evidence), assessedAnswers: 0, totalAnswers: session.answered, perAnswer };
  }

  const phonemeErrors = assessed.flatMap(item => (item.phonemeErrors || []).map(error => ({
    ...error,
    answerNumber: item.answerNumber
  }))).slice(0, 12);
  const wordObservations = assessed.flatMap(item => (item.wordObservations || []).map(observation => ({
    ...observation,
    answerNumber: item.answerNumber
  }))).sort((left, right) => (left.totalScore ?? 101) - (right.totalScore ?? 101)).slice(0, 8);
  const fluency = {
    speakingRate: average(assessed.map(item => item.fluency?.speakingRate)),
    rhythmScore: average(assessed.map(item => item.fluency?.rhythmScore)),
    monotonyScore: average(assessed.map(item => item.fluency?.monotonyScore))
  };
  const hasFluency = Object.values(fluency).some(value => value !== null);
  return {
    status: 'assessed',
    score: average(assessed.map(item => item.score)),
    engine: assessed.every(item => item.engine === 'multipa') ? 'multipa' : 'phoneme_baseline',
    accuracyScore: average(assessed.map(item => item.accuracyScore)),
    prosodyScore: average(assessed.map(item => item.prosodyScore)),
    evidence: assessed.every(item => item.engine === 'multipa')
      ? `${assessed.length} of ${session.answered} recorded answer(s) were analysed with the pretrained open-source MultiPA audio model.`
      : `${assessed.length} of ${session.answered} recorded answer(s) were acoustically analysed with an experimental open-source pronunciation model.`,
    wordObservations,
    phonemeErrors,
    fluency: hasFluency ? fluency : null,
    suggestions: [...new Set(assessed.flatMap(item => item.suggestions || []))].slice(0, 3),
    assessedAnswers: assessed.length,
    totalAnswers: session.answered,
    perAnswer
  };
}

function publicSession(session) {
  return {
    interviewId: session.id,
    questionNumber: Math.min(session.answered + 1, MAX_QUESTIONS),
    totalQuestions: MAX_QUESTIONS,
    question: session.question,
    status: session.status,
    audioRecording: {
      enabled: Boolean(session.consents.audioRecording),
      retainedAnswers: session.recordings.length
    },
    audioAnalysis: {
      enabled: Boolean(session.consents.audioAnalysis),
      assessedAnswers: session.pronunciationByAnswer.filter(item => item.status === 'assessed').length
    }
  };
}

function buildReport(session) {
  const dimensionNames = ['comprehension', 'fluency', 'grammar', 'vocabulary', 'coherence', 'interaction'];
  const averages = Object.fromEntries(dimensionNames.map(name => [name, Number((session.evaluations.reduce((sum, item) => sum + item.answerEvaluation[name].score, 0) / session.evaluations.length).toFixed(1))]));
  const last = session.evaluations.at(-1);
  const shortAnswers = session.answers.filter(answer => answer.trim().split(/\s+/).length < 15).length;
  const pronunciation = summarisePronunciation(session);
  const fusion = fuseCefr(session.evaluations, pronunciation);
  const coverageValues = pronunciation.perAnswer.map(item => item.recordedDuration > 0 && item.analyzedDuration !== null ? item.analyzedDuration / item.recordedDuration : null).filter(Number.isFinite);
  const audioCoverage = coverageValues.length ? Number((average(coverageValues) * 100).toFixed(1)) : null;
  const speechPenalty = pronunciation.status === 'assessed' ? (audioCoverage !== null && audioCoverage < 80 ? 15 : 0) : 25;
  const confidenceScore = Math.max(0, Math.min(100, Math.round(45 + Math.min(session.answers.length, 6) * 6 + Math.min(session.answers.reduce((n,a)=>n+a.trim().split(/\s+/).filter(Boolean).length,0), 240) / 12 - speechPenalty - (shortAnswers * 8))));
  const confidence = confidenceScore >= 75 ? 'high' : confidenceScore >= 55 ? 'medium' : 'low';
  const dimensions = Object.fromEntries(['comprehension','fluency','grammar','vocabulary','coherence','interaction'].map(name => [name, { score: Number((session.evaluations.reduce((sum,item)=>sum+item.answerEvaluation[name].score,0)/session.evaluations.length).toFixed(1)), summary: `Average Claude language score for ${name}.` }]));
  dimensions.pronunciation = { status: pronunciation.status, score: pronunciation.score === null ? null : Number((pronunciation.score / 20).toFixed(1)), summary: pronunciation.evidence };
  return {
    estimatedCefr: fusion.estimatedCefr,
    estimatedBand: fusion.estimatedBand,
    confidence,
    confidenceScore,
    confidenceReasons: [`${session.answers.length}/${MAX_QUESTIONS} answers completed`, `${shortAnswers} short answer(s)`, audioCoverage === null ? 'Pronunciation is required but no usable audio coverage is available' : `${audioCoverage}% average audio coverage`, 'Confidence is a product heuristic, not a statistical certification.'],
    summary: `Estimated CEFR level: ${fusion.estimatedCefr}. Language score ${fusion.languageScore}/100${fusion.speechScore === null ? '' : ` and speech score ${fusion.speechScore}/100`} were combined with documented weights.`,
    dimensions,
    fusion,
    audioCoverage,
    rawEvaluations: session.evaluations,
    audioCoverageByAnswer: pronunciation.perAnswer.map(item => ({ answerNumber: item.answerNumber, recordedDuration: item.recordedDuration, analyzedDuration: item.analyzedDuration, coverage: item.recordedDuration > 0 && item.analyzedDuration !== null ? Number((item.analyzedDuration / item.recordedDuration * 100).toFixed(1)) : null, analyzedSegments: item.analyzedSegments, skippedSegments: item.skippedSegments, skippedReasons: item.skippedReasons })),
    averages,
    strengths: [...new Set(session.evaluations.flatMap(item => item.answerEvaluation.strengths))].slice(0, 4),
    improvementAreas: [...new Set(session.evaluations.flatMap(item => item.answerEvaluation.improvementAreas))].slice(0, 4),
    representativeExamples: session.evaluations.flatMap(item => (item.answerEvaluation.observedErrors || []).map(error => ({ example: error.example, observation: `${error.category}: ${error.suggestedCorrection}` }))).slice(0, 6),
    recommendedCourseLevel: `${fusion.estimatedCefr} guided English course`,
    pronunciation,
    limitations: [
      'Transcript source: browser speech recognition or manual text.',
      pronunciation.status === 'assessed'
        ? `Pronunciation was assessed from ${pronunciation.assessedAnswers} recorded interview answer(s) by an experimental open-source acoustic model.`
        : 'Pronunciation was not assessed; no response audio could be acoustically analysed.',
      pronunciation.engine === 'multipa'
        ? 'MultiPA creates its own internal speech transcript for open-response scoring. Its experimental audio scores do not change the CEFR placement estimate automatically.'
        : 'The pronunciation signal is aligned with the transcript, so transcription differences can affect it. It does not change the CEFR placement estimate automatically.',
      session.consents.audioRecording
        ? `${session.recordings.length} spoken-response recording(s) were retained in the local administrator archive and can be deleted by an authorised administrator.`
        : 'Spoken-response recordings were not retained.',
      'This is an estimated placement result, not an official certification.',
      'Confidence is a transparent product heuristic, not a statistically validated probability.'
    ]
  };
}

function validAdminCode(value) {
  const configured = process.env.LIVE_AUDIO_ADMIN_CODE;
  if (!configured || typeof value !== 'string') return false;
  const expected = Buffer.from(configured);
  const supplied = Buffer.from(value);
  return expected.length === supplied.length && crypto.timingSafeEqual(expected, supplied);
}

function requireArchiveAdministrator(req, res, next) {
  if (!process.env.LIVE_AUDIO_ADMIN_CODE) {
    return res.status(503).json({ message: 'Audio archive administration has not been configured on this server.' });
  }
  if (!validAdminCode(req.get('x-live-audio-admin-code'))) {
    return res.status(401).json({ message: 'Administrator access is required.' });
  }
  return next();
}

async function assessRecordedAnswer(session, answerNumber, transcript) {
  const recording = session.recordings.find(item => item.answerNumber === answerNumber);
  if (!recording) return notAssessed('No saved audio recording was available for this answer.');
  try {
    const stored = await audioArchive.getAudio(recording.id);
    if (!stored) return notAssessed('The saved audio recording for this answer is no longer available.');
    const audio = await fs.promises.readFile(stored.audioPath);
    return await assessPronunciation({
      audio,
      contentType: stored.metadata.contentType,
      referenceText: transcript
    });
  } catch (error) {
    console.error('Per-answer pronunciation assessment failed', error.name, error.message);
    return notAssessed('The saved audio recording could not be processed for pronunciation analysis.');
  }
}

router.post('/start', (req, res) => {
  const { candidate, consents } = req.body || {};
  if (!candidate || typeof candidate.fullName !== 'string' || !candidate.fullName.trim() || typeof candidate.email !== 'string' || !candidate.email.includes('@')) return res.status(400).json({ message: 'Candidate name and a valid email address are required.' });
  if (!consents?.assessment || !consents?.microphone) return res.status(400).json({ message: 'Assessment and microphone consent are required.' });
  if (consents?.audioAnalysis && !consents?.audioRecording) return res.status(400).json({ message: 'Per-answer pronunciation analysis requires consent to retain each response recording.' });
  if (!consents?.audioRecording || !consents?.audioAnalysis) return res.status(400).json({ message: 'Recording and pronunciation analysis consent are required for this spoken assessment.' });
  const id = crypto.randomUUID();
  const session = {
    id,
    candidate: { fullName: candidate.fullName.trim(), email: candidate.email.trim().toLowerCase(), reference: String(candidate.reference || '').trim() },
    consents: {
      assessment: true,
      microphone: true,
      audioRecording: Boolean(consents?.audioRecording),
      audioAnalysis: Boolean(consents?.audioAnalysis),
      acceptedAt: new Date().toISOString()
    },
    answered: 0,
    currentBand: 'intermediate',
    question: firstQuestion,
    history: [{ role: 'user', text: 'Begin the English placement interview.' }, { role: 'assistant', text: firstQuestion.text }],
    answers: [],
    evaluations: [],
    recordings: [],
    pronunciationByAnswer: [],
    pronunciationJobs: [],
    evaluationJobs: [],
    status: 'in_progress',
    createdAt: Date.now()
  };
  sessions.set(id, session);
  return res.status(201).json(publicSession(session));
});

router.post('/:interviewId/recordings/:answerNumber', express.raw({
  type: request => String(request.headers['content-type'] || '').startsWith('audio/'),
  limit: '8mb'
}), async (req, res) => {
  const session = sessions.get(req.params.interviewId);
  if (!session) return res.status(404).json({ message: 'Interview session not found. Please start again.' });
  if (session.status !== 'in_progress') return res.status(400).json({ message: 'This interview no longer accepts response recordings.' });
  if (!session.consents.audioRecording) return res.status(403).json({ message: 'Consent to retain response recordings is required.' });
  const answerNumber = Number(req.params.answerNumber);
  if (!Number.isInteger(answerNumber) || answerNumber !== session.answered + 1) return res.status(400).json({ message: 'This recording does not match the current interview question.' });
  if (session.recordings.some(recording => recording.answerNumber === answerNumber)) return res.status(409).json({ message: 'A recording has already been retained for this answer.' });

  try {
    const recording = await audioArchive.save({
      interviewId: session.id,
      candidate: session.candidate,
      answerNumber,
      question: session.question,
      audio: req.body,
      contentType: req.headers['content-type']
    });
    session.recordings.push(recording);
    return res.status(201).json({ recording: { id: recording.id, answerNumber: recording.answerNumber, recordedAt: recording.recordedAt } });
  } catch (error) {
    console.error('Live audio archive write failed', error.name, error.message);
    return res.status(503).json({ message: 'The response recording could not be retained. Please try again.' });
  }
});

router.post('/:interviewId/answer', async (req, res) => {
  const session = sessions.get(req.params.interviewId);
  if (!session) return res.status(404).json({ message: 'Interview session not found. Please start again.' });
  if (session.status !== 'in_progress') return res.status(400).json({ message: 'This interview is already completed.' });
  const transcript = req.body?.transcript;
  if (typeof transcript !== 'string' || !transcript.trim()) return res.status(400).json({ message: 'Please provide an answer.' });

  const answerNumber = session.answered + 1;
  const hasRecording = session.recordings.some(recording => recording.answerNumber === answerNumber);
  if (session.consents.audioRecording && !hasRecording) {
    return res.status(400).json({ message: 'Please record this spoken answer before sending it. Every response is retained when audio recording is enabled.' });
  }

  if (session.turnBusy) return res.status(409).json({ message: 'An answer is already being processed.' });
  session.turnBusy = true;
  try {
    // The language evaluation and the self-hosted acoustic check run in parallel.
    // Only the transcript goes to the language assessor; audio remains local to
    // the archive and the separately configured pronunciation worker.
    const pronunciationPromise = session.consents.audioAnalysis
      ? assessRecordedAnswer(session, answerNumber, transcript.trim())
      : Promise.resolve(null);
    const evaluationJob = assessTurn({
      systemPrompt,
      history: session.history.map(item => ({ ...item })),
      candidateAnswer: transcript.trim(),
      currentBand: session.currentBand,
      questionsAsked: session.answered,
      stage: stageFor(session.answered)
    }).then(result => evaluationResponseSchema.parse(result.evaluation)).catch(error => ({ failure: error.message }));
    const questionText = answerNumber < MAX_QUESTIONS ? await nextConversationQuestion({ history: session.history, candidateAnswer: transcript.trim(), stage: stageFor(answerNumber), currentBand: session.currentBand }) : null;
    session.evaluationJobs.push(evaluationJob);
    const questionId = session.question.id;
    const job = pronunciationPromise.then(pronunciation => {
      if (pronunciation) session.pronunciationByAnswer.push({ ...pronunciation, answerNumber, questionId });
    });
    session.pronunciationJobs.push(job);
    const pronunciation = null;
    session.answers.push(transcript.trim());

    session.history.push({ role: 'user', text: transcript.trim() });
    session.answered += 1;


    const finished = session.answered >= MAX_QUESTIONS;
    if (finished) {
      session.evaluations = await Promise.all(session.evaluationJobs);
      if (session.evaluations.some(item => item.failure)) throw new Error('One or more language evaluations failed; report unavailable');
      const evaluation = session.evaluations[session.evaluations.length - 1];
      await Promise.all(session.pronunciationJobs);
      session.pronunciationByAnswer.sort((a,b) => a.answerNumber-b.answerNumber);
      session.status = 'completed';
      session.question = null;
      return res.json({
        ...publicSession(session),
        pronunciation,
        evaluation: { ...evaluation, shouldFinish: true, nextAction: 'finish_interview', nextQuestion: null, finishReason: 'Six-question interview completed.' },
        report: buildReport(session)
      });
    }

    const nextQuestion = {
      id: `fallback-${session.answered + 1}`,
      text: questionText,
      difficulty: session.currentBand,
      competencyTarget: 'interaction',
      stage: stageFor(session.answered)
    };
    nextQuestion.stage = stageFor(session.answered);
    session.question = nextQuestion;
    session.history.push({ role: 'assistant', text: nextQuestion.text });
    return res.json({
      ...publicSession(session),
      pronunciation,
      evaluation: null
    });
  } catch (error) {
    console.error('Live interview evaluation failed', error.name, error.message);
    return res.status(503).json({ message: 'The AI interviewer is temporarily unavailable. Please try again.' });
  } finally { session.turnBusy = false; }
});

router.get('/admin/recordings', requireArchiveAdministrator, async (_req, res) => {
  try {
    return res.json({ recordings: await audioArchive.list() });
  } catch (error) {
    console.error('Live audio archive list failed', error.name, error.message);
    return res.status(503).json({ message: 'The audio archive is temporarily unavailable.' });
  }
});

router.get('/admin/recordings/:recordingId/audio', requireArchiveAdministrator, async (req, res) => {
  try {
    const recording = await audioArchive.getAudio(req.params.recordingId);
    if (!recording) return res.status(404).json({ message: 'Recording not found.' });
    res.type(recording.metadata.contentType);
    res.set('Content-Disposition', `inline; filename="answer-${recording.metadata.answerNumber}"`);
    return res.sendFile(recording.audioPath);
  } catch (error) {
    console.error('Live audio archive read failed', error.name, error.message);
    return res.status(503).json({ message: 'The recording could not be opened.' });
  }
});

router.delete('/admin/recordings/:recordingId', requireArchiveAdministrator, async (req, res) => {
  try {
    const deleted = await audioArchive.delete(req.params.recordingId);
    if (!deleted) return res.status(404).json({ message: 'Recording not found or already deleted.' });
    return res.status(204).end();
  } catch (error) {
    console.error('Live audio archive deletion failed', error.name, error.message);
    return res.status(503).json({ message: 'The recording could not be deleted.' });
  }
});

router.get('/:interviewId', (req, res) => {
  const session = sessions.get(req.params.interviewId);
  if (!session) return res.status(404).json({ message: 'Interview session not found.' });
  return res.json(session.status === 'completed' ? { ...publicSession(session), report: buildReport(session) } : publicSession(session));
});

setInterval(() => {
  const cutoff = Date.now() - (2 * 60 * 60 * 1000);
  for (const [id, session] of sessions) if (session.createdAt < cutoff) sessions.delete(id);
}, 15 * 60 * 1000).unref();

module.exports = router;
