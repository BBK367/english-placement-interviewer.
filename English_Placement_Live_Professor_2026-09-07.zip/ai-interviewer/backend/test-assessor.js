const fs = require('node:fs');
const path = require('node:path');
const { assessTurn } = require('./services/assessor');

async function main() {
  const systemPrompt = fs.readFileSync(path.join(__dirname, 'prompts/assessor.en.txt'), 'utf8');
  const result = await assessTurn({
    systemPrompt, history: [],
    candidateAnswer: 'I working in a company since three years and I like very much my job',
    currentBand: 'intermediate', questionsAsked: 1, stage: 'experience'
  });
  console.dir(result, { depth: null });
}
main().catch(error => { console.error(error.name, error.message); process.exitCode = 1; });
