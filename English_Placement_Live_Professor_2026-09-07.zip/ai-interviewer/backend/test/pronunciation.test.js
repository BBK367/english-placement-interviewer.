const test = require('node:test');
const assert = require('node:assert/strict');
const { assessPronunciation, normalizePronunciationResult } = require('../services/pronunciation');

test('pronunciation worker data is normalised before it reaches the interview report', () => {
  const result = normalizePronunciationResult({
    status: 'assessed', score: 72.5, evidence: 'A short reference sentence was assessed.',
    phonemeErrors: [{ expected: 'TH', heard: 'F', type: 'mispronounced', score: 22 }],
    fluency: { speakingRate: 118, rhythmScore: 68, monotonyScore: 24 },
    suggestions: ['Practise the TH sound with slow, short phrases.']
  });
  assert.equal(result.score, 72.5);
  assert.equal(result.phonemeErrors[0].expected, 'TH');
  assert.equal(result.fluency.speakingRate, 118);
});

test('pretrained MultiPA dimensions and word observations are retained', () => {
  const result = normalizePronunciationResult({
    status: 'assessed', engine: 'multipa', score: 71.2,
    accuracyScore: 69.5, prosodyScore: 74.3,
    fluency: { speakingRate: 112, rhythmScore: 72, monotonyScore: null },
    wordObservations: [{ word: 'interview', accuracyScore: 60, stressScore: 56, totalScore: 59 }],
    evidence: 'Pretrained MultiPA result.', suggestions: []
  });
  assert.equal(result.engine, 'multipa');
  assert.equal(result.accuracyScore, 69.5);
  assert.equal(result.prosodyScore, 74.3);
  assert.deepEqual(result.wordObservations[0], { word: 'interview', accuracyScore: 60, stressScore: 56, totalScore: 59 });
});

test('an unavailable worker never creates an invented pronunciation score', () => {
  const result = normalizePronunciationResult({ status: 'not_assessed', evidence: 'Worker unavailable.' });
  assert.equal(result.status, 'not_assessed');
  assert.equal(result.score, null);
  assert.deepEqual(result.phonemeErrors, []);
});

test('a deployment without a pronunciation worker reports not assessed', async () => {
  const workerUrl = process.env.PRONUNCIATION_WORKER_URL;
  delete process.env.PRONUNCIATION_WORKER_URL;
  try {
    const result = await assessPronunciation({
      audio: Buffer.from('short-audio'), contentType: 'audio/webm', referenceText: 'The quick brown fox jumps over the lazy dog.'
    });
    assert.equal(result.status, 'not_assessed');
    assert.equal(result.score, null);
  } finally {
    if (workerUrl !== undefined) process.env.PRONUNCIATION_WORKER_URL = workerUrl;
  }
});

test('the optional worker key is sent only from the backend to a configured worker', async () => {
  const previousUrl = process.env.PRONUNCIATION_WORKER_URL;
  const previousKey = process.env.PRONUNCIATION_WORKER_API_KEY;
  process.env.PRONUNCIATION_WORKER_URL = 'https://pronunciation.example.test';
  process.env.PRONUNCIATION_WORKER_API_KEY = 'server-only-test-key';
  try {
    let receivedHeaders;
    const result = await assessPronunciation({
      audio: Buffer.from('short-audio'), contentType: 'audio/webm', referenceText: 'The quick brown fox jumps over the lazy dog.',
      fetchImpl: async (_url, options) => {
        receivedHeaders = options.headers;
        return { ok: true, json: async () => ({ status: 'not_assessed', evidence: 'No stable assessment.' }) };
      }
    });
    assert.equal(receivedHeaders['x-worker-api-key'], 'server-only-test-key');
    assert.equal(result.status, 'not_assessed');
  } finally {
    if (previousUrl === undefined) delete process.env.PRONUNCIATION_WORKER_URL;
    else process.env.PRONUNCIATION_WORKER_URL = previousUrl;
    if (previousKey === undefined) delete process.env.PRONUNCIATION_WORKER_API_KEY;
    else process.env.PRONUNCIATION_WORKER_API_KEY = previousKey;
  }
});
