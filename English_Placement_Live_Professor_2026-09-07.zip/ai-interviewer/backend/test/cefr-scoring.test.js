const test = require('node:test');
const assert = require('node:assert/strict');
const { fuseCefr } = require('../services/cefr-scoring');
function evaluations(score, cefr='B1') { return [{ estimatedCefr: cefr, answerEvaluation: Object.fromEntries(['comprehension','grammar','vocabulary','coherence','interaction','fluency'].map(name => [name,{score,evidence:'test'}])) }]; }
test('language remains dominant when speech is weak', () => {
  const result = fuseCefr(evaluations(4), { status:'assessed', score:20, accuracyScore:20, prosodyScore:20, fluency:{rhythmScore:20} });
  assert.equal(result.estimatedCefr, 'B2');
  assert.ok(result.languageScore > result.speechScore);
});
test('speech improves but cannot rescue weak language to an advanced level', () => {
  const result = fuseCefr(evaluations(1), { status:'assessed', score:100, accuracyScore:100, prosodyScore:100, fluency:{rhythmScore:100} });
  assert.equal(result.estimatedCefr, 'B1');
});
test('missing speech falls back to language score', () => {
  const result = fuseCefr(evaluations(3), { status:'not_assessed' });
  assert.equal(result.speechScore, null);
  assert.equal(result.estimatedCefr, 'B2');
});

