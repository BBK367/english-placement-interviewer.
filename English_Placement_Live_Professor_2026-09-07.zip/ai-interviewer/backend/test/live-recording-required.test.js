const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const app = require('../server');

async function withServer(run) {
  const server = http.createServer(app);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  try {
    return await run(`http://127.0.0.1:${port}`);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
}

test('per-answer audio analysis requires a retained recording before an answer can be evaluated', async () => {
  await withServer(async baseUrl => {
    const start = await fetch(`${baseUrl}/api/live/start`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        candidate: { fullName: 'Local Test', email: 'local@example.com', reference: 'TEST' },
        consents: { assessment: true, microphone: true, audioRecording: true, audioAnalysis: true }
      })
    });
    assert.equal(start.status, 201);
    const { interviewId } = await start.json();

    const answer = await fetch(`${baseUrl}/api/live/${interviewId}/answer`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ transcript: 'Hello, my name is Local Test and I work in finance.' })
    });
    assert.equal(answer.status, 400);
    const body = await answer.json();
    assert.match(body.message, /record this spoken answer/i);
  });
});

test('audio analysis cannot be enabled without consent to retain response recordings', async () => {
  await withServer(async baseUrl => {
    const response = await fetch(`${baseUrl}/api/live/start`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        candidate: { fullName: 'Local Test', email: 'local@example.com', reference: 'TEST' },
        consents: { assessment: true, microphone: true, audioRecording: false, audioAnalysis: true }
      })
    });
    assert.equal(response.status, 400);
    const body = await response.json();
    assert.match(body.message, /requires consent to retain/i);
  });
});
