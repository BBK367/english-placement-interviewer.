const test=require('node:test'),assert=require('node:assert/strict');
const {analyseChunks,aggregate}=require('../services/partial-pronunciation');
const {fuseCefr}=require('../services/cefr-scoring');
test('failed long audio is split once and a successful child is retained',async()=>{
 let n=0;const results=await analyseChunks(Buffer.alloc(32000*60),async()=>++n===2?{status:'assessed',engine:'multipa',score:70}:{status:'not_assessed',evidence:'Could not assess this recording'},x=>x);
 assert.equal(n,3);assert.equal(results.length,2);assert.equal(aggregate(results).score,70);
});
test('infrastructure failure does not trigger repeated long waits',async()=>{
 let n=0;const results=await analyseChunks(Buffer.alloc(32000*60),async()=>{n++;return {status:'not_assessed',evidence:'Worker unavailable'};},x=>x);assert.equal(n,1);assert.equal(aggregate(results).score,null);
});
test('partial score is weighted by analysed duration, not number of chunks',()=>{
 const result=aggregate([{status:'assessed',engine:'multipa',score:80,recordedDuration:60,analyzedDuration:30},{status:'assessed',engine:'multipa',score:40,recordedDuration:30,analyzedDuration:10},{status:'not_assessed',recordedDuration:30}]);assert.equal(result.score,70);
 const evaluation={answerEvaluation:Object.fromEntries(['comprehension','grammar','vocabulary','coherence','interaction','fluency'].map(k=>[k,{score:3}]))};
 assert.equal(fuseCefr([evaluation],result).weights.speech,.35);
 assert.equal(fuseCefr([evaluation],aggregate([])).weights.speech,0);
});
