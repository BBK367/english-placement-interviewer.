const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createAudioArchive } = require('../services/audio-archive');

test('a retained response can be listed, retrieved and deleted by an administrator', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'audio-archive-'));
  const archive = createAudioArchive({ directory });
  try {
    const recording = await archive.save({
      interviewId: 'interview-1',
      candidate: { fullName: 'Alex Martin', email: 'alex@example.com', reference: 'TEST-001' },
      answerNumber: 1,
      question: { id: 'warm-up-1', text: 'Please introduce yourself.' },
      audio: Buffer.from('test-audio'), contentType: 'audio/webm'
    });
    const list = await archive.list();
    assert.equal(list.length, 1);
    assert.equal(list[0].candidate.fullName, 'Alex Martin');
    const audio = await archive.getAudio(recording.id);
    assert.equal(audio.metadata.answerNumber, 1);
    assert.equal(await archive.delete(recording.id), true);
    assert.equal((await archive.list()).length, 0);
  } finally {
    await fs.rm(directory, { recursive: true, force: true });
  }
});
