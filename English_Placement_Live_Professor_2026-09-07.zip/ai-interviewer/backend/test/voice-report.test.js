const test = require('node:test');
const assert = require('node:assert/strict');
const { wav, voiceReport } = require('../services/voice-report');

test('assistant speech alone cannot produce a candidate placement', async () => {
  const result = await voiceReport({ transcript: [{ role: 'ASSISTANT', text: 'Please introduce yourself and tell me about your work and studies.' }], audio: [] });
  assert.equal(result.status, 'insufficient_evidence');
  assert.equal(result.report, undefined);
});

test('a greeting alone cannot produce a CEFR level', async () => {
  const result = await voiceReport({ transcript: [{ role: 'USER', text: 'Hello there.' }], audio: [] });
  assert.equal(result.status, 'insufficient_evidence');
});

test('worker WAV has consistent mono PCM metadata and unmodified samples', () => {
  const pcm = Buffer.from([0, 0, 255, 127, 0, 128]);
  const result = wav(pcm);
  assert.equal(result.readUInt32LE(24), 16000);
  assert.equal(result.readUInt16LE(22), 1);
  assert.equal(result.readUInt32LE(40), pcm.length);
  assert.equal(result.readUInt32LE(4), result.length - 8);
  assert.deepEqual(result.subarray(44), pcm);
});
