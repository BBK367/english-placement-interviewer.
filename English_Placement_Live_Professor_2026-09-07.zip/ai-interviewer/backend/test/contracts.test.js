const test = require('node:test');
const assert = require('node:assert/strict');
const { evaluationResponseSchema, finalEnglishReportSchema } = require('../../shared/assessment-schemas');

test('evaluation contract accepts the documented field names', () => {
  const metric = { score: 3, evidence: 'A short example' };
  const value = { answerEvaluation: { comprehension: metric, fluency: metric, grammar: metric, vocabulary: metric, coherence: metric, interaction: metric, pronunciation: { status: 'not_assessed', score: null, evidence: 'No audio.' }, observedErrors: [], strengths: [], improvementAreas: [] }, estimatedBand: 'intermediate', estimatedCefr: 'B1', nextAction: 'ask_next_question', nextQuestion: { id: 'q1', text: 'What do you do?', difficulty: 'intermediate', competencyTarget: 'interaction', stage: 'experience' }, shouldFinish: false, finishReason: '' };
  assert.deepEqual(evaluationResponseSchema.parse(value), value);
  assert.throws(() => evaluationResponseSchema.parse({ ...value, cefr: 'B1', estimatedCefr: undefined }));
});

test('report contract requires limitations', () => {
  const metric = { score: 3, summary: 'The evidence is limited.' };
  const value = { estimatedCefr: 'B1', estimatedBand: 'intermediate', confidence: 'low', summary: 'The available evidence suggests B1.', dimensions: { comprehension: metric, fluency: metric, grammar: metric, vocabulary: metric, coherence: metric, interaction: metric, pronunciation: { status: 'not_assessed', score: null, summary: 'No audio was analysed.' } }, strengths: [], improvementAreas: [], representativeExamples: [], recommendedCourseLevel: 'B1', limitations: ['Transcript source: browser.', 'Pronunciation was not assessed; no audio was analysed.', 'This is an estimated placement result, not an official certification.'] };
  assert.deepEqual(finalEnglishReportSchema.parse(value), value);
});
