require('dotenv').config({ path: require('node:path').join(__dirname, '../.env') });
const express = require('express');
const path = require('node:path');
const assessment = require('./routes/assessment');
const live = require('./routes/live');
const app = express();
app.use(express.json({ limit: '100kb' }));
app.use('/api/assessment', assessment);
app.use('/api/live', live);
app.use('/api/voice', require('./routes/voice'));
app.get('/health', (_req, res) => res.json({ status: 'ok' }));
app.get('/', (_req, res) => res.redirect('/voice.html'));
app.use(express.static(path.join(__dirname, '../frontend/public'), {
  setHeaders(res, file) {
    if (/voice(?:-results)?\.(html|js)$/.test(file)) res.setHeader('Cache-Control', 'no-store');
  }
}));
if (require.main === module) app.listen(process.env.PORT || 5001, () => console.log(`Assessment API listening on ${process.env.PORT || 5001}`));
module.exports = app;
