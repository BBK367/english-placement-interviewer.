# MultiPA review for the AI English Placement Interviewer

**Paper reviewed:** [MultiPA: A Multi-task Speech Pronunciation Assessment Model for Open Response Scenarios](https://arxiv.org/html/2308.12490v2) (INTERSPEECH 2024)  
**Status:** experimental pronunciation module for a recruitment pre-screening prototype  
**Licence/cost:** open source research implementation with published pretrained weights; no pronunciation API licence is used.

## 1. What problem does it solve?

The browser transcript can show **what** a candidate said. It cannot reliably show **how** it was pronounced. MultiPA analyses the recorded audio signal itself, so it can provide an additional pronunciation signal for free-form spoken answers.

This is relevant to this project because candidates answer interview questions in their own words, rather than reading one fixed sentence.

## 2. What can MultiPA provide?

For each recorded answer, the published model can estimate:

- **accuracy**: how clearly the speech sounds;
- **fluency**: pauses, hesitations and continuity of speech;
- **prosody**: rhythm, pace and aspects of intonation;
- **word-level observations**: words or segments that may need improvement.

It is not an official English certificate, a CEFR classifier, or a safe automatic hiring decision tool.

## 3. How does the model work?

MultiPA is already trained. It combines several pretrained components internally:

1. **Whisper** creates transcripts from the candidate's audio in an open-response setting.
2. **Charsiu** aligns recognised words and speech sounds with the audio timeline.
3. **HuBERT** extracts acoustic speech features.
4. **RoBERTa** adds language context for the recognised words.
5. The released **MultiPA checkpoint** combines those features into accuracy, fluency, prosody and word-level results.

The candidate's browser transcript is not used as the pronunciation score. Recognition errors can still affect word-level feedback because the model must recognise free speech before aligning it.

## 4. Integration in this project

```text
Candidate gives recording consent
        -> browser records one answer
        -> Node.js backend stores the private audio archive
        -> Node.js calls the private MultiPA Python worker
        -> worker returns advisory audio scores
        -> final report shows pronunciation separately

Candidate transcript -> Claude / AWS Bedrock -> grammar, vocabulary,
                         coherence, comprehension and CEFR estimate
```

Claude does **not** receive the recording and does not calculate the pronunciation score. The worker is called server-to-server with a private API key. If a candidate does not consent, does not record audio, or the worker fails, pronunciation is returned as `not_assessed` rather than an invented score.

### Long answers: the 15-second rule

The 15-second limit is **not a limit imposed on the candidate**. A candidate may give a 45-second or one-minute answer. It is an internal protection for MultiPA, whose published evaluation uses short utterances.

For an answer longer than 15 seconds, the worker now asks Whisper for timestamped natural speech segments. It groups adjacent segments only while the group remains at most 15 seconds, analyses each group with MultiPA, then combines the numerical results with a duration-weighted average. This prevents normal cuts through the middle of a sentence. If Whisper cannot produce timestamps, a bounded fixed-window fallback is used so that the model is never given an overlong recording.

The overall recording duration is retained for the speaking-rate calculation, so long pauses are not hidden by the segmentation.

## 5. What the research results mean

The paper reports promising results for open responses, especially for sentence-level **accuracy** and **fluency**. In its small real-world test set, the reported correlation with human ratings was 0.62 for accuracy and 0.65 for fluency. Prosody was lower (0.49), and word-level scoring was lower again (0.39).

This means MultiPA is a useful **experimental audio signal**, not proof that every individual score is correct. The authors themselves state that recognised words can be wrong and that word-level feedback needs further investigation.

For this application, the safest presentation is:

- show an advisory pronunciation section;
- use cautious wording such as “may need improvement”;
- never make a rejection decision from MultiPA alone;
- never convert the pronunciation number directly into a CEFR level.

## 6. What is needed to test it properly?

The model does not need new training for the prototype. It needs a machine to run inference:

| Resource | Suitable minimum for a demonstration |
| --- | --- |
| Operating system | Linux (Ubuntu 22.04 or 24.04 preferred) |
| Container runtime | Docker and Docker Compose |
| GPU | NVIDIA GPU, ideally 12–16 GB VRAM (for example RTX 3060 12 GB or T4 16 GB) |
| Main memory | 16 GB RAM |
| CPU | 4 vCPU or more |
| Disk | 40 GB SSD free space |

The Node.js website can remain on Render. The GPU machine hosts only the Python pronunciation worker. CPU-only execution is possible for local development but is too slow for a comfortable live interview demonstration.

### Optional Apple Silicon test machine

A Mac mini M1 with 16 GB unified memory and an eight-core Apple GPU can be used
to test the worker through PyTorch's Apple Metal (MPS) backend. It is not
equivalent to NVIDIA CUDA, and MultiPA/Fairseq must be benchmarked on the
actual Mac before it is accepted for a live demonstration. The project includes
[native installation and benchmark instructions](../pronunciation-worker/DEPLOY_MAC_MINI_M1.md).

## 7. Validation plan before any real recruitment use

1. Collect a small set of consented recordings from speakers with varied English levels and accents.
2. Ask an English teacher or qualified reviewer to rate accuracy, fluency and prosody independently.
3. Compare those ratings with the model outputs, noting latency, failures and inconsistent feedback.
4. Adjust the display thresholds so that only high-confidence word suggestions are shown.
5. Keep recordings private, give the candidate clear consent options, and allow an administrator to delete them permanently.

## 8. Practical conclusion

MultiPA is the most realistic free and open-source choice for this prototype because it is already trained and supports free spoken answers. It materially improves the project over transcript-only analysis, but it must remain an experimental advisory component until it has been validated on the target candidate population.
