# Live voice preview

Open http://localhost:5006/voice.html on the running test server. On a normal application start, use /voice.html on the configured port.

Consent explicitly to sending microphone audio to AWS US East (Virginia), press Start conversation, and say hello. Use headphones. End conversation releases the microphone, stops playback and closes the AWS connection. Sessions expire after seven minutes.

This is a separate voice preview, with continuous 16 kHz PCM input, 24 kHz streamed audio output and interruption handling. Browser speech recognition and speech synthesis are not used. It does not produce a CEFR report or save recordings. The existing assessment remains at /.

Server settings: VOICE_AWS_REGION (default us-east-1), VOICE_MODEL_ID (default amazon.nova-2-sonic-v1:0). Existing AWS credential configuration is used. Streaming requires Bedrock permission for InvokeModelWithBidirectionalStream. AWS usage is billed to the configured account.

Verification: a public sample WAV produced text events and audio response chunks through the actual local route and AWS service. The 13 existing backend tests passed. Microphone latency, echo and interruptions still require browser testing. Do not describe this as a validated placement assessment or a latency guarantee.
