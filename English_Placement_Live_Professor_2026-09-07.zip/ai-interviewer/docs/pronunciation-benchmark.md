# Free/open-source pronunciation benchmark

Date: 16 August 2026  
Scope: advisory English pronunciation checks for the AI English Placement
Interviewer. This is not an official certification and must never create an
automatic recruitment decision.

## What needs to be measured

Browser speech recognition can identify *what* a candidate said, but not
reliably *how* it was pronounced. Pronunciation therefore requires a real audio
recording. The project records each consented spoken interview answer; a typed
answer never becomes pronunciation evidence.

## Options compared

| Option | What it provides | Complexity | Decision |
| --- | --- | --- | --- |
| [Kaldi GOP](https://github.com/kaldi-asr/kaldi) | Classical phoneme-level Goodness of Pronunciation scoring. | High: acoustic model, lexicon, alignment recipe and Linux worker. | Strong long-term reference, not the first prototype. |
| [GOPT](https://github.com/YuanGongND/gopt) + Kaldi GOP | Phoneme, word and utterance scoring for several pronunciation dimensions. | Very high: its own-data workflow needs Kaldi GOP preparation. | Benchmark later on a capable Linux machine. |
| [Montreal Forced Aligner](https://montreal-forced-aligner.readthedocs.io/en/latest/) | Word and phone timings for a known transcript. | Medium, but it does not create a pronunciation score itself. | Auxiliary component only. |
| [SpeechOcean762](https://github.com/jimbozhang/speechocean762) | Human-labelled pronunciation assessment data. | Training/evaluation data, not a runtime service. | Use for external evaluation, not direct deployment. |
| [MultiPA](https://github.com/yuwchen/MultiPA) | Pretrained open-response audio accuracy, fluency, prosody and word-level scores. | Python 3.9, PyTorch, HuBERT, RoBERTa, Whisper and a separate worker. | Selected: it is free, open source and designed for spoken free responses. |

## Selected architecture

```text
Candidate consent + recorded answer audio
        -> Node/Express backend
        -> self-hosted pretrained MultiPA Python worker
        -> audio accuracy, fluency, prosody and word observations
        -> separate pronunciation section in the report
```

Claude receives the interview transcript only. It does not receive recordings
and does not produce the pronunciation score. MultiPA runs locally/on the
project's worker, internally transcribes open responses with Whisper, and
segments long answers at Whisper's timestamped natural speech boundaries into
blocks of at most 15 seconds. The numerical results are combined with a
duration-weighted average. A fixed bounded fallback is used only if Whisper
cannot return usable timestamps. If the worker is unavailable or cannot assess
an answer, the result is exactly `not_assessed` with a null score.

## Validation required before use

MultiPA's released weights avoid the need to train a model for this prototype,
but they do not prove that its numerical scores are calibrated for this
candidate population. Before any real use:

1. Obtain explicit consent and use complete recorded answers, never typed text.
2. Have an English teacher or qualified reviewer rate a representative sample
   of recordings from the expected accents and recording conditions.
3. Compare the human ratings with MultiPA's accuracy, fluency and prosody
   results; record latency, failures and potential accent bias.
4. Keep the feedback advisory. Never turn a low audio score into an automatic
   rejection or a definitive CEFR level.

## Hosting reality

Open source removes a pronunciation API licence fee; it does not remove the
need for RAM, CPU/GPU time and model storage. The Node.js app can remain on
Render, but the Python worker needs an organisation-owned machine or a separate
Linux service. Render Free is not an appropriate host for MultiPA.
