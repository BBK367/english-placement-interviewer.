# Run the complete demonstration with Docker

This configuration launches the **website/API** and the **pretrained MultiPA
pronunciation worker** together. It is intended for a local Linux or Windows
Docker demonstration. It is not the Mac mini M1 MPS route, which uses the
native guide in pronunciation-worker/DEPLOY_MAC_MINI_M1.md.

## 1. Install Docker Desktop or Docker Engine

Confirm these commands work:

```bash
docker --version
docker compose version
```

## 2. Create the local environment file

From the project root:

```bash
cp .env.example .env
```

Set these server-only values in .env:

```dotenv
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=ap-southeast-1
BEDROCK_MODEL_ID=global.anthropic.claude-sonnet-4-6
LIVE_AUDIO_ADMIN_CODE=choose-a-long-private-code
PRONUNCIATION_WORKER_API_KEY=generate-a-long-random-private-value
```

Do not put any of these values in frontend files or commit .env.

## 3. Start every component

```bash
docker compose -f docker-compose.local.yml up --build
```

On the first start, MultiPA downloads its released pretrained assets. This can
take several minutes. Docker retains those assets in a named volume, so later
starts do not download them again.

When both services are healthy, open:

```text
http://localhost:5001/
```

The administrator archive is at:

```text
http://localhost:5001/admin.html
```

## 4. Stop or restart

```bash
docker compose -f docker-compose.local.yml down
docker compose -f docker-compose.local.yml up
```

The named model and audio archive volumes are retained. An administrator can
permanently delete an individual candidate recording in the web interface.

## NVIDIA GPU option

On a Linux computer with an NVIDIA GPU and NVIDIA Container Toolkit:

```bash
docker compose -f docker-compose.local.yml -f docker-compose.local.gpu.yml up --build
```

The application still opens at http://localhost:5001. Before conducting an
interview, verify the worker can see the GPU:

```bash
docker compose -f docker-compose.local.yml -f docker-compose.local.gpu.yml exec pronunciation-worker python -c "import torch; print(torch.cuda.is_available())"
```

The result must be True. The Mac mini M1 does not use this overlay.
